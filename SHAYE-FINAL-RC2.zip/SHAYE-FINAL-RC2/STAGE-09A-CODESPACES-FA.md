# مرحله ۹A — آزمایش در GitHub Codespaces

این بسته برای نصب وابستگی‌ها، TypeScript typecheck، تست‌های خودکار، اجرای PostgreSQL، Migrationها و بالا‌آوردن موقت سایت در Codespaces ساخته شده است.

## نکته‌های ایمنی

- شبکه روی Testnet باقی می‌ماند.
- `BLOCKCHAIN_ENABLED=false` است.
- Worker واریز، اعتباردهی، برداشت و Sweep خاموش‌اند.
- هیچ کلید خصوصی یا عبارت بازیابی در این بسته وجود ندارد.
- حساب مدیر داخل این مرحله فقط آزمایشی است.
- آدرس برداشت مشترک میان چند کاربر مجاز است؛ فقط ارسال دوباره همان درخواست برداشت جلوگیری می‌شود.

## اجرای اصلی

از ریشه پروژه:

```bash
bash scripts/codespaces-stage9a.sh
```

پس از موفقیت، از بخش **Ports** در Codespaces پورت `5000` را با **Open in Browser** باز کنید.

## وضعیت

```bash
bash scripts/codespaces-stage9a-status.sh
```

## توقف

```bash
bash scripts/codespaces-stage9a-stop.sh
```

توقف Codespace طبیعی است؛ این مرحله جای VPS دائمی را نمی‌گیرد.
