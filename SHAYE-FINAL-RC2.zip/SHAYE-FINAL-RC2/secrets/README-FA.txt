این پوشه برای فایل‌های محرمانه کیف پول است.

فایل deposit_wallet_xpub در نسخه ZIP عمداً خالی است تا Docker Compose قبل از راه‌اندازی خطا ندهد.
برای ساخت کیف پول آزمایشی روی VPS، فقط اسکریپت زیر را اجرا کنید:

./scripts/setup-deposit-wallet.sh

عبارت بازیابی، کلید خصوصی یا فایل‌های این پوشه را در چت، GitHub یا فایل ZIP بعدی قرار ندهید.


فایل hot_wallet_private_key
---------------------------
این فایل فقط روی VPS و فقط توسط اسکریپت مرحله ۶ ساخته می‌شود.
داخل ZIP خالی است. کلید خصوصی را در چت، GitHub، Spck، تلگرام یا فضای ابری
قرار ندهید. فقط سرویس withdrawal-worker اجازه خواندن این Secret را دارد.

فایل‌های مرحله ۸
----------------
فایل deposit_wallet_mnemonic فقط روی VPS توسط مرحله ۳ ساخته می‌شود. در ZIP خالی است.
فایل gas_wallet_private_key فقط روی VPS توسط setup-sweeper.sh ساخته می‌شود. در ZIP خالی است.

فقط سرویس sweep-worker اجازه خواندن این دو Secret را دارد. برنامه اصلی سایت، Worker واریز
و Worker برداشت به این کلیدها دسترسی ندارند. آدرس عمومی GAS_WALLET_ADDRESS و
TREASURY_WALLET_ADDRESS محرمانه نیستند و در .env.deploy ذخیره می‌شوند.
