(function (global) {
  'use strict';
  let cache = null;
  const defaults = {
    cycleDays: 30,
    vipAmounts: { 1: 10, 2: 30, 3: 60, 4: 150, 5: 300 },
    vipDailyRates: { 1: 1, 2: 1.2, 3: 1.5, 4: 1.8, 5: 2 }
  };

  function fromServer(config) {
    const data = JSON.parse(JSON.stringify(defaults));
    if (config) {
      data.cycleDays = config.settings.lockDays;
      (config.tiers || []).forEach((tier) => {
        data.vipAmounts[tier.level] = tier.minLocked;
        data.vipDailyRates[tier.level] = tier.dailyRate;
      });
    }
    return data;
  }

  global.ShayeConfig = {
    defaults,
    load() { return cache || defaults; },
    async refresh() {
      cache = fromServer(await global.ShayeAPI.public.config());
      return cache;
    },
    save() {
      throw new Error('تنظیمات فقط از پنل مدیریت سرور ذخیره می‌شوند.');
    },
    detectVip(amount, settings) {
      const data = settings || defaults;
      let level = 0;
      Object.keys(data.vipAmounts).forEach((key) => {
        if (Number(amount) >= Number(data.vipAmounts[key])) level = Number(key);
      });
      return level;
    },
    rewardForVip(level, settings) {
      const data = settings || defaults;
      return { rate: Number(data.vipDailyRates[level] || 0), reward: 0 };
    }
  };
})(window);
