(function () {
  'use strict';

  const q = (selector, root = document) => root.querySelector(selector);
  const qa = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const esc = (value) => String(value == null ? '' : value).replace(/[&<>"']/g, (char) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[char]));

  const defaults = {
    companyName: 'SHAYE', intro: '', address: '', phone: '', email: '', website: '',
    logo: '', officeImage: '', licenseImage: '', socials: '',
    banners: [], news: [], licenses: [], documents: []
  };

  let homeState = { ...defaults };
  let selectedSupportUser = '';

  function isDashboard() {
    return /(?:^|\/)dashboard\.html(?:$|[?#])/.test(location.pathname + location.search + location.hash);
  }

  function isAdmin() {
    return /(?:^|\/)admin\.html(?:$|[?#])/.test(location.pathname + location.search + location.hash);
  }

  function toast(text, error) {
    const old = q('.premium-toast');
    if (old) old.remove();
    const node = document.createElement('div');
    node.className = 'premium-toast' + (error ? ' error' : '');
    node.textContent = text;
    document.body.appendChild(node);
    setTimeout(() => node.remove(), 2200);
  }

  function safeLink(value) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    try {
      const url = new URL(raw, location.origin);
      return ['http:', 'https:'].includes(url.protocol) ? url.href : '';
    } catch (_error) {
      return '';
    }
  }

  function readFile(file) {
    return new Promise((resolve, reject) => {
      if (!file) return resolve('');
      if (file.size > 1_500_000) return reject(new Error('حداکثر حجم هر تصویر ۱.۵ مگابایت است.'));
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(new Error('خواندن فایل انجام نشد.'));
      reader.readAsDataURL(file);
    });
  }

  function itemId() {
    return (window.crypto && window.crypto.randomUUID) ? window.crypto.randomUUID() : String(Date.now()) + Math.random().toString(16).slice(2);
  }

  async function loadHomePublic() {
    homeState = { ...defaults, ...(await ShayeAPI.public.home()) };
    return homeState;
  }

  async function loadHomeAdmin() {
    homeState = { ...defaults, ...(await ShayeAPI.admin.home()) };
    return homeState;
  }

  async function saveHome(next) {
    homeState = { ...defaults, ...next };
    homeState = { ...defaults, ...(await ShayeAPI.admin.updateHome(homeState)) };
    return homeState;
  }

  function initSlider(root) {
    const slider = q('#premiumSlider', root || document);
    if (!slider) return;
    const slides = qa('.premium-slide', slider);
    const dots = qa('.premium-dots button', slider);
    let index = 0;
    const show = (next) => {
      index = (next + slides.length) % slides.length;
      slides.forEach((x, i) => x.classList.toggle('active', i === index));
      dots.forEach((x, i) => x.classList.toggle('active', i === index));
    };
    dots.forEach((dot, i) => {
      dot.onclick = (event) => { event.preventDefault(); show(i); };
    });
    if (slides.length > 1) setInterval(() => show(index + 1), 4500);
  }

  async function renderHome() {
    if (!isDashboard()) return;
    try {
      const data = await loadHomePublic();
      const main = q('.dashboard-container');
      if (!main) return;
      q('#premiumHomeContent')?.remove();
      const host = document.createElement('section');
      host.id = 'premiumHomeContent';
      host.className = 'premium-home-content';

      const banners = (data.banners || []).filter((x) => x && x.active !== false && x.image);
      const bannerHtml = banners.length
        ? '<div class="premium-slider" id="premiumSlider">' + banners.map((x, i) => {
            const href = safeLink(x.link);
            return '<a class="premium-slide ' + (i ? '' : 'active') + '" ' + (href ? 'href="' + esc(href) + '" target="_blank" rel="noopener"' : '') + '>' +
              '<img src="' + esc(x.image) + '" alt="' + esc(x.title || 'بنر') + '">' +
              '<div class="premium-slide-caption"><b>' + esc(x.title || '') + '</b><span>' + esc(x.text || '') + '</span></div></a>';
          }).join('') + '<div class="premium-dots">' + banners.map((_x, i) => '<button type="button" data-slide="' + i + '" class="' + (i ? '' : 'active') + '"></button>').join('') + '</div></div>'
        : '';

      const introHtml = (data.intro || data.logo || data.officeImage)
        ? '<article class="premium-company-card premium-glass">' +
          (data.logo ? '<img class="premium-company-logo" src="' + esc(data.logo) + '" alt="لوگو">' : '') +
          '<div><h3>' + esc(data.companyName || 'SHAYE') + '</h3><p>' + esc(data.intro || '') + '</p>' +
          '<div class="premium-company-meta">' + [data.address, data.phone, data.email, data.website].filter(Boolean).map((x) => '<span>' + esc(x) + '</span>').join('') + '</div></div>' +
          (data.officeImage ? '<img class="premium-office" src="' + esc(data.officeImage) + '" alt="دفتر">' : '') + '</article>'
        : '';

      const news = (data.news || []).filter((x) => x && x.active !== false).slice().reverse().slice(0, 8);
      const newsHtml = news.length
        ? '<section class="premium-block"><h3>📰 اخبار شرکت</h3><div class="premium-news-grid">' + news.map((x) =>
            '<article class="premium-news premium-glass">' + (x.image ? '<img src="' + esc(x.image) + '" alt="' + esc(x.title || 'خبر') + '">' : '') +
            '<div><b>' + esc(x.title || '') + '</b><p>' + esc(x.text || '') + '</p><small>' + esc(x.date || '') + '</small></div></article>'
          ).join('') + '</div></section>'
        : '';

      const licenses = (data.licenses || []).filter((x) => x && x.active !== false && x.image);
      if (data.licenseImage) licenses.unshift({ title: 'پروانه فعالیت', image: data.licenseImage });
      const licenseHtml = licenses.length
        ? '<section class="premium-block"><h3>🛡️ مجوزها و گواهی‌ها</h3><div class="premium-license-grid">' + licenses.map((x) =>
            '<button type="button" class="premium-license premium-glass" data-image="' + esc(x.image) + '"><img src="' + esc(x.image) + '" alt="' + esc(x.title || 'مجوز') + '"><span>' + esc(x.title || 'مجوز') + '</span></button>'
          ).join('') + '</div></section>'
        : '';

      const documents = (data.documents || []).filter((x) => x && x.active !== false && (x.url || x.data));
      const documentHtml = documents.length
        ? '<section class="premium-block"><h3>📄 اسناد شرکت</h3><div class="premium-docs">' + documents.map((x) => {
            const href = x.data || safeLink(x.url);
            if (!href) return '';
            return '<a class="premium-doc premium-glass" href="' + esc(href) + '" ' + (x.data ? 'download="' + esc(x.name || 'document') + '"' : 'target="_blank" rel="noopener"') + '><span>📎</span><b>' + esc(x.title || x.name || 'سند') + '</b></a>';
          }).join('') + '</div></section>'
        : '';

      host.innerHTML = bannerHtml + introHtml + newsHtml + licenseHtml + documentHtml;
      const welcome = q('.welcome');
      if (welcome?.parentNode) welcome.parentNode.insertBefore(host, welcome);
      else main.insertBefore(host, main.firstChild);

      qa('[data-image]', host).forEach((button) => {
        button.onclick = () => {
          const viewer = document.createElement('div');
          viewer.className = 'premium-image-viewer';
          viewer.innerHTML = '<button type="button">×</button><img src="' + esc(button.dataset.image) + '" alt="تصویر">';
          document.body.appendChild(viewer);
          viewer.onclick = () => viewer.remove();
        };
      });
      initSlider(host);
    } catch (_error) {
      // Main application remains usable if optional home content cannot load.
    }
  }

  function listRows(items, type) {
    return (items || []).map((x, index) =>
      '<div class="premium-admin-row"><div><b>' + esc(x.title || x.name || 'مورد') + '</b><small>' + esc(x.text || x.url || '') + '</small></div>' +
      '<label class="switch-line"><input type="checkbox" data-active="' + type + '" data-index="' + index + '" ' + (x.active === false ? '' : 'checked') + '>فعال</label>' +
      '<button type="button" data-remove="' + type + '" data-index="' + index + '">حذف</button></div>'
    ).join('') || '<div class="premium-empty">هنوز موردی ثبت نشده است.</div>';
  }

  function adminHtml(data) {
    return '<h2 class="section-title">✨ مدیریت محتوای سرور و پشتیبانی</h2>' +
      '<p class="muted">تمام موارد این بخش در PostgreSQL ذخیره می‌شوند و برای همه کاربران یکسان هستند.</p>' +
      '<div class="premium-admin-tabs">' +
        '<button class="active" data-patab="support">پشتیبانی</button>' +
        '<button data-patab="company">مشخصات سایت</button>' +
        '<button data-patab="banners">بنرها</button>' +
        '<button data-patab="news">اخبار</button>' +
        '<button data-patab="licenses">مجوزها</button>' +
        '<button data-patab="documents">اسناد</button>' +
      '</div>' +
      '<div class="premium-pa-page active" data-papage="support">' +
        '<input id="paSupportSearch" placeholder="جستجوی ایمیل"><div id="paSupportThreads"></div>' +
        '<div id="paSupportConversation"></div><div class="v6-chat-form"><textarea id="paSupportReply" placeholder="پاسخ مدیر"></textarea><button id="paSupportSend">ارسال</button></div>' +
      '</div>' +
      '<div class="premium-pa-page" data-papage="company">' +
        '<label>نام سایت<input id="paCompanyName" value="' + esc(data.companyName) + '"></label>' +
        '<label>معرفی سایت<textarea id="paIntro">' + esc(data.intro) + '</textarea></label>' +
        '<div class="grid2"><label>آدرس<input id="paAddress" value="' + esc(data.address) + '"></label><label>تلفن<input id="paPhone" value="' + esc(data.phone) + '"></label><label>ایمیل<input id="paEmail" value="' + esc(data.email) + '"></label><label>وب‌سایت<input id="paWebsite" value="' + esc(data.website) + '"></label></div>' +
        '<div class="grid2"><label>لوگو<input id="paLogo" type="file" accept="image/*"></label><label>عکس دفتر<input id="paOffice" type="file" accept="image/*"></label><label>پروانه اصلی<input id="paMainLicense" type="file" accept="image/*"></label></div>' +
        '<div class="mini-actions"><button class="premium-save" id="paSaveCompany">ذخیره مشخصات</button><button class="danger-button" id="paClearCompanyImages">حذف تصاویر اصلی</button></div>' +
      '</div>' +
      '<div class="premium-pa-page" data-papage="banners"><label>عنوان<input id="paBannerTitle"></label><label>متن<input id="paBannerText"></label><label>لینک اختیاری<input id="paBannerLink" placeholder="https://..."></label><label>تصویر<input id="paBannerImage" type="file" accept="image/*"></label><button class="premium-save" id="paAddBanner">افزودن بنر</button><div id="paBannerList">' + listRows(data.banners, 'banners') + '</div></div>' +
      '<div class="premium-pa-page" data-papage="news"><label>عنوان<input id="paNewsTitle"></label><label>متن<textarea id="paNewsText"></textarea></label><label>تصویر اختیاری<input id="paNewsImage" type="file" accept="image/*"></label><button class="premium-save" id="paAddNews">انتشار خبر</button><div id="paNewsList">' + listRows(data.news, 'news') + '</div></div>' +
      '<div class="premium-pa-page" data-papage="licenses"><label>عنوان<input id="paLicenseTitle"></label><label>تصویر<input id="paLicenseImage" type="file" accept="image/*"></label><button class="premium-save" id="paAddLicense">افزودن مجوز</button><div id="paLicenseList">' + listRows(data.licenses, 'licenses') + '</div></div>' +
      '<div class="premium-pa-page" data-papage="documents"><label>عنوان<input id="paDocTitle"></label><label>لینک سند<input id="paDocUrl" placeholder="https://..."></label><button class="premium-save" id="paAddDoc">افزودن سند</button><div id="paDocList">' + listRows(data.documents, 'documents') + '</div></div>';
  }

  async function renderSupportThreads(root) {
    const rows = await ShayeAPI.admin.supportThreads(q('#paSupportSearch', root)?.value || '');
    q('#paSupportThreads', root).innerHTML = rows.map((x) =>
      '<button type="button" class="premium-doc" data-support-user="' + esc(x.userId) + '"><b>' + esc(x.email) + '</b><span>' + x.messageCount + ' پیام | ' + x.unread + ' خوانده‌نشده</span></button>'
    ).join('') || '<div class="premium-empty">پیامی وجود ندارد.</div>';
    qa('[data-support-user]', root).forEach((button) => {
      button.onclick = async () => {
        selectedSupportUser = button.dataset.supportUser;
        const messages = await ShayeAPI.admin.supportThread(selectedSupportUser);
        q('#paSupportConversation', root).innerHTML = messages.map((x) =>
          '<div class="v6-bubble ' + (x.senderRole === 'ADMIN' ? 'admin' : 'user') + '">' + esc(x.body) + '<small style="display:block;opacity:.55;margin-top:4px">' + esc(new Date(x.createdAt).toLocaleString()) + '</small></div>'
        ).join('');
      };
    });
  }

  function bindContentActions(root) {
    qa('[data-remove]', root).forEach((button) => {
      button.onclick = async () => {
        const type = button.dataset.remove;
        const index = Number(button.dataset.index);
        const next = { ...homeState, [type]: [...(homeState[type] || [])] };
        next[type].splice(index, 1);
        await saveHome(next);
        await refreshAdminContent(root);
        toast('حذف شد.');
      };
    });
    qa('[data-active]', root).forEach((input) => {
      input.onchange = async () => {
        const type = input.dataset.active;
        const index = Number(input.dataset.index);
        const items = (homeState[type] || []).map((x) => ({ ...x }));
        if (items[index]) items[index].active = input.checked;
        await saveHome({ ...homeState, [type]: items });
        toast('وضعیت ذخیره شد.');
      };
    });
  }

  async function refreshAdminContent(root) {
    await loadHomeAdmin();
    q('#paBannerList', root).innerHTML = listRows(homeState.banners, 'banners');
    q('#paNewsList', root).innerHTML = listRows(homeState.news, 'news');
    q('#paLicenseList', root).innerHTML = listRows(homeState.licenses, 'licenses');
    q('#paDocList', root).innerHTML = listRows(homeState.documents, 'documents');
    bindContentActions(root);
  }

  async function mountAdmin() {
    if (!isAdmin() || q('#premiumServerTools')) return;
    const panel = q('#adminPanel');
    const shell = q('.admin-shell');
    if (!panel || panel.classList.contains('hidden') || !shell) return false;

    let data;
    try {
      data = await loadHomeAdmin();
    } catch (error) {
      if (error.status === 401 || error.status === 403) return false;
      throw error;
    }

    const section = document.createElement('section');
    section.className = 'card premium-admin';
    section.id = 'premiumServerTools';
    section.innerHTML = adminHtml(data);
    shell.appendChild(section);

    qa('[data-patab]', section).forEach((button) => {
      button.onclick = () => {
        qa('[data-patab]', section).forEach((x) => x.classList.remove('active'));
        qa('[data-papage]', section).forEach((x) => x.classList.remove('active'));
        button.classList.add('active');
        q('[data-papage="' + button.dataset.patab + '"]', section).classList.add('active');
      };
    });

    q('#paSupportSearch', section).oninput = () => renderSupportThreads(section).catch((e) => toast(e.message, true));
    q('#paSupportSend', section).onclick = async () => {
      const value = q('#paSupportReply', section).value.trim();
      if (!selectedSupportUser || !value) return;
      try {
        await ShayeAPI.admin.supportReply(selectedSupportUser, value);
        q('#paSupportReply', section).value = '';
        const selectedButton = q('[data-support-user="' + selectedSupportUser + '"]', section);
        if (selectedButton) await selectedButton.onclick();
        await renderSupportThreads(section);
      } catch (error) { toast(error.message, true); }
    };
    await renderSupportThreads(section);

    const pending = {};
    [['paLogo', 'logo'], ['paOffice', 'officeImage'], ['paMainLicense', 'licenseImage']].forEach(([inputId, key]) => {
      q('#' + inputId, section).onchange = async function () {
        try { pending[key] = await readFile(this.files?.[0]); } catch (error) { toast(error.message, true); this.value = ''; }
      };
    });

    q('#paSaveCompany', section).onclick = async () => {
      try {
        await saveHome({
          ...homeState,
          companyName: q('#paCompanyName', section).value.trim(),
          intro: q('#paIntro', section).value.trim(),
          address: q('#paAddress', section).value.trim(),
          phone: q('#paPhone', section).value.trim(),
          email: q('#paEmail', section).value.trim(),
          website: q('#paWebsite', section).value.trim(),
          ...pending
        });
        Object.keys(pending).forEach((key) => delete pending[key]);
        toast('مشخصات ذخیره شد.');
      } catch (error) { toast(error.message, true); }
    };

    q('#paClearCompanyImages', section).onclick = async () => {
      if (!confirm('لوگو، عکس دفتر و پروانه اصلی حذف شوند؟')) return;
      try { await saveHome({ ...homeState, logo: '', officeImage: '', licenseImage: '' }); toast('تصاویر حذف شدند.'); }
      catch (error) { toast(error.message, true); }
    };

    q('#paAddBanner', section).onclick = async () => {
      try {
        const image = await readFile(q('#paBannerImage', section).files?.[0]);
        if (!image) throw new Error('تصویر بنر را انتخاب کنید.');
        const link = q('#paBannerLink', section).value.trim();
        if (link && !safeLink(link)) throw new Error('لینک بنر معتبر نیست.');
        const items = [...(homeState.banners || []), { id: itemId(), title: q('#paBannerTitle', section).value.trim(), text: q('#paBannerText', section).value.trim(), link, image, active: true }];
        await saveHome({ ...homeState, banners: items });
        ['paBannerTitle', 'paBannerText', 'paBannerLink'].forEach((id) => { q('#' + id, section).value = ''; });
        q('#paBannerImage', section).value = '';
        await refreshAdminContent(section); toast('بنر ذخیره شد.');
      } catch (error) { toast(error.message, true); }
    };

    q('#paAddNews', section).onclick = async () => {
      try {
        const title = q('#paNewsTitle', section).value.trim();
        const text = q('#paNewsText', section).value.trim();
        if (!title || !text) throw new Error('عنوان و متن خبر را وارد کنید.');
        const image = await readFile(q('#paNewsImage', section).files?.[0]);
        const items = [...(homeState.news || []), { id: itemId(), title, text, image, date: new Date().toLocaleDateString('fa-IR'), active: true }];
        await saveHome({ ...homeState, news: items });
        q('#paNewsTitle', section).value = ''; q('#paNewsText', section).value = ''; q('#paNewsImage', section).value = '';
        await refreshAdminContent(section); toast('خبر ذخیره شد.');
      } catch (error) { toast(error.message, true); }
    };

    q('#paAddLicense', section).onclick = async () => {
      try {
        const title = q('#paLicenseTitle', section).value.trim();
        const image = await readFile(q('#paLicenseImage', section).files?.[0]);
        if (!title || !image) throw new Error('عنوان و تصویر مجوز را وارد کنید.');
        const items = [...(homeState.licenses || []), { id: itemId(), title, image, active: true }];
        await saveHome({ ...homeState, licenses: items });
        q('#paLicenseTitle', section).value = ''; q('#paLicenseImage', section).value = '';
        await refreshAdminContent(section); toast('مجوز ذخیره شد.');
      } catch (error) { toast(error.message, true); }
    };

    q('#paAddDoc', section).onclick = async () => {
      try {
        const title = q('#paDocTitle', section).value.trim();
        const url = q('#paDocUrl', section).value.trim();
        if (!title || !safeLink(url)) throw new Error('عنوان و لینک معتبر سند را وارد کنید.');
        const items = [...(homeState.documents || []), { id: itemId(), title, url, active: true }];
        await saveHome({ ...homeState, documents: items });
        q('#paDocTitle', section).value = ''; q('#paDocUrl', section).value = '';
        await refreshAdminContent(section); toast('سند ذخیره شد.');
      } catch (error) { toast(error.message, true); }
    };

    bindContentActions(section);
    return true;
  }

  async function waitForAdmin(attempt = 0) {
    if (!isAdmin()) return;
    try {
      if (await mountAdmin()) return;
    } catch (error) {
      console.error('Admin content mount failed', error);
    }
    if (attempt < 120) setTimeout(() => waitForAdmin(attempt + 1), 500);
  }

  function init() {
    renderHome();
    waitForAdmin();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
