(function(global){
  'use strict';
  const API=global.ShayeAPI;
  const $=id=>document.getElementById(id);
  const esc=v=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmt=v=>{try{return new Intl.DateTimeFormat(document.documentElement.lang||'fa',{dateStyle:'short',timeStyle:'short'}).format(new Date(v))}catch(_){return String(v||'')}};
  let selectedId='', selectedEmail='', timer=0, poll=0, loading=false;

  function msg(text,type=''){
    const el=$('supportAdminMessage');
    if(!el)return;
    el.textContent=text||'';
    el.className='admin-message'+(type?' '+type:'');
  }
  function setBadge(count){
    const badge=$('adminSupportBadge');
    if(!badge)return;
    const n=Math.max(0,Number(count)||0);
    badge.textContent=n>99?'99+':String(n);
    badge.hidden=n===0;
  }
  function isActive(){return $('supportPage')?.classList.contains('active')}

  async function loadThreads(keepSelection=true){
    if(!API?.admin?.supportThreads || loading)return;
    loading=true;
    const list=$('supportThreadList');
    if(list&&!list.children.length)list.innerHTML='<div class="admin-support-empty">در حال دریافت گفتگوها...</div>';
    try{
      const rows=await API.admin.supportThreads(($('supportSearch')?.value||'').trim());
      setBadge(rows.reduce((n,x)=>n+Number(x.unread||0),0));
      if(!list)return;
      list.innerHTML=rows.length?rows.map(x=>'<button type="button" class="admin-support-thread '+(x.userId===selectedId?'active':'')+'" data-user-id="'+esc(x.userId)+'" data-email="'+esc(x.email)+'"><span class="admin-support-thread-main"><strong>'+esc(x.email)+'</strong><small>'+esc(fmt(x.lastMessageAt))+'</small></span><span class="admin-support-thread-meta"><b>'+Number(x.messageCount||0)+'</b>'+(Number(x.unread||0)>0?'<i>'+Number(x.unread)+'</i>':'')+'</span></button>').join(''):'<div class="admin-support-empty">گفتگویی پیدا نشد.</div>';
      list.querySelectorAll('[data-user-id]').forEach(b=>b.onclick=()=>openThread(b.dataset.userId,b.dataset.email));
      if(keepSelection&&selectedId&&rows.some(x=>x.userId===selectedId)){
        list.querySelectorAll('[data-user-id]').forEach(x=>x.classList.toggle('active',x.dataset.userId===selectedId));
      }else if(rows.length&&!selectedId){
        await openThread(rows[0].userId,rows[0].email,false);
      }
    }catch(e){
      if(list)list.innerHTML='<div class="admin-support-empty error">'+esc(e.message||'گفتگوها دریافت نشد.')+'</div>';
    }finally{loading=false}
  }

  async function openThread(id,email,refreshList=true){
    selectedId=id||'';selectedEmail=email||'';
    document.querySelectorAll('.admin-support-thread').forEach(x=>x.classList.toggle('active',x.dataset.userId===selectedId));
    const title=$('supportConversationTitle'), box=$('supportConversation');
    if(title)title.textContent=selectedEmail||'گفتگو';
    if(box)box.innerHTML='<div class="admin-support-empty">در حال دریافت پیام‌ها...</div>';
    try{
      const rows=await API.admin.supportThread(selectedId);
      if(box){
        box.innerHTML=rows.length?rows.map(x=>'<article class="admin-support-message '+(x.senderRole==='ADMIN'?'admin':'user')+'"><div>'+esc(x.body)+'</div><small>'+esc(fmt(x.createdAt))+'</small></article>').join(''):'<div class="admin-support-empty">هنوز پیامی وجود ندارد.</div>';
        box.scrollTop=box.scrollHeight;
      }
      if(refreshList)await loadThreads(true);
    }catch(e){if(box)box.innerHTML='<div class="admin-support-empty error">'+esc(e.message||'پیام‌ها دریافت نشد.')+'</div>'}
  }

  async function reply(event){
    event.preventDefault();
    const input=$('supportReplyText'), button=$('supportReplyButton');
    const body=(input?.value||'').trim();
    if(!selectedId){msg('ابتدا یک گفتگو را انتخاب کنید.','error');return}
    if(!body){msg('متن پاسخ را بنویسید.','error');return}
    button.disabled=true;msg('در حال ارسال...');
    try{
      await API.admin.supportReply(selectedId,body);
      input.value='';msg('پاسخ ارسال شد.','success');
      await openThread(selectedId,selectedEmail);
    }catch(e){msg(e.message||'پاسخ ارسال نشد.','error')}
    finally{button.disabled=false}
  }

  function bind(){
    const tab=document.querySelector('[data-tab="supportPage"]');
    if(!tab||tab.dataset.supportBound==='1')return;
    tab.dataset.supportBound='1';
    tab.addEventListener('click',()=>setTimeout(()=>{loadThreads();startPoll()},0));
    $('supportRefreshButton')?.addEventListener('click',()=>loadThreads());
    $('supportReplyForm')?.addEventListener('submit',reply);
    $('supportSearch')?.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(()=>{selectedId='';selectedEmail='';loadThreads(false)},280)});
    document.addEventListener('visibilitychange',()=>{if(document.hidden)stopPoll();else if(isActive())startPoll()});
  }
  function startPoll(){stopPoll();poll=setInterval(()=>{if(isActive())loadThreads(true)},15000)}
  function stopPoll(){if(poll){clearInterval(poll);poll=0}}
  function init(){bind();setTimeout(()=>loadThreads(false),1200);window.addEventListener('beforeunload',stopPoll,{once:true})}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})(window);
