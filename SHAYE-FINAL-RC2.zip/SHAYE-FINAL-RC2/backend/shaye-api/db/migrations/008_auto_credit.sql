-- Stage 5: automatic crediting of confirmed blockchain deposits.
-- All balance changes, lock creation, referral rewards and ledger postings are
-- committed in one PostgreSQL transaction and are idempotent per chain event.

ALTER TABLE blockchain_settings
  ADD COLUMN IF NOT EXISTS auto_credit_enabled BOOLEAN NOT NULL DEFAULT FALSE;

ALTER TABLE blockchain_deposits
  ADD COLUMN IF NOT EXISTS credit_job_enqueued_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS credited_amount NUMERIC(18,6),
  ADD COLUMN IF NOT EXISTS lock_days_snapshot INTEGER,
  ADD COLUMN IF NOT EXISTS level1_referral_rate_snapshot NUMERIC(8,4),
  ADD COLUMN IF NOT EXISTS level2_referral_rate_snapshot NUMERIC(8,4),
  ADD COLUMN IF NOT EXISTS vip_level_before INTEGER,
  ADD COLUMN IF NOT EXISTS vip_level_after INTEGER,
  ADD COLUMN IF NOT EXISTS credit_journal_id TEXT REFERENCES ledger_journals(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS credit_failure_reason TEXT;

ALTER TABLE blockchain_deposits
  DROP CONSTRAINT IF EXISTS blockchain_deposits_status_check;
ALTER TABLE blockchain_deposits
  ADD CONSTRAINT blockchain_deposits_status_check CHECK (
    status IN (
      'DETECTED','CONFIRMING','CONFIRMED','CREDITED','ORPHANED',
      'IGNORED','FAILED','REVIEW_REQUIRED'
    )
  );

ALTER TABLE blockchain_deposits
  DROP CONSTRAINT IF EXISTS blockchain_deposits_credited_amount_check;
ALTER TABLE blockchain_deposits
  ADD CONSTRAINT blockchain_deposits_credited_amount_check CHECK (
    credited_amount IS NULL OR credited_amount > 0
  );
ALTER TABLE blockchain_deposits
  DROP CONSTRAINT IF EXISTS blockchain_deposits_lock_days_snapshot_check;
ALTER TABLE blockchain_deposits
  ADD CONSTRAINT blockchain_deposits_lock_days_snapshot_check CHECK (
    lock_days_snapshot IS NULL OR lock_days_snapshot BETWEEN 1 AND 3650
  );
ALTER TABLE blockchain_deposits
  DROP CONSTRAINT IF EXISTS blockchain_deposits_referral_snapshot_check;
ALTER TABLE blockchain_deposits
  ADD CONSTRAINT blockchain_deposits_referral_snapshot_check CHECK (
    (level1_referral_rate_snapshot IS NULL OR level1_referral_rate_snapshot BETWEEN 0 AND 25)
    AND
    (level2_referral_rate_snapshot IS NULL OR level2_referral_rate_snapshot BETWEEN 0 AND 25)
  );

CREATE INDEX IF NOT EXISTS blockchain_deposits_credit_queue_idx
  ON blockchain_deposits(status, confirmed_at, created_at)
  WHERE status = 'CONFIRMED';

ALTER TABLE lock_positions
  ADD COLUMN IF NOT EXISTS lock_days_snapshot INTEGER,
  ADD COLUMN IF NOT EXISTS source_blockchain_deposit_id TEXT REFERENCES blockchain_deposits(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS metadata JSONB NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE lock_positions
  DROP CONSTRAINT IF EXISTS lock_positions_lock_days_snapshot_check;
ALTER TABLE lock_positions
  ADD CONSTRAINT lock_positions_lock_days_snapshot_check CHECK (
    lock_days_snapshot IS NULL OR lock_days_snapshot BETWEEN 1 AND 3650
  );
CREATE UNIQUE INDEX IF NOT EXISTS lock_positions_blockchain_deposit_unique
  ON lock_positions(source_blockchain_deposit_id)
  WHERE source_blockchain_deposit_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS deposit_credit_settlements (
  id TEXT PRIMARY KEY,
  blockchain_deposit_id TEXT NOT NULL UNIQUE REFERENCES blockchain_deposits(id) ON DELETE RESTRICT,
  deposit_id TEXT NOT NULL UNIQUE REFERENCES deposits(id) ON DELETE RESTRICT,
  lock_position_id TEXT NOT NULL UNIQUE REFERENCES lock_positions(id) ON DELETE RESTRICT,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  amount NUMERIC(18,6) NOT NULL CHECK (amount > 0),
  lock_days_snapshot INTEGER NOT NULL CHECK (lock_days_snapshot BETWEEN 1 AND 3650),
  unlock_at TIMESTAMPTZ NOT NULL,
  vip_level_before INTEGER NOT NULL DEFAULT 0 CHECK (vip_level_before BETWEEN 0 AND 20),
  vip_level_after INTEGER NOT NULL DEFAULT 0 CHECK (vip_level_after BETWEEN 0 AND 20),
  level1_referral_reward NUMERIC(18,6) NOT NULL DEFAULT 0 CHECK (level1_referral_reward >= 0),
  level2_referral_reward NUMERIC(18,6) NOT NULL DEFAULT 0 CHECK (level2_referral_reward >= 0),
  wheel_spins_granted INTEGER NOT NULL DEFAULT 0 CHECK (wheel_spins_granted >= 0),
  principal_journal_id TEXT NOT NULL UNIQUE REFERENCES ledger_journals(id) ON DELETE RESTRICT,
  referral_journal_id TEXT UNIQUE REFERENCES ledger_journals(id) ON DELETE RESTRICT,
  status TEXT NOT NULL DEFAULT 'CREDITED' CHECK (status IN ('CREDITED','REVIEW_REQUIRED')),
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  credited_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS deposit_credit_settlements_user_created_idx
  ON deposit_credit_settlements(user_id, created_at DESC);

DROP TRIGGER IF EXISTS deposit_credit_settlements_updated_at ON deposit_credit_settlements;
CREATE TRIGGER deposit_credit_settlements_updated_at
BEFORE UPDATE ON deposit_credit_settlements
FOR EACH ROW EXECUTE FUNCTION shaye_set_updated_at();

CREATE TABLE IF NOT EXISTS user_notifications (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS user_notifications_user_created_idx
  ON user_notifications(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS user_notifications_user_unread_idx
  ON user_notifications(user_id, created_at DESC)
  WHERE read_at IS NULL;

-- Existing manual lock positions already have an exact unlock_at snapshot. Fill
-- the new descriptive column only where it can be calculated safely.
UPDATE lock_positions
SET lock_days_snapshot = GREATEST(
  1,
  ROUND(EXTRACT(EPOCH FROM (unlock_at - started_at)) / 86400.0)::int
)
WHERE lock_days_snapshot IS NULL;
