-- SHAYE stage 03: deterministic per-user BSC deposit addresses.
-- Only public addresses and derivation metadata are stored in PostgreSQL.
-- The account xpub is provided to the application through a Docker secret.
-- The mnemonic/private keys are never stored in PostgreSQL.

CREATE SEQUENCE IF NOT EXISTS blockchain_deposit_derivation_index_seq
  AS BIGINT
  MINVALUE 0
  START WITH 0
  INCREMENT BY 1
  NO CYCLE;

DO $$
DECLARE
  next_index BIGINT;
BEGIN
  SELECT COALESCE(MAX(derivation_index) + 1, 0)
  INTO next_index
  FROM blockchain_wallets
  WHERE purpose = 'DEPOSIT';

  PERFORM setval(
    'blockchain_deposit_derivation_index_seq',
    GREATEST(next_index, 0),
    FALSE
  );
END;
$$;

CREATE INDEX IF NOT EXISTS blockchain_wallets_fingerprint_status_idx
  ON blockchain_wallets(chain_id, key_fingerprint, status)
  WHERE purpose = 'DEPOSIT';

COMMENT ON SEQUENCE blockchain_deposit_derivation_index_seq IS
  'Allocates a unique non-negative derivation index for per-user BSC deposit addresses.';
