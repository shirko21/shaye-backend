ALTER TABLE withdrawals
  ALTER COLUMN network SET DEFAULT 'BEP20';

ALTER TABLE app_settings
  ALTER COLUMN platform_name SET DEFAULT 'SHAYE',
  ALTER COLUMN sandbox_mode SET DEFAULT FALSE;

UPDATE app_settings
SET platform_name = 'SHAYE',
    sandbox_mode = FALSE,
    deposit_network = COALESCE(NULLIF(deposit_network, ''), 'BEP20'),
    deposit_wallet_address = CASE
      WHEN deposit_wallet_address = '0x1111111111111111111111111111111111111111'
      THEN '0x0000000000000000000000000000000000000000'
      ELSE deposit_wallet_address
    END,
    updated_at = now()
WHERE id = 'default';
