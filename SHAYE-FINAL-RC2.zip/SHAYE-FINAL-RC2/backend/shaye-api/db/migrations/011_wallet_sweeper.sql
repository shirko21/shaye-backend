-- Stage 8: safe Testnet token sweeping from per-user deposit wallets.
-- Secrets remain outside PostgreSQL. The dedicated sweeper worker alone receives
-- the deposit-wallet mnemonic and gas-wallet private key through Docker secrets.

ALTER TABLE blockchain_settings
  ADD COLUMN IF NOT EXISTS sweep_worker_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS sweep_min_amount NUMERIC(36,18) NOT NULL DEFAULT 10 CHECK (sweep_min_amount > 0),
  ADD COLUMN IF NOT EXISTS sweep_discovery_batch_size INTEGER NOT NULL DEFAULT 50 CHECK (sweep_discovery_batch_size BETWEEN 1 AND 500),
  ADD COLUMN IF NOT EXISTS sweep_job_batch_size INTEGER NOT NULL DEFAULT 3 CHECK (sweep_job_batch_size BETWEEN 1 AND 25),
  ADD COLUMN IF NOT EXISTS sweep_max_concurrent INTEGER NOT NULL DEFAULT 1 CHECK (sweep_max_concurrent BETWEEN 1 AND 20),
  ADD COLUMN IF NOT EXISTS sweep_target_gas_bnb NUMERIC(36,18) NOT NULL DEFAULT 0.001 CHECK (sweep_target_gas_bnb > 0),
  ADD COLUMN IF NOT EXISTS sweep_gas_wallet_min_bnb_reserve NUMERIC(36,18) NOT NULL DEFAULT 0.05 CHECK (sweep_gas_wallet_min_bnb_reserve >= 0),
  ADD COLUMN IF NOT EXISTS sweep_pause_reason TEXT,
  ADD COLUMN IF NOT EXISTS sweep_paused_at TIMESTAMPTZ;

ALTER TABLE wallet_sweeps
  ADD COLUMN IF NOT EXISTS token_balance_at_detection_raw NUMERIC(78,0),
  ADD COLUMN IF NOT EXISTS gas_required_raw NUMERIC(78,0),
  ADD COLUMN IF NOT EXISTS gas_funding_nonce BIGINT,
  ADD COLUMN IF NOT EXISTS gas_funding_raw_transaction TEXT,
  ADD COLUMN IF NOT EXISTS gas_funding_block_number BIGINT,
  ADD COLUMN IF NOT EXISTS gas_funding_block_hash TEXT,
  ADD COLUMN IF NOT EXISTS gas_funding_confirmations INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS sweep_raw_transaction TEXT,
  ADD COLUMN IF NOT EXISTS sweep_block_number BIGINT,
  ADD COLUMN IF NOT EXISTS sweep_block_hash TEXT,
  ADD COLUMN IF NOT EXISTS sweep_confirmations INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS discovered_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS gas_broadcast_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS gas_confirmed_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS sweep_broadcast_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS sweep_confirmed_at TIMESTAMPTZ;

ALTER TABLE wallet_sweeps
  DROP CONSTRAINT IF EXISTS wallet_sweeps_status_check;
ALTER TABLE wallet_sweeps
  ADD CONSTRAINT wallet_sweeps_status_check CHECK (
    status IN (
      'QUEUED','DISCOVERED','GAS_REQUIRED','GAS_SIGNING','GAS_SENT','GAS_CONFIRMING',
      'TOKEN_SIGNING','BROADCASTED','CONFIRMING','COMPLETED','FAILED',
      'REVIEW_REQUIRED','CANCELLED'
    )
  );

ALTER TABLE wallet_sweeps
  DROP CONSTRAINT IF EXISTS wallet_sweeps_gas_funding_nonce_check;
ALTER TABLE wallet_sweeps
  ADD CONSTRAINT wallet_sweeps_gas_funding_nonce_check CHECK (
    gas_funding_nonce IS NULL OR gas_funding_nonce >= 0
  );
ALTER TABLE wallet_sweeps
  DROP CONSTRAINT IF EXISTS wallet_sweeps_gas_funding_block_number_check;
ALTER TABLE wallet_sweeps
  ADD CONSTRAINT wallet_sweeps_gas_funding_block_number_check CHECK (
    gas_funding_block_number IS NULL OR gas_funding_block_number >= 0
  );
ALTER TABLE wallet_sweeps
  DROP CONSTRAINT IF EXISTS wallet_sweeps_sweep_block_number_check;
ALTER TABLE wallet_sweeps
  ADD CONSTRAINT wallet_sweeps_sweep_block_number_check CHECK (
    sweep_block_number IS NULL OR sweep_block_number >= 0
  );
ALTER TABLE wallet_sweeps
  DROP CONSTRAINT IF EXISTS wallet_sweeps_gas_funding_confirmations_check;
ALTER TABLE wallet_sweeps
  ADD CONSTRAINT wallet_sweeps_gas_funding_confirmations_check CHECK (
    gas_funding_confirmations >= 0
  );
ALTER TABLE wallet_sweeps
  DROP CONSTRAINT IF EXISTS wallet_sweeps_sweep_confirmations_check;
ALTER TABLE wallet_sweeps
  ADD CONSTRAINT wallet_sweeps_sweep_confirmations_check CHECK (
    sweep_confirmations >= 0
  );

CREATE UNIQUE INDEX IF NOT EXISTS wallet_sweeps_active_wallet_unique
  ON wallet_sweeps(wallet_id)
  WHERE status NOT IN ('COMPLETED','FAILED','REVIEW_REQUIRED','CANCELLED');

DROP INDEX IF EXISTS wallet_sweeps_queue_idx;
CREATE INDEX IF NOT EXISTS wallet_sweeps_queue_idx
  ON wallet_sweeps(status, next_attempt_at, created_at)
  WHERE status IN (
    'QUEUED','DISCOVERED','GAS_REQUIRED','GAS_SIGNING','GAS_SENT','GAS_CONFIRMING',
    'TOKEN_SIGNING','BROADCASTED','CONFIRMING','FAILED'
  );

CREATE INDEX IF NOT EXISTS wallet_sweeps_gas_tx_lookup_idx
  ON wallet_sweeps(chain_id, lower(gas_funding_tx_hash))
  WHERE gas_funding_tx_hash IS NOT NULL;
CREATE INDEX IF NOT EXISTS wallet_sweeps_token_tx_lookup_idx
  ON wallet_sweeps(chain_id, lower(sweep_tx_hash))
  WHERE sweep_tx_hash IS NOT NULL;

-- Explicit activation is required after Testnet secrets and addresses are prepared.
UPDATE blockchain_settings
SET sweeps_enabled = FALSE,
    sweep_worker_enabled = FALSE,
    sweep_pause_reason = COALESCE(sweep_pause_reason, 'Stage 8 requires explicit Testnet activation'),
    sweep_paused_at = COALESCE(sweep_paused_at, now()),
    updated_at = now()
WHERE id = 'default';
