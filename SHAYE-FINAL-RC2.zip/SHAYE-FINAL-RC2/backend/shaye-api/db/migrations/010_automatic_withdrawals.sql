-- Stage 7: configurable limited automatic Testnet withdrawals.
-- Small withdrawals may bypass manager approval only while all safety limits pass.

ALTER TABLE blockchain_settings
  ADD COLUMN IF NOT EXISTS auto_withdrawals_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS auto_withdrawal_max_amount NUMERIC(36,18) NOT NULL DEFAULT 50,
  ADD COLUMN IF NOT EXISTS auto_withdrawal_daily_limit NUMERIC(36,18) NOT NULL DEFAULT 500,
  ADD COLUMN IF NOT EXISTS auto_withdrawal_daily_count_limit INTEGER NOT NULL DEFAULT 20,
  ADD COLUMN IF NOT EXISTS auto_withdrawal_max_concurrent INTEGER NOT NULL DEFAULT 3,
  ADD COLUMN IF NOT EXISTS hot_wallet_min_token_reserve NUMERIC(36,18) NOT NULL DEFAULT 10,
  ADD COLUMN IF NOT EXISTS hot_wallet_min_bnb_reserve NUMERIC(36,18) NOT NULL DEFAULT 0.01,
  ADD COLUMN IF NOT EXISTS auto_withdrawal_pause_reason TEXT,
  ADD COLUMN IF NOT EXISTS auto_withdrawal_paused_at TIMESTAMPTZ;

ALTER TABLE blockchain_settings
  DROP CONSTRAINT IF EXISTS blockchain_settings_auto_withdrawal_limits_check;
ALTER TABLE blockchain_settings
  ADD CONSTRAINT blockchain_settings_auto_withdrawal_limits_check CHECK (
    auto_withdrawal_max_amount >= 0
    AND auto_withdrawal_daily_limit >= 0
    AND auto_withdrawal_daily_count_limit BETWEEN 1 AND 100000
    AND auto_withdrawal_max_concurrent BETWEEN 1 AND 100
    AND hot_wallet_min_token_reserve >= 0
    AND hot_wallet_min_bnb_reserve >= 0
  );

ALTER TABLE withdrawals
  ADD COLUMN IF NOT EXISTS approval_mode TEXT NOT NULL DEFAULT 'MANUAL',
  ADD COLUMN IF NOT EXISTS auto_approved_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS auto_approval_reason TEXT,
  ADD COLUMN IF NOT EXISTS auto_budget_date_key TEXT;

ALTER TABLE withdrawals
  DROP CONSTRAINT IF EXISTS withdrawals_approval_mode_check;
ALTER TABLE withdrawals
  ADD CONSTRAINT withdrawals_approval_mode_check CHECK (
    approval_mode IN ('MANUAL','AUTOMATIC')
  );

ALTER TABLE withdrawals
  DROP CONSTRAINT IF EXISTS withdrawals_auto_approval_consistency_check;
ALTER TABLE withdrawals
  ADD CONSTRAINT withdrawals_auto_approval_consistency_check CHECK (
    (approval_mode = 'MANUAL') OR
    (approval_mode = 'AUTOMATIC' AND auto_approved_at IS NOT NULL)
  );

ALTER TABLE blockchain_withdrawals
  ADD COLUMN IF NOT EXISTS approval_mode TEXT NOT NULL DEFAULT 'MANUAL',
  ADD COLUMN IF NOT EXISTS auto_approved_at TIMESTAMPTZ;

ALTER TABLE blockchain_withdrawals
  DROP CONSTRAINT IF EXISTS blockchain_withdrawals_approval_mode_check;
ALTER TABLE blockchain_withdrawals
  ADD CONSTRAINT blockchain_withdrawals_approval_mode_check CHECK (
    approval_mode IN ('MANUAL','AUTOMATIC')
  );

CREATE TABLE IF NOT EXISTS withdrawal_auto_daily_usage (
  date_key TEXT PRIMARY KEY,
  total_amount NUMERIC(36,18) NOT NULL DEFAULT 0 CHECK (total_amount >= 0),
  request_count INTEGER NOT NULL DEFAULT 0 CHECK (request_count >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

DROP TRIGGER IF EXISTS withdrawal_auto_daily_usage_updated_at ON withdrawal_auto_daily_usage;
CREATE TRIGGER withdrawal_auto_daily_usage_updated_at
BEFORE UPDATE ON withdrawal_auto_daily_usage
FOR EACH ROW EXECUTE FUNCTION shaye_set_updated_at();

CREATE INDEX IF NOT EXISTS withdrawals_auto_mode_created_idx
  ON withdrawals(approval_mode, created_at DESC);
CREATE INDEX IF NOT EXISTS blockchain_withdrawals_auto_active_idx
  ON blockchain_withdrawals(approval_mode, status, created_at)
  WHERE approval_mode = 'AUTOMATIC'
    AND status IN ('QUEUED','RESERVED','SIGNING','BROADCASTED','CONFIRMING','CONFIRMED');

-- Keep stage 7 disabled until the administrator deliberately enables it on Testnet.
UPDATE blockchain_settings
SET auto_withdrawals_enabled = FALSE,
    auto_withdrawal_pause_reason = COALESCE(auto_withdrawal_pause_reason, 'Stage 7 requires explicit Testnet activation')
WHERE id = 'default';
