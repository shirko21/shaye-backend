-- SHAYE stage 04: automatic BSC token deposit detection and confirmation.
-- This stage is read-only on-chain. It never signs or broadcasts transactions.

CREATE TABLE IF NOT EXISTS blockchain_worker_status (
  worker_name TEXT PRIMARY KEY,
  instance_id TEXT,
  status TEXT NOT NULL DEFAULT 'STOPPED' CHECK (
    status IN ('STOPPED','STARTING','IDLE','SCANNING','HEALTHY','PAUSED','ERROR')
  ),
  chain_id BIGINT,
  token_contract TEXT,
  latest_chain_block BIGINT CHECK (latest_chain_block IS NULL OR latest_chain_block >= 0),
  last_scanned_block BIGINT CHECK (last_scanned_block IS NULL OR last_scanned_block >= 0),
  last_finalized_block BIGINT CHECK (last_finalized_block IS NULL OR last_finalized_block >= 0),
  detected_events BIGINT NOT NULL DEFAULT 0 CHECK (detected_events >= 0),
  confirmed_events BIGINT NOT NULL DEFAULT 0 CHECK (confirmed_events >= 0),
  orphaned_events BIGINT NOT NULL DEFAULT 0 CHECK (orphaned_events >= 0),
  last_cycle_started_at TIMESTAMPTZ,
  last_cycle_completed_at TIMESTAMPTZ,
  heartbeat_at TIMESTAMPTZ,
  last_error TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT blockchain_worker_status_token_check CHECK (
    token_contract IS NULL OR token_contract ~ '^0x[0-9A-Fa-f]{40}$'
  )
);

DROP TRIGGER IF EXISTS blockchain_worker_status_updated_at ON blockchain_worker_status;
CREATE TRIGGER blockchain_worker_status_updated_at
BEFORE UPDATE ON blockchain_worker_status
FOR EACH ROW EXECUTE FUNCTION shaye_set_updated_at();

CREATE INDEX IF NOT EXISTS blockchain_wallets_active_deposit_address_idx
  ON blockchain_wallets(chain_id, lower(address))
  WHERE purpose = 'DEPOSIT' AND status = 'ACTIVE';

CREATE INDEX IF NOT EXISTS blockchain_deposits_confirmation_queue_idx
  ON blockchain_deposits(chain_id, status, block_number)
  WHERE status IN ('DETECTED','CONFIRMING','CONFIRMED');

CREATE INDEX IF NOT EXISTS blockchain_deposits_block_hash_idx
  ON blockchain_deposits(chain_id, block_number, lower(block_hash));

COMMENT ON TABLE blockchain_worker_status IS
  'Operational heartbeat and progress summary for blockchain workers. No secret material is stored here.';
