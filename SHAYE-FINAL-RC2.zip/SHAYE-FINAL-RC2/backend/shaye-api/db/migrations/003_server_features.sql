ALTER TABLE users
  ADD COLUMN IF NOT EXISTS wallet_address TEXT,
  ADD COLUMN IF NOT EXISTS wheel_spins INTEGER NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS wheel_spins_used INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS last_seen_at TIMESTAMPTZ;

ALTER TABLE users
  DROP CONSTRAINT IF EXISTS users_wheel_spins_nonnegative;
ALTER TABLE users
  ADD CONSTRAINT users_wheel_spins_nonnegative CHECK (
    wheel_spins >= 0 AND wheel_spins_used >= 0
  );

ALTER TABLE app_settings
  DROP CONSTRAINT IF EXISTS app_settings_sandbox_mode_check;
ALTER TABLE app_settings
  ADD COLUMN IF NOT EXISTS funding_mode TEXT NOT NULL DEFAULT 'MANUAL',
  ADD COLUMN IF NOT EXISTS deposit_wallet_address TEXT NOT NULL DEFAULT '0x0000000000000000000000000000000000000000',
  ADD COLUMN IF NOT EXISTS deposit_network TEXT NOT NULL DEFAULT 'BEP20';

ALTER TABLE app_settings
  DROP CONSTRAINT IF EXISTS app_settings_funding_mode_check;
ALTER TABLE app_settings
  ADD CONSTRAINT app_settings_funding_mode_check CHECK (
    funding_mode IN ('MANUAL','BLOCKCHAIN')
  );

CREATE TABLE IF NOT EXISTS wheel_settings (
  id TEXT PRIMARY KEY DEFAULT 'default',
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  spin_duration_ms INTEGER NOT NULL DEFAULT 4500 CHECK(spin_duration_ms BETWEEN 1000 AND 30000),
  registration_spins INTEGER NOT NULL DEFAULT 1 CHECK(registration_spins BETWEEN 0 AND 1000),
  referral_spins INTEGER NOT NULL DEFAULT 1 CHECK(referral_spins BETWEEN 0 AND 1000),
  notice TEXT NOT NULL DEFAULT 'هر فرصت فقط یک بار قابل استفاده است.',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS wheel_prizes (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  subtitle TEXT,
  amount NUMERIC(18,6) NOT NULL DEFAULT 0 CHECK(amount >= 0),
  weight NUMERIC(18,6) NOT NULL DEFAULT 0 CHECK(weight >= 0),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS wheel_history (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  prize_id TEXT REFERENCES wheel_prizes(id) ON DELETE SET NULL,
  reward_amount NUMERIC(18,6) NOT NULL DEFAULT 0 CHECK(reward_amount >= 0),
  reward_text TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'COMPLETED' CHECK(status IN ('COMPLETED','FAILED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS wheel_history_user_created_idx ON wheel_history(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS wheel_history_created_idx ON wheel_history(created_at DESC);

CREATE TABLE IF NOT EXISTS support_messages (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  sender_role TEXT NOT NULL CHECK(sender_role IN ('USER','ADMIN')),
  body TEXT NOT NULL,
  read_by_user BOOLEAN NOT NULL DEFAULT FALSE,
  read_by_admin BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS support_messages_user_created_idx ON support_messages(user_id, created_at);
CREATE INDEX IF NOT EXISTS support_messages_admin_unread_idx ON support_messages(read_by_admin, created_at DESC);

CREATE TABLE IF NOT EXISTS home_content (
  id TEXT PRIMARY KEY DEFAULT 'default',
  content JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO wheel_settings(id) VALUES('default') ON CONFLICT(id) DO NOTHING;
INSERT INTO home_content(id, content) VALUES('default', '{"companyName":"SHAYE","intro":"","address":"","phone":"","email":"","website":"","logo":"","officeImage":"","licenseImage":"","banners":[],"news":[],"licenses":[],"documents":[]}'::jsonb) ON CONFLICT(id) DO NOTHING;

INSERT INTO wheel_prizes(id,title,subtitle,amount,weight,is_active,sort_order)
VALUES
  ('default-05','0.5 USDT','پاداش نقدی',0.5,100,TRUE,1),
  ('default-10','10 USDT','پاداش ویژه',10,0,TRUE,2),
  ('default-bike','دوچرخه','معادل 100 USDT',100,0,TRUE,3),
  ('default-phone','گوشی هوشمند','معادل 300 USDT',300,0,TRUE,4),
  ('default-home','لوازم خانگی','معادل 500 USDT',500,0,TRUE,5)
ON CONFLICT(id) DO NOTHING;
