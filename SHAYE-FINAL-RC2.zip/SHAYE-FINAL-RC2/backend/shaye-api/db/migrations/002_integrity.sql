CREATE UNIQUE INDEX IF NOT EXISTS deposits_tx_hash_unique
  ON deposits (lower(tx_hash))
  WHERE tx_hash IS NOT NULL AND btrim(tx_hash) <> '';

ALTER TABLE users
  DROP CONSTRAINT IF EXISTS users_balances_nonnegative;
ALTER TABLE users
  ADD CONSTRAINT users_balances_nonnegative CHECK (
    deposit_balance >= 0 AND
    profit_balance >= 0 AND
    locked_balance >= 0 AND
    total_deposit >= 0 AND
    total_withdraw >= 0 AND
    total_profit >= 0 AND
    referral_profit >= 0
  );

ALTER TABLE vip_tiers
  DROP CONSTRAINT IF EXISTS vip_tiers_values_nonnegative;
ALTER TABLE vip_tiers
  ADD CONSTRAINT vip_tiers_values_nonnegative CHECK (
    level > 0 AND
    min_locked >= 0 AND
    min_withdrawal >= 0
  );

ALTER TABLE app_settings
  DROP CONSTRAINT IF EXISTS app_settings_values_valid;
ALTER TABLE app_settings
  ADD CONSTRAINT app_settings_values_valid CHECK (
    min_deposit > 0 AND
    min_withdrawal > 0 AND
    lock_days > 0 AND
    task_hour BETWEEN 0 AND 23
  );

CREATE INDEX IF NOT EXISTS task_claims_user_created_idx
  ON task_claims(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS admin_action_logs_actor_created_idx
  ON admin_action_logs(actor_id, created_at DESC);
