CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  invite_code TEXT NOT NULL UNIQUE,
  referred_by_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  role TEXT NOT NULL DEFAULT 'USER' CHECK (role IN ('USER','ADMIN')),
  vip_level INTEGER NOT NULL DEFAULT 0,
  deposit_balance NUMERIC(18,6) NOT NULL DEFAULT 0,
  profit_balance NUMERIC(18,6) NOT NULL DEFAULT 0,
  locked_balance NUMERIC(18,6) NOT NULL DEFAULT 0,
  total_deposit NUMERIC(18,6) NOT NULL DEFAULT 0,
  total_withdraw NUMERIC(18,6) NOT NULL DEFAULT 0,
  total_profit NUMERIC(18,6) NOT NULL DEFAULT 0,
  referral_profit NUMERIC(18,6) NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS users_referrer_idx ON users(referred_by_id);
CREATE INDEX IF NOT EXISTS users_role_active_idx ON users(role,is_active);

CREATE TABLE IF NOT EXISTS deposits (
  id TEXT PRIMARY KEY,
  amount NUMERIC(18,6) NOT NULL CHECK(amount > 0),
  reference_code TEXT NOT NULL UNIQUE,
  tx_hash TEXT,
  status TEXT NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','APPROVED','REJECTED')),
  note TEXT,
  reviewed_by TEXT,
  reviewed_at TIMESTAMPTZ,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS deposits_user_status_idx ON deposits(user_id,status);
CREATE INDEX IF NOT EXISTS deposits_created_idx ON deposits(created_at DESC);

CREATE TABLE IF NOT EXISTS lock_positions (
  id TEXT PRIMARY KEY,
  amount NUMERIC(18,6) NOT NULL CHECK(amount > 0),
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE','RELEASED')),
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  unlock_at TIMESTAMPTZ NOT NULL,
  released_at TIMESTAMPTZ,
  source_deposit_id TEXT UNIQUE REFERENCES deposits(id) ON DELETE SET NULL,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS locks_user_status_unlock_idx ON lock_positions(user_id,status,unlock_at);

CREATE TABLE IF NOT EXISTS withdrawals (
  id TEXT PRIMARY KEY,
  amount NUMERIC(18,6) NOT NULL CHECK(amount > 0),
  wallet_address TEXT NOT NULL,
  network TEXT NOT NULL DEFAULT 'BEP20-SANDBOX',
  request_date_key TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','APPROVED','REJECTED')),
  note TEXT,
  reviewed_by TEXT,
  reviewed_at TIMESTAMPTZ,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id,request_date_key)
);
CREATE INDEX IF NOT EXISTS withdrawals_user_status_idx ON withdrawals(user_id,status);
CREATE INDEX IF NOT EXISTS withdrawals_created_idx ON withdrawals(created_at DESC);

CREATE TABLE IF NOT EXISTS transactions (
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL,
  amount NUMERIC(18,6) NOT NULL,
  description TEXT,
  metadata JSONB,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS transactions_user_created_idx ON transactions(user_id,created_at DESC);

CREATE TABLE IF NOT EXISTS task_claims (
  id TEXT PRIMARY KEY,
  claim_date_key TEXT NOT NULL,
  base_amount NUMERIC(18,6) NOT NULL,
  rate NUMERIC(8,4) NOT NULL,
  reward NUMERIC(18,6) NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id,claim_date_key)
);

CREATE TABLE IF NOT EXISTS vip_tiers (
  id TEXT PRIMARY KEY,
  level INTEGER NOT NULL UNIQUE,
  label TEXT NOT NULL,
  min_locked NUMERIC(18,6) NOT NULL,
  daily_rate NUMERIC(8,4) NOT NULL CHECK(daily_rate >= 0 AND daily_rate <= 25),
  min_withdrawal NUMERIC(18,6) NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS app_settings (
  id TEXT PRIMARY KEY DEFAULT 'default',
  platform_name TEXT NOT NULL DEFAULT 'SHAYE Sandbox',
  sandbox_mode BOOLEAN NOT NULL DEFAULT TRUE CHECK(sandbox_mode = TRUE),
  min_deposit NUMERIC(18,6) NOT NULL DEFAULT 10,
  min_withdrawal NUMERIC(18,6) NOT NULL DEFAULT 2.5,
  lock_days INTEGER NOT NULL DEFAULT 30 CHECK(lock_days > 0),
  level1_referral_rate NUMERIC(8,4) NOT NULL DEFAULT 12 CHECK(level1_referral_rate BETWEEN 0 AND 25),
  level2_referral_rate NUMERIC(8,4) NOT NULL DEFAULT 4 CHECK(level2_referral_rate BETWEEN 0 AND 25),
  task_hour INTEGER NOT NULL DEFAULT 16 CHECK(task_hour BETWEEN 0 AND 23),
  timezone TEXT NOT NULL DEFAULT 'Asia/Tehran',
  maintenance_mode BOOLEAN NOT NULL DEFAULT FALSE,
  support_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS announcements (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  image_url TEXT,
  action_text TEXT,
  action_url TEXT,
  priority INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS announcements_active_priority_idx ON announcements(is_active,priority DESC);

CREATE TABLE IF NOT EXISTS admin_action_logs (
  id TEXT PRIMARY KEY,
  action TEXT NOT NULL,
  target_type TEXT,
  target_id TEXT,
  metadata JSONB,
  actor_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
