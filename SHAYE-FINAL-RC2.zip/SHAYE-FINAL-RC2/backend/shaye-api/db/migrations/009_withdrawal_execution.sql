-- Stage 6: manager-approved Testnet withdrawals and one-time first-VIP wheel grants.
-- The application service never receives the hot-wallet private key. Only the
-- dedicated withdrawal worker mounts that Docker secret.

ALTER TABLE blockchain_settings
  ADD COLUMN IF NOT EXISTS withdrawal_worker_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS withdrawal_approval_required BOOLEAN NOT NULL DEFAULT TRUE;

-- The stage-6 product rule allows exactly one referral chance per qualifying
-- direct invitee. The existing field remains as a simple 0/1 enable switch.
UPDATE wheel_settings SET referral_spins = 1 WHERE referral_spins > 1;
ALTER TABLE wheel_settings
  DROP CONSTRAINT IF EXISTS wheel_settings_referral_spins_check;
ALTER TABLE wheel_settings
  ADD CONSTRAINT wheel_settings_referral_spins_check
  CHECK (referral_spins BETWEEN 0 AND 1);

ALTER TABLE withdrawals
  ADD COLUMN IF NOT EXISTS blockchain_withdrawal_id TEXT,
  ADD COLUMN IF NOT EXISTS tx_hash TEXT,
  ADD COLUMN IF NOT EXISTS confirmations INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS failure_reason TEXT,
  ADD COLUMN IF NOT EXISTS reserved_journal_id TEXT REFERENCES ledger_journals(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS completion_journal_id TEXT REFERENCES ledger_journals(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS refund_journal_id TEXT REFERENCES ledger_journals(id) ON DELETE SET NULL;

ALTER TABLE withdrawals
  DROP CONSTRAINT IF EXISTS withdrawals_tx_hash_check;
ALTER TABLE withdrawals
  ADD CONSTRAINT withdrawals_tx_hash_check CHECK (
    tx_hash IS NULL OR tx_hash ~ '^0x[0-9A-Fa-f]{64}$'
  );

ALTER TABLE withdrawals
  DROP CONSTRAINT IF EXISTS withdrawals_confirmations_check;
ALTER TABLE withdrawals
  ADD CONSTRAINT withdrawals_confirmations_check CHECK (confirmations >= 0);

ALTER TABLE withdrawals
  DROP CONSTRAINT IF EXISTS withdrawals_status_check;
ALTER TABLE withdrawals
  ADD CONSTRAINT withdrawals_status_check CHECK (
    status IN (
      'PENDING','RESERVED','PROCESSING','BROADCASTED','CONFIRMING',
      'APPROVED','COMPLETED','FAILED','REVIEW_REQUIRED',
      'REJECTED','CANCELLED'
    )
  );

ALTER TABLE blockchain_withdrawals
  ADD COLUMN IF NOT EXISTS raw_transaction TEXT,
  ADD COLUMN IF NOT EXISTS gas_limit NUMERIC(78,0),
  ADD COLUMN IF NOT EXISTS gas_price_raw NUMERIC(78,0),
  ADD COLUMN IF NOT EXISTS approved_by TEXT REFERENCES users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS approved_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS reservation_journal_id TEXT REFERENCES ledger_journals(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS completion_journal_id TEXT REFERENCES ledger_journals(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS refund_journal_id TEXT REFERENCES ledger_journals(id) ON DELETE SET NULL;

ALTER TABLE blockchain_withdrawals
  DROP CONSTRAINT IF EXISTS blockchain_withdrawals_status_check;
ALTER TABLE blockchain_withdrawals
  ADD CONSTRAINT blockchain_withdrawals_status_check CHECK (
    status IN (
      'AWAITING_APPROVAL','QUEUED','RESERVED','SIGNING','BROADCASTED',
      'CONFIRMING','CONFIRMED','COMPLETED','FAILED','REVIEW_REQUIRED',
      'CANCELLED','REPLACED'
    )
  );

ALTER TABLE blockchain_withdrawals
  DROP CONSTRAINT IF EXISTS blockchain_withdrawals_raw_transaction_check;
ALTER TABLE blockchain_withdrawals
  ADD CONSTRAINT blockchain_withdrawals_raw_transaction_check CHECK (
    raw_transaction IS NULL OR raw_transaction ~ '^0x[0-9A-Fa-f]+$'
  );

ALTER TABLE blockchain_withdrawals
  DROP CONSTRAINT IF EXISTS blockchain_withdrawals_gas_values_check;
ALTER TABLE blockchain_withdrawals
  ADD CONSTRAINT blockchain_withdrawals_gas_values_check CHECK (
    (gas_limit IS NULL OR gas_limit > 0)
    AND (gas_price_raw IS NULL OR gas_price_raw > 0)
  );

CREATE UNIQUE INDEX IF NOT EXISTS blockchain_withdrawals_sender_nonce_unique
  ON blockchain_withdrawals(chain_id, lower(sender_address), nonce)
  WHERE sender_address IS NOT NULL
    AND nonce IS NOT NULL
    AND status NOT IN ('CANCELLED');

ALTER TABLE withdrawals
  DROP CONSTRAINT IF EXISTS withdrawals_blockchain_withdrawal_fk;
ALTER TABLE withdrawals
  ADD CONSTRAINT withdrawals_blockchain_withdrawal_fk
  FOREIGN KEY (blockchain_withdrawal_id)
  REFERENCES blockchain_withdrawals(id)
  ON DELETE SET NULL;

CREATE UNIQUE INDEX IF NOT EXISTS withdrawals_blockchain_withdrawal_unique
  ON withdrawals(blockchain_withdrawal_id)
  WHERE blockchain_withdrawal_id IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS withdrawals_tx_hash_unique
  ON withdrawals(lower(tx_hash))
  WHERE tx_hash IS NOT NULL;

CREATE TABLE IF NOT EXISTS referral_wheel_grants (
  id TEXT PRIMARY KEY,
  inviter_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  invitee_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  blockchain_deposit_id TEXT REFERENCES blockchain_deposits(id) ON DELETE SET NULL,
  source_deposit_id TEXT REFERENCES deposits(id) ON DELETE SET NULL,
  deposit_credit_settlement_id TEXT REFERENCES deposit_credit_settlements(id) ON DELETE SET NULL,
  vip_level_before INTEGER NOT NULL DEFAULT 0 CHECK (vip_level_before BETWEEN 0 AND 20),
  vip_level_after INTEGER NOT NULL CHECK (vip_level_after BETWEEN 1 AND 20),
  spins_granted INTEGER NOT NULL CHECK (spins_granted = 1),
  reason TEXT NOT NULL DEFAULT 'FIRST_VIP_ACTIVATION',
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT referral_wheel_grants_distinct_users_check CHECK (inviter_id <> invitee_id)
);

CREATE UNIQUE INDEX IF NOT EXISTS referral_wheel_grants_invitee_unique
  ON referral_wheel_grants(invitee_id);
CREATE UNIQUE INDEX IF NOT EXISTS referral_wheel_grants_pair_unique
  ON referral_wheel_grants(inviter_id, invitee_id);
CREATE INDEX IF NOT EXISTS referral_wheel_grants_inviter_created_idx
  ON referral_wheel_grants(inviter_id, created_at DESC);

ALTER TABLE deposit_credit_settlements
  ADD COLUMN IF NOT EXISTS wheel_grant_id TEXT REFERENCES referral_wheel_grants(id) ON DELETE SET NULL;

-- Conservative legacy marker: mark only the earliest settlement that actually
-- crossed VIP0 to VIP1+ so later deposits cannot grant another chance. Stage 5
-- deployments should still be audited manually for any older non-qualifying spins.
WITH earliest AS (
  SELECT DISTINCT ON (s.user_id)
         s.id AS settlement_id,
         s.user_id AS invitee_id,
         u.referred_by_id AS inviter_id,
         s.blockchain_deposit_id,
         s.vip_level_before,
         GREATEST(s.vip_level_after, 1) AS vip_level_after,
         s.wheel_spins_granted,
         s.credited_at
  FROM deposit_credit_settlements s
  JOIN users u ON u.id = s.user_id
  WHERE s.wheel_spins_granted > 0
    AND s.vip_level_before = 0
    AND s.vip_level_after >= 1
    AND u.referred_by_id IS NOT NULL
  ORDER BY s.user_id, s.credited_at ASC, s.id ASC
), inserted AS (
  INSERT INTO referral_wheel_grants(
    id, inviter_id, invitee_id, blockchain_deposit_id,
    deposit_credit_settlement_id, vip_level_before, vip_level_after,
    spins_granted, metadata, created_at
  )
  SELECT
    md5(random()::text || clock_timestamp()::text || settlement_id),
    inviter_id, invitee_id, blockchain_deposit_id,
    settlement_id, vip_level_before, vip_level_after,
    1, '{"legacyStage5":true}'::jsonb, credited_at
  FROM earliest
  ON CONFLICT(invitee_id) DO NOTHING
  RETURNING id, deposit_credit_settlement_id
)
UPDATE deposit_credit_settlements s
SET wheel_grant_id = i.id
FROM inserted i
WHERE s.id = i.deposit_credit_settlement_id;
