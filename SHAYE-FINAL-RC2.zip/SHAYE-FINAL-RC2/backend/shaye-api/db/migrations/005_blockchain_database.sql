-- SHAYE blockchain persistence and double-entry ledger foundation.
-- This migration intentionally stores public addresses and chain metadata only.
-- Seed phrases, private keys and keystore payloads must never be stored here.

CREATE OR REPLACE FUNCTION shaye_set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TABLE IF NOT EXISTS blockchain_settings (
  id TEXT PRIMARY KEY DEFAULT 'default',
  network TEXT NOT NULL DEFAULT 'testnet' CHECK (network IN ('testnet','mainnet')),
  chain_id BIGINT NOT NULL DEFAULT 97 CHECK (chain_id > 0),
  token_contract TEXT,
  token_symbol TEXT NOT NULL DEFAULT 'USDT',
  token_decimals INTEGER NOT NULL DEFAULT 18 CHECK (token_decimals BETWEEN 0 AND 255),
  required_confirmations INTEGER NOT NULL DEFAULT 12 CHECK (required_confirmations BETWEEN 1 AND 10000),
  reorg_buffer_blocks INTEGER NOT NULL DEFAULT 24 CHECK (reorg_buffer_blocks BETWEEN 1 AND 10000),
  scan_batch_size INTEGER NOT NULL DEFAULT 500 CHECK (scan_batch_size BETWEEN 1 AND 5000),
  deposits_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  withdrawals_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  sweeps_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  emergency_stop BOOLEAN NOT NULL DEFAULT TRUE,
  emergency_reason TEXT,
  updated_by TEXT REFERENCES users(id) ON DELETE SET NULL,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT blockchain_settings_token_address_check CHECK (
    token_contract IS NULL OR token_contract ~ '^0x[0-9A-Fa-f]{40}$'
  ),
  CONSTRAINT blockchain_settings_network_chain_check CHECK (
    (network = 'testnet' AND chain_id = 97) OR
    (network = 'mainnet' AND chain_id = 56)
  )
);

INSERT INTO blockchain_settings(id)
VALUES ('default')
ON CONFLICT (id) DO NOTHING;

DROP TRIGGER IF EXISTS blockchain_settings_updated_at ON blockchain_settings;
CREATE TRIGGER blockchain_settings_updated_at
BEFORE UPDATE ON blockchain_settings
FOR EACH ROW EXECUTE FUNCTION shaye_set_updated_at();

CREATE TABLE IF NOT EXISTS blockchain_wallets (
  id TEXT PRIMARY KEY,
  user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
  purpose TEXT NOT NULL DEFAULT 'DEPOSIT' CHECK (purpose IN ('DEPOSIT','HOT','TREASURY','GAS')),
  chain_id BIGINT NOT NULL CHECK (chain_id > 0),
  address TEXT NOT NULL,
  derivation_index BIGINT,
  derivation_path TEXT,
  key_fingerprint TEXT,
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','DISABLED','ARCHIVED')),
  assigned_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  disabled_at TIMESTAMPTZ,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT blockchain_wallets_address_check CHECK (address ~ '^0x[0-9A-Fa-f]{40}$'),
  CONSTRAINT blockchain_wallets_derivation_index_check CHECK (
    derivation_index IS NULL OR derivation_index >= 0
  ),
  CONSTRAINT blockchain_wallets_owner_check CHECK (
    (purpose = 'DEPOSIT' AND user_id IS NOT NULL) OR
    (purpose <> 'DEPOSIT' AND user_id IS NULL)
  ),
  CONSTRAINT blockchain_wallets_deposit_derivation_check CHECK (
    purpose <> 'DEPOSIT' OR (
      derivation_index IS NOT NULL AND
      derivation_path IS NOT NULL AND
      key_fingerprint IS NOT NULL
    )
  )
);

CREATE UNIQUE INDEX IF NOT EXISTS blockchain_wallets_chain_address_unique
  ON blockchain_wallets(chain_id, lower(address));
CREATE UNIQUE INDEX IF NOT EXISTS blockchain_wallets_user_deposit_unique
  ON blockchain_wallets(user_id, chain_id, purpose)
  WHERE purpose = 'DEPOSIT' AND status <> 'ARCHIVED';
CREATE UNIQUE INDEX IF NOT EXISTS blockchain_wallets_derivation_unique
  ON blockchain_wallets(
    chain_id,
    COALESCE(key_fingerprint, ''),
    derivation_index
  )
  WHERE purpose = 'DEPOSIT' AND derivation_index IS NOT NULL;
CREATE INDEX IF NOT EXISTS blockchain_wallets_user_status_idx
  ON blockchain_wallets(user_id, status);

DROP TRIGGER IF EXISTS blockchain_wallets_updated_at ON blockchain_wallets;
CREATE TRIGGER blockchain_wallets_updated_at
BEFORE UPDATE ON blockchain_wallets
FOR EACH ROW EXECUTE FUNCTION shaye_set_updated_at();

COMMENT ON TABLE blockchain_wallets IS
  'Public blockchain addresses and derivation metadata only. Never store private keys, seed phrases or keystore secrets.';
COMMENT ON COLUMN blockchain_wallets.key_fingerprint IS
  'Optional public fingerprint for key-version identification; it must not contain secret key material.';

CREATE TABLE IF NOT EXISTS blockchain_deposits (
  id TEXT PRIMARY KEY,
  deposit_id TEXT UNIQUE REFERENCES deposits(id) ON DELETE SET NULL,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  wallet_id TEXT NOT NULL REFERENCES blockchain_wallets(id) ON DELETE RESTRICT,
  chain_id BIGINT NOT NULL CHECK (chain_id > 0),
  token_contract TEXT NOT NULL,
  tx_hash TEXT NOT NULL,
  log_index INTEGER NOT NULL CHECK (log_index >= 0),
  block_number BIGINT NOT NULL CHECK (block_number >= 0),
  block_hash TEXT NOT NULL,
  from_address TEXT NOT NULL,
  to_address TEXT NOT NULL,
  amount_raw NUMERIC(78,0) NOT NULL CHECK (amount_raw > 0),
  amount NUMERIC(36,18) NOT NULL CHECK (amount > 0),
  confirmations INTEGER NOT NULL DEFAULT 0 CHECK (confirmations >= 0),
  status TEXT NOT NULL DEFAULT 'DETECTED' CHECK (
    status IN ('DETECTED','CONFIRMING','CONFIRMED','CREDITED','ORPHANED','IGNORED','FAILED')
  ),
  detected_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  confirmed_at TIMESTAMPTZ,
  credited_at TIMESTAMPTZ,
  orphaned_at TIMESTAMPTZ,
  failure_reason TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT blockchain_deposits_token_address_check CHECK (token_contract ~ '^0x[0-9A-Fa-f]{40}$'),
  CONSTRAINT blockchain_deposits_tx_hash_check CHECK (tx_hash ~ '^0x[0-9A-Fa-f]{64}$'),
  CONSTRAINT blockchain_deposits_block_hash_check CHECK (block_hash ~ '^0x[0-9A-Fa-f]{64}$'),
  CONSTRAINT blockchain_deposits_from_address_check CHECK (from_address ~ '^0x[0-9A-Fa-f]{40}$'),
  CONSTRAINT blockchain_deposits_to_address_check CHECK (to_address ~ '^0x[0-9A-Fa-f]{40}$')
);

CREATE UNIQUE INDEX IF NOT EXISTS blockchain_deposits_event_unique
  ON blockchain_deposits(chain_id, lower(tx_hash), log_index);
CREATE INDEX IF NOT EXISTS blockchain_deposits_user_created_idx
  ON blockchain_deposits(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS blockchain_deposits_status_block_idx
  ON blockchain_deposits(status, block_number);
CREATE INDEX IF NOT EXISTS blockchain_deposits_wallet_status_idx
  ON blockchain_deposits(wallet_id, status);

DROP TRIGGER IF EXISTS blockchain_deposits_updated_at ON blockchain_deposits;
CREATE TRIGGER blockchain_deposits_updated_at
BEFORE UPDATE ON blockchain_deposits
FOR EACH ROW EXECUTE FUNCTION shaye_set_updated_at();

CREATE TABLE IF NOT EXISTS blockchain_withdrawals (
  id TEXT PRIMARY KEY,
  withdrawal_id TEXT NOT NULL UNIQUE REFERENCES withdrawals(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  chain_id BIGINT NOT NULL CHECK (chain_id > 0),
  token_contract TEXT NOT NULL,
  sender_address TEXT,
  destination_address TEXT NOT NULL,
  amount_raw NUMERIC(78,0) NOT NULL CHECK (amount_raw > 0),
  amount NUMERIC(36,18) NOT NULL CHECK (amount > 0),
  network_fee_raw NUMERIC(78,0) CHECK (network_fee_raw IS NULL OR network_fee_raw >= 0),
  network_fee NUMERIC(36,18) CHECK (network_fee IS NULL OR network_fee >= 0),
  nonce BIGINT CHECK (nonce IS NULL OR nonce >= 0),
  tx_hash TEXT,
  replacement_tx_hash TEXT,
  block_number BIGINT CHECK (block_number IS NULL OR block_number >= 0),
  block_hash TEXT,
  confirmations INTEGER NOT NULL DEFAULT 0 CHECK (confirmations >= 0),
  status TEXT NOT NULL DEFAULT 'QUEUED' CHECK (
    status IN ('QUEUED','RESERVED','SIGNING','BROADCASTED','CONFIRMING','CONFIRMED','COMPLETED','FAILED','CANCELLED','REPLACED')
  ),
  idempotency_key TEXT NOT NULL UNIQUE,
  attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  max_attempts INTEGER NOT NULL DEFAULT 10 CHECK (max_attempts BETWEEN 1 AND 100),
  next_attempt_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  reserved_at TIMESTAMPTZ,
  broadcast_at TIMESTAMPTZ,
  confirmed_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  failed_at TIMESTAMPTZ,
  failure_reason TEXT,
  last_error TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT blockchain_withdrawals_token_address_check CHECK (token_contract ~ '^0x[0-9A-Fa-f]{40}$'),
  CONSTRAINT blockchain_withdrawals_sender_address_check CHECK (
    sender_address IS NULL OR sender_address ~ '^0x[0-9A-Fa-f]{40}$'
  ),
  CONSTRAINT blockchain_withdrawals_destination_address_check CHECK (
    destination_address ~ '^0x[0-9A-Fa-f]{40}$'
  ),
  CONSTRAINT blockchain_withdrawals_tx_hash_check CHECK (
    tx_hash IS NULL OR tx_hash ~ '^0x[0-9A-Fa-f]{64}$'
  ),
  CONSTRAINT blockchain_withdrawals_replacement_tx_hash_check CHECK (
    replacement_tx_hash IS NULL OR replacement_tx_hash ~ '^0x[0-9A-Fa-f]{64}$'
  ),
  CONSTRAINT blockchain_withdrawals_block_hash_check CHECK (
    block_hash IS NULL OR block_hash ~ '^0x[0-9A-Fa-f]{64}$'
  )
);

CREATE UNIQUE INDEX IF NOT EXISTS blockchain_withdrawals_tx_hash_unique
  ON blockchain_withdrawals(chain_id, lower(tx_hash))
  WHERE tx_hash IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS blockchain_withdrawals_replacement_tx_hash_unique
  ON blockchain_withdrawals(chain_id, lower(replacement_tx_hash))
  WHERE replacement_tx_hash IS NOT NULL;
CREATE INDEX IF NOT EXISTS blockchain_withdrawals_queue_idx
  ON blockchain_withdrawals(status, next_attempt_at, created_at)
  WHERE status IN ('QUEUED','RESERVED','FAILED');
CREATE INDEX IF NOT EXISTS blockchain_withdrawals_user_created_idx
  ON blockchain_withdrawals(user_id, created_at DESC);

DROP TRIGGER IF EXISTS blockchain_withdrawals_updated_at ON blockchain_withdrawals;
CREATE TRIGGER blockchain_withdrawals_updated_at
BEFORE UPDATE ON blockchain_withdrawals
FOR EACH ROW EXECUTE FUNCTION shaye_set_updated_at();

CREATE TABLE IF NOT EXISTS blockchain_cursors (
  id TEXT PRIMARY KEY,
  worker_name TEXT NOT NULL,
  stream_name TEXT NOT NULL,
  chain_id BIGINT NOT NULL CHECK (chain_id > 0),
  token_contract TEXT,
  last_scanned_block BIGINT NOT NULL DEFAULT 0 CHECK (last_scanned_block >= 0),
  last_finalized_block BIGINT NOT NULL DEFAULT 0 CHECK (last_finalized_block >= 0),
  last_block_hash TEXT,
  lock_owner TEXT,
  lock_expires_at TIMESTAMPTZ,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT blockchain_cursors_token_address_check CHECK (
    token_contract IS NULL OR token_contract ~ '^0x[0-9A-Fa-f]{40}$'
  ),
  CONSTRAINT blockchain_cursors_block_hash_check CHECK (
    last_block_hash IS NULL OR last_block_hash ~ '^0x[0-9A-Fa-f]{64}$'
  ),
  CONSTRAINT blockchain_cursors_finalized_not_ahead_check CHECK (
    last_finalized_block <= last_scanned_block
  )
);

CREATE UNIQUE INDEX IF NOT EXISTS blockchain_cursors_stream_unique
  ON blockchain_cursors(
    worker_name,
    stream_name,
    chain_id,
    COALESCE(lower(token_contract), '')
  );
CREATE INDEX IF NOT EXISTS blockchain_cursors_lock_idx
  ON blockchain_cursors(lock_expires_at);

DROP TRIGGER IF EXISTS blockchain_cursors_updated_at ON blockchain_cursors;
CREATE TRIGGER blockchain_cursors_updated_at
BEFORE UPDATE ON blockchain_cursors
FOR EACH ROW EXECUTE FUNCTION shaye_set_updated_at();

CREATE TABLE IF NOT EXISTS blockchain_jobs (
  id TEXT PRIMARY KEY,
  job_type TEXT NOT NULL CHECK (
    job_type IN ('SCAN_DEPOSITS','CONFIRM_DEPOSIT','CREDIT_DEPOSIT','PREPARE_WITHDRAWAL','SEND_WITHDRAWAL','CONFIRM_WITHDRAWAL','FUND_GAS','SWEEP_TOKEN','RECONCILE')
  ),
  idempotency_key TEXT NOT NULL UNIQUE,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  status TEXT NOT NULL DEFAULT 'PENDING' CHECK (
    status IN ('PENDING','RUNNING','RETRY','COMPLETED','FAILED','CANCELLED')
  ),
  priority INTEGER NOT NULL DEFAULT 100,
  attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  max_attempts INTEGER NOT NULL DEFAULT 10 CHECK (max_attempts BETWEEN 1 AND 100),
  run_after TIMESTAMPTZ NOT NULL DEFAULT now(),
  locked_by TEXT,
  locked_at TIMESTAMPTZ,
  lock_expires_at TIMESTAMPTZ,
  last_error TEXT,
  result JSONB,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS blockchain_jobs_claim_idx
  ON blockchain_jobs(status, run_after, priority, created_at)
  WHERE status IN ('PENDING','RETRY');
CREATE INDEX IF NOT EXISTS blockchain_jobs_running_lock_idx
  ON blockchain_jobs(lock_expires_at)
  WHERE status = 'RUNNING';

DROP TRIGGER IF EXISTS blockchain_jobs_updated_at ON blockchain_jobs;
CREATE TRIGGER blockchain_jobs_updated_at
BEFORE UPDATE ON blockchain_jobs
FOR EACH ROW EXECUTE FUNCTION shaye_set_updated_at();

CREATE TABLE IF NOT EXISTS wallet_sweeps (
  id TEXT PRIMARY KEY,
  wallet_id TEXT NOT NULL REFERENCES blockchain_wallets(id) ON DELETE RESTRICT,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  chain_id BIGINT NOT NULL CHECK (chain_id > 0),
  token_contract TEXT NOT NULL,
  from_address TEXT NOT NULL,
  treasury_address TEXT NOT NULL,
  amount_raw NUMERIC(78,0) NOT NULL CHECK (amount_raw > 0),
  amount NUMERIC(36,18) NOT NULL CHECK (amount > 0),
  gas_funding_amount_raw NUMERIC(78,0) CHECK (gas_funding_amount_raw IS NULL OR gas_funding_amount_raw >= 0),
  gas_funding_tx_hash TEXT,
  sweep_tx_hash TEXT,
  nonce BIGINT CHECK (nonce IS NULL OR nonce >= 0),
  status TEXT NOT NULL DEFAULT 'QUEUED' CHECK (
    status IN ('QUEUED','GAS_REQUIRED','GAS_SENT','BROADCASTED','CONFIRMING','COMPLETED','FAILED','CANCELLED')
  ),
  idempotency_key TEXT NOT NULL UNIQUE,
  attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  max_attempts INTEGER NOT NULL DEFAULT 10 CHECK (max_attempts BETWEEN 1 AND 100),
  next_attempt_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ,
  failure_reason TEXT,
  last_error TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT wallet_sweeps_token_address_check CHECK (token_contract ~ '^0x[0-9A-Fa-f]{40}$'),
  CONSTRAINT wallet_sweeps_from_address_check CHECK (from_address ~ '^0x[0-9A-Fa-f]{40}$'),
  CONSTRAINT wallet_sweeps_treasury_address_check CHECK (treasury_address ~ '^0x[0-9A-Fa-f]{40}$'),
  CONSTRAINT wallet_sweeps_gas_tx_hash_check CHECK (
    gas_funding_tx_hash IS NULL OR gas_funding_tx_hash ~ '^0x[0-9A-Fa-f]{64}$'
  ),
  CONSTRAINT wallet_sweeps_tx_hash_check CHECK (
    sweep_tx_hash IS NULL OR sweep_tx_hash ~ '^0x[0-9A-Fa-f]{64}$'
  )
);

CREATE UNIQUE INDEX IF NOT EXISTS wallet_sweeps_gas_tx_hash_unique
  ON wallet_sweeps(chain_id, lower(gas_funding_tx_hash))
  WHERE gas_funding_tx_hash IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS wallet_sweeps_tx_hash_unique
  ON wallet_sweeps(chain_id, lower(sweep_tx_hash))
  WHERE sweep_tx_hash IS NOT NULL;
CREATE INDEX IF NOT EXISTS wallet_sweeps_queue_idx
  ON wallet_sweeps(status, next_attempt_at, created_at)
  WHERE status IN ('QUEUED','GAS_REQUIRED','FAILED');
CREATE INDEX IF NOT EXISTS wallet_sweeps_wallet_created_idx
  ON wallet_sweeps(wallet_id, created_at DESC);

DROP TRIGGER IF EXISTS wallet_sweeps_updated_at ON wallet_sweeps;
CREATE TRIGGER wallet_sweeps_updated_at
BEFORE UPDATE ON wallet_sweeps
FOR EACH ROW EXECUTE FUNCTION shaye_set_updated_at();

CREATE TABLE IF NOT EXISTS ledger_accounts (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  account_type TEXT NOT NULL CHECK (account_type IN ('ASSET','LIABILITY','EQUITY','REVENUE','EXPENSE')),
  normal_side TEXT NOT NULL CHECK (normal_side IN ('DEBIT','CREDIT')),
  currency TEXT NOT NULL,
  user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','FROZEN','CLOSED')),
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT ledger_accounts_currency_check CHECK (currency ~ '^[A-Z0-9_-]{2,16}$')
);

CREATE UNIQUE INDEX IF NOT EXISTS ledger_accounts_user_currency_name_unique
  ON ledger_accounts(user_id, currency, name)
  WHERE user_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS ledger_accounts_user_status_idx
  ON ledger_accounts(user_id, status);

DROP TRIGGER IF EXISTS ledger_accounts_updated_at ON ledger_accounts;
CREATE TRIGGER ledger_accounts_updated_at
BEFORE UPDATE ON ledger_accounts
FOR EACH ROW EXECUTE FUNCTION shaye_set_updated_at();

CREATE TABLE IF NOT EXISTS ledger_journals (
  id TEXT PRIMARY KEY,
  idempotency_key TEXT NOT NULL UNIQUE,
  reference_type TEXT,
  reference_id TEXT,
  description TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT','POSTED','VOID')),
  posted_at TIMESTAMPTZ,
  voided_at TIMESTAMPTZ,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT ledger_journals_posted_time_check CHECK (
    status <> 'POSTED' OR posted_at IS NOT NULL
  )
);

CREATE INDEX IF NOT EXISTS ledger_journals_reference_idx
  ON ledger_journals(reference_type, reference_id);
CREATE INDEX IF NOT EXISTS ledger_journals_created_idx
  ON ledger_journals(created_at DESC);

DROP TRIGGER IF EXISTS ledger_journals_updated_at ON ledger_journals;
CREATE TRIGGER ledger_journals_updated_at
BEFORE UPDATE ON ledger_journals
FOR EACH ROW EXECUTE FUNCTION shaye_set_updated_at();

CREATE TABLE IF NOT EXISTS ledger_entries (
  id TEXT PRIMARY KEY,
  journal_id TEXT NOT NULL REFERENCES ledger_journals(id) ON DELETE RESTRICT,
  account_id TEXT NOT NULL REFERENCES ledger_accounts(id) ON DELETE RESTRICT,
  user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  direction TEXT NOT NULL CHECK (direction IN ('DEBIT','CREDIT')),
  amount NUMERIC(36,18) NOT NULL CHECK (amount > 0),
  memo TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ledger_entries_journal_idx
  ON ledger_entries(journal_id);
CREATE INDEX IF NOT EXISTS ledger_entries_account_created_idx
  ON ledger_entries(account_id, created_at DESC);
CREATE INDEX IF NOT EXISTS ledger_entries_user_created_idx
  ON ledger_entries(user_id, created_at DESC)
  WHERE user_id IS NOT NULL;

CREATE OR REPLACE FUNCTION shaye_prevent_posted_ledger_mutation()
RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  target_journal_id TEXT;
  current_status TEXT;
BEGIN
  target_journal_id := CASE WHEN TG_OP = 'DELETE' THEN OLD.journal_id ELSE NEW.journal_id END;

  SELECT status INTO current_status
  FROM ledger_journals
  WHERE id = target_journal_id;

  IF current_status IN ('POSTED','VOID') THEN
    RAISE EXCEPTION 'Ledger entries for a posted or void journal are immutable: %', target_journal_id
      USING ERRCODE = '23514';
  END IF;

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS ledger_entries_immutable ON ledger_entries;
CREATE TRIGGER ledger_entries_immutable
BEFORE INSERT OR UPDATE OR DELETE ON ledger_entries
FOR EACH ROW EXECUTE FUNCTION shaye_prevent_posted_ledger_mutation();

CREATE OR REPLACE FUNCTION shaye_prevent_posted_journal_rewrite()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF OLD.status IN ('POSTED','VOID') THEN
    RAISE EXCEPTION 'Posted or void ledger journals are immutable: %', OLD.id
      USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS ledger_journals_immutable ON ledger_journals;
CREATE TRIGGER ledger_journals_immutable
BEFORE UPDATE ON ledger_journals
FOR EACH ROW EXECUTE FUNCTION shaye_prevent_posted_journal_rewrite();

CREATE OR REPLACE FUNCTION shaye_assert_ledger_balance(target_journal_id TEXT)
RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  journal_status TEXT;
  debit_total NUMERIC(36,18);
  credit_total NUMERIC(36,18);
  currency_count INTEGER;
  entry_count INTEGER;
BEGIN
  SELECT status INTO journal_status
  FROM ledger_journals
  WHERE id = target_journal_id;

  IF journal_status IS DISTINCT FROM 'POSTED' THEN
    RETURN;
  END IF;

  SELECT
    COALESCE(SUM(CASE WHEN e.direction = 'DEBIT' THEN e.amount ELSE 0 END), 0),
    COALESCE(SUM(CASE WHEN e.direction = 'CREDIT' THEN e.amount ELSE 0 END), 0),
    COUNT(DISTINCT a.currency),
    COUNT(*)
  INTO debit_total, credit_total, currency_count, entry_count
  FROM ledger_entries e
  JOIN ledger_accounts a ON a.id = e.account_id
  WHERE e.journal_id = target_journal_id;

  IF entry_count < 2 OR debit_total <= 0 OR debit_total <> credit_total OR currency_count <> 1 THEN
    RAISE EXCEPTION
      'Unbalanced ledger journal % (entries %, debit %, credit %, currencies %)',
      target_journal_id, entry_count, debit_total, credit_total, currency_count
      USING ERRCODE = '23514';
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION shaye_validate_ledger_entry_balance()
RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  target_journal_id TEXT;
BEGIN
  IF TG_OP = 'DELETE' THEN
    target_journal_id := OLD.journal_id;
  ELSE
    target_journal_id := NEW.journal_id;
  END IF;

  PERFORM shaye_assert_ledger_balance(target_journal_id);
  RETURN NULL;
END;
$$;

CREATE OR REPLACE FUNCTION shaye_validate_ledger_journal_balance()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  PERFORM shaye_assert_ledger_balance(NEW.id);
  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS ledger_entries_balance_check ON ledger_entries;
CREATE CONSTRAINT TRIGGER ledger_entries_balance_check
AFTER INSERT OR UPDATE OR DELETE ON ledger_entries
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION shaye_validate_ledger_entry_balance();

DROP TRIGGER IF EXISTS ledger_journals_balance_check ON ledger_journals;
CREATE CONSTRAINT TRIGGER ledger_journals_balance_check
AFTER INSERT OR UPDATE ON ledger_journals
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION shaye_validate_ledger_journal_balance();

INSERT INTO ledger_accounts(id, code, name, account_type, normal_side, currency)
VALUES
  ('sys-usdt-hot', 'SYS-USDT-HOT', 'USDT hot wallet', 'ASSET', 'DEBIT', 'USDT'),
  ('sys-usdt-treasury', 'SYS-USDT-TREASURY', 'USDT treasury', 'ASSET', 'DEBIT', 'USDT'),
  ('sys-usdt-in-transit', 'SYS-USDT-IN-TRANSIT', 'USDT deposits in transit', 'ASSET', 'DEBIT', 'USDT'),
  ('sys-usdt-customer-principal', 'SYS-USDT-CUSTOMER-PRINCIPAL', 'Customer principal liability', 'LIABILITY', 'CREDIT', 'USDT'),
  ('sys-usdt-customer-profit', 'SYS-USDT-CUSTOMER-PROFIT', 'Customer profit liability', 'LIABILITY', 'CREDIT', 'USDT'),
  ('sys-usdt-withdrawal-payable', 'SYS-USDT-WITHDRAWAL-PAYABLE', 'Withdrawal payable', 'LIABILITY', 'CREDIT', 'USDT'),
  ('sys-usdt-platform-revenue', 'SYS-USDT-PLATFORM-REVENUE', 'Platform revenue', 'REVENUE', 'CREDIT', 'USDT'),
  ('sys-usdt-referral-expense', 'SYS-USDT-REFERRAL-EXPENSE', 'Referral expense', 'EXPENSE', 'DEBIT', 'USDT'),
  ('sys-usdt-chain-fee-expense', 'SYS-USDT-CHAIN-FEE-EXPENSE', 'Blockchain fee expense', 'EXPENSE', 'DEBIT', 'USDT'),
  ('sys-bnb-gas-wallet', 'SYS-BNB-GAS-WALLET', 'BNB gas wallet', 'ASSET', 'DEBIT', 'BNB'),
  ('sys-bnb-gas-expense', 'SYS-BNB-GAS-EXPENSE', 'BNB gas expense', 'EXPENSE', 'DEBIT', 'BNB')
ON CONFLICT (id) DO NOTHING;

ALTER TABLE deposits
  ADD COLUMN IF NOT EXISTS source TEXT NOT NULL DEFAULT 'MANUAL',
  ADD COLUMN IF NOT EXISTS chain_id BIGINT,
  ADD COLUMN IF NOT EXISTS token_contract TEXT;

ALTER TABLE deposits
  DROP CONSTRAINT IF EXISTS deposits_source_check;
ALTER TABLE deposits
  ADD CONSTRAINT deposits_source_check CHECK (source IN ('MANUAL','BLOCKCHAIN'));
ALTER TABLE deposits
  DROP CONSTRAINT IF EXISTS deposits_token_contract_check;
ALTER TABLE deposits
  ADD CONSTRAINT deposits_token_contract_check CHECK (
    token_contract IS NULL OR token_contract ~ '^0x[0-9A-Fa-f]{40}$'
  );

ALTER TABLE withdrawals
  ADD COLUMN IF NOT EXISTS source TEXT NOT NULL DEFAULT 'MANUAL',
  ADD COLUMN IF NOT EXISTS chain_id BIGINT,
  ADD COLUMN IF NOT EXISTS token_contract TEXT,
  ADD COLUMN IF NOT EXISTS reserved_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS broadcast_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS completed_at TIMESTAMPTZ;

ALTER TABLE withdrawals
  DROP CONSTRAINT IF EXISTS withdrawals_source_check;
ALTER TABLE withdrawals
  ADD CONSTRAINT withdrawals_source_check CHECK (source IN ('MANUAL','BLOCKCHAIN'));
ALTER TABLE withdrawals
  DROP CONSTRAINT IF EXISTS withdrawals_token_contract_check;
ALTER TABLE withdrawals
  ADD CONSTRAINT withdrawals_token_contract_check CHECK (
    token_contract IS NULL OR token_contract ~ '^0x[0-9A-Fa-f]{40}$'
  );

-- Expand the business-level withdrawal state machine while keeping current
-- PENDING / APPROVED / REJECTED behavior backward compatible.
ALTER TABLE withdrawals
  DROP CONSTRAINT IF EXISTS withdrawals_status_check;
ALTER TABLE withdrawals
  ADD CONSTRAINT withdrawals_status_check CHECK (
    status IN ('PENDING','RESERVED','PROCESSING','BROADCASTED','CONFIRMING','APPROVED','COMPLETED','FAILED','REJECTED','CANCELLED')
  );
