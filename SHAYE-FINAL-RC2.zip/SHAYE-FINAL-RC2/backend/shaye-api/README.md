# SHAYE API — Blockchain Stage 8

Node.js, TypeScript, Express and PostgreSQL backend.

Stage 8 adds:

- migration `011_wallet_sweeper.sql`
- dedicated `sweep-worker`
- deposit-wallet HD signing isolated from the web app
- separate gas-wallet signer and public treasury address
- token balance discovery and minimum sweep threshold
- gas estimation, bounded BNB top-up and gas-wallet reserve checks
- raw transaction persistence before broadcast
- confirmation/retry/recovery state machine
- admin settings, status, pause and recent sweep history
- setup, check, pause and retry scripts

Useful commands after a verified Stage 7 Testnet deployment:

```bash
npm run blockchain:check-sweeper
npm run blockchain:sweep-worker
```

The root deployment uses `scripts/setup-sweeper.sh`. Mainnet execution remains blocked in Stage 8.
