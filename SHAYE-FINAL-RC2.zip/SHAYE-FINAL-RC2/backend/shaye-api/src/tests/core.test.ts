import test from "node:test";
import assert from "node:assert/strict";
import { HDNodeWallet } from "ethers";
import { dateKey, taskWindow } from "../utils/date";
import { money } from "../utils/helpers";
import { percentage } from "../utils/wallet";
import { BLOCKCHAIN_JOB_TYPES } from "../db/blockchain.types";
import { assertPositiveDecimal } from "../utils/decimal";
import {
  amountSchema,
  timezoneSchema,
  walletAddressSchema,
} from "../utils/validator";

test("money values are rounded to six decimals", () => {
  assert.equal(money(1.12345678), 1.123457);
});

test("percentage returns six-decimal monetary value", () => {
  assert.equal(percentage(60, 1.5), 0.9);
});

test("Iran date key is stable", () => {
  assert.equal(
    dateKey(new Date("2026-07-21T12:30:00.000Z"), "Asia/Tehran"),
    "2026-07-21",
  );
});

test("daily task window lasts 24 hours", () => {
  const now = new Date("2026-07-21T13:00:00.000Z");
  const window = taskWindow(now, "Asia/Tehran", 16);
  assert.equal(window.endsAt.getTime() - window.startsAt.getTime(), 86_400_000);
  assert.equal(window.isOpen, true);
});

test("validators reject invalid inputs", () => {
  assert.equal(amountSchema.safeParse(-1).success, false);
  assert.equal(timezoneSchema.safeParse("Not/AZone").success, false);
  assert.equal(walletAddressSchema.safeParse("abc").success, false);
  assert.equal(
    walletAddressSchema.safeParse(
      "0x1111111111111111111111111111111111111111",
    ).success,
    true,
  );
});


test("blockchain job types contain the required worker operations", () => {
  assert.equal(BLOCKCHAIN_JOB_TYPES.includes("SCAN_DEPOSITS"), true);
  assert.equal(BLOCKCHAIN_JOB_TYPES.includes("SEND_WITHDRAWAL"), true);
  assert.equal(BLOCKCHAIN_JOB_TYPES.includes("SWEEP_TOKEN"), true);
});

test("ledger amount validator accepts exact positive decimals", () => {
  assert.doesNotThrow(() => assertPositiveDecimal("1"));
  assert.doesNotThrow(() =>
    assertPositiveDecimal("0.000000000000000001"),
  );
  assert.throws(() => assertPositiveDecimal("0"));
  assert.throws(() => assertPositiveDecimal("-1"));
  assert.throws(() =>
    assertPositiveDecimal("1.0000000000000000001"),
  );
});


test("account xpub derives the same public deposit address", () => {
  const phrase =
    "test test test test test test test test test test test junk";
  const account = HDNodeWallet.fromPhrase(phrase, undefined, "m/44'/60'/0'");
  const xpubNode = HDNodeWallet.fromExtendedKey(account.neuter().extendedKey);
  assert.equal(
    xpubNode.derivePath("0/7").address,
    account.derivePath("0/7").address,
  );
});

test("stage 4 parses an ERC20 Transfer event without private keys", async () => {
  process.env.DATABASE_URL ||= "postgresql://test:test@127.0.0.1:5432/test";
  process.env.JWT_SECRET ||= "x".repeat(64);
  process.env.ADMIN_EMAIL ||= "admin@example.com";
  process.env.ADMIN_PASSWORD ||= "password123";
  process.env.BSC_NETWORK ||= "testnet";
  process.env.BLOCKCHAIN_ENABLED ||= "false";

  const { Interface } = await import("ethers");
  const { depositWatcherInternals } = await import(
    "../services/deposit-watcher.service"
  );
  const iface = new Interface([
    "event Transfer(address indexed from, address indexed to, uint256 value)",
  ]);
  const from = "0x1111111111111111111111111111111111111111";
  const to = "0x2222222222222222222222222222222222222222";
  const encoded = iface.encodeEventLog(iface.getEvent("Transfer")!, [
    from,
    to,
    1_500_000_000_000_000_000n,
  ]);
  const parsed = depositWatcherInternals.parseTransferLog(
    {
      topics: encoded.topics,
      data: encoded.data,
      blockHash: `0x${"a".repeat(64)}`,
      transactionHash: `0x${"b".repeat(64)}`,
      index: 7,
      blockNumber: 123,
    } as any,
    18,
  );

  assert.equal(parsed.fromAddress, from);
  assert.equal(parsed.toAddress, to);
  assert.equal(parsed.amount, "1.5");
  assert.equal(parsed.logIndex, 7);
});

test("stage 4 divides address topics into bounded RPC batches", async () => {
  process.env.DATABASE_URL ||= "postgresql://test:test@127.0.0.1:5432/test";
  process.env.JWT_SECRET ||= "x".repeat(64);
  process.env.ADMIN_EMAIL ||= "admin@example.com";
  process.env.ADMIN_PASSWORD ||= "password123";
  const { depositWatcherInternals } = await import(
    "../services/deposit-watcher.service"
  );
  assert.deepEqual(depositWatcherInternals.chunks([1, 2, 3, 4, 5], 2), [
    [1, 2],
    [3, 4],
    [5],
  ]);
});


test("stage 5 credit helpers are deterministic and six-decimal safe", async () => {
  process.env.DATABASE_URL ||= "postgresql://test:test@127.0.0.1:5432/test";
  process.env.JWT_SECRET ||= "x".repeat(64);
  process.env.ADMIN_EMAIL ||= "admin@example.com";
  process.env.ADMIN_PASSWORD ||= "password123";
  process.env.BSC_NETWORK ||= "testnet";
  process.env.BLOCKCHAIN_ENABLED ||= "false";

  const { depositCreditInternals } = await import(
    "../services/deposit-credit.service"
  );
  assert.equal(depositCreditInternals.businessAmount("1.12345678"), 1.123457);
  assert.equal(depositCreditInternals.percentageReward(60, 12), 7.2);
  assert.equal(
    depositCreditInternals.creditJobKey("deposit-123"),
    "credit-deposit:deposit-123",
  );
});


test("stage 6 first-VIP wheel grant is eligible only on VIP0 to VIP1+ crossing", async () => {
  process.env.DATABASE_URL ||= "postgresql://test:test@127.0.0.1:5432/test";
  process.env.JWT_SECRET ||= "x".repeat(64);
  process.env.ADMIN_EMAIL ||= "admin@example.com";
  process.env.ADMIN_PASSWORD ||= "password123";
  const {
    isFirstVipReferralGrantEligible,
    firstVipReferralSpinCount,
  } = await import("../services/wheel.service");
  assert.equal(isFirstVipReferralGrantEligible(0, 0), false);
  assert.equal(isFirstVipReferralGrantEligible(0, 1), true);
  assert.equal(isFirstVipReferralGrantEligible(0, 5), true);
  assert.equal(isFirstVipReferralGrantEligible(1, 2), false);
  assert.equal(isFirstVipReferralGrantEligible(2, 5), false);
  assert.equal(firstVipReferralSpinCount(0), 0);
  assert.equal(firstVipReferralSpinCount(1), 1);
  assert.equal(firstVipReferralSpinCount(20), 1);
});

test("stage 6 withdrawal helpers create stable job keys and exact raw amounts", async () => {
  process.env.DATABASE_URL ||= "postgresql://test:test@127.0.0.1:5432/test";
  process.env.JWT_SECRET ||= "x".repeat(64);
  process.env.ADMIN_EMAIL ||= "admin@example.com";
  process.env.ADMIN_PASSWORD ||= "password123";
  process.env.BSC_NETWORK ||= "testnet";
  process.env.BLOCKCHAIN_ENABLED ||= "false";
  const { withdrawalExecutionInternals } = await import(
    "../services/withdrawal-execution.service"
  );
  assert.equal(
    withdrawalExecutionInternals.parseBusinessAmountToRaw(1.5, 18),
    "1500000000000000000",
  );
  assert.equal(
    withdrawalExecutionInternals.sendJobKey("wd-1"),
    "send-withdrawal:wd-1",
  );
  assert.equal(
    withdrawalExecutionInternals.confirmJobKey("wd-1"),
    "confirm-withdrawal:wd-1",
  );
  assert.equal(
    withdrawalExecutionInternals.isZeroAddress(
      "0x0000000000000000000000000000000000000000",
    ),
    true,
  );
  assert.equal(
    withdrawalExecutionInternals.isKnownTransactionError(
      new Error("already known"),
    ),
    true,
  );
});

test("stage 7 automatic withdrawal limits fall back to manager review", async () => {
  process.env.DATABASE_URL ||= "postgresql://test:test@127.0.0.1:5432/test";
  process.env.JWT_SECRET ||= "x".repeat(64);
  process.env.ADMIN_EMAIL ||= "admin@example.com";
  process.env.ADMIN_PASSWORD ||= "password123";
  const { evaluateAutoWithdrawalEligibility } = await import(
    "../services/automatic-withdrawal.service"
  );
  const policy = {
    enabled: true,
    maxAmount: 50,
    dailyLimit: 500,
    dailyCountLimit: 20,
    maxConcurrent: 3,
  };
  assert.equal(
    evaluateAutoWithdrawalEligibility(policy, {
      amount: 25,
      currentDailyAmount: 100,
      currentDailyCount: 2,
      currentConcurrent: 1,
    }).automatic,
    true,
  );
  assert.equal(
    evaluateAutoWithdrawalEligibility(policy, {
      amount: 51,
      currentDailyAmount: 0,
      currentDailyCount: 0,
      currentConcurrent: 0,
    }).reason,
    "ABOVE_PER_REQUEST_LIMIT",
  );
  assert.equal(
    evaluateAutoWithdrawalEligibility(policy, {
      amount: 25,
      currentDailyAmount: 490,
      currentDailyCount: 1,
      currentConcurrent: 0,
    }).reason,
    "DAILY_AMOUNT_LIMIT_REACHED",
  );
  assert.equal(
    evaluateAutoWithdrawalEligibility(policy, {
      amount: 25,
      currentDailyAmount: 0,
      currentDailyCount: 1,
      currentConcurrent: 3,
    }).reason,
    "CONCURRENT_LIMIT_REACHED",
  );
});

test("stage 8 sweep helpers enforce minimum balance and concurrency", async () => {
  process.env.DATABASE_URL ||= "postgresql://test:test@127.0.0.1:5432/test";
  process.env.JWT_SECRET ||= "x".repeat(64);
  process.env.ADMIN_EMAIL ||= "admin@example.com";
  process.env.ADMIN_PASSWORD ||= "password123";
  process.env.BSC_NETWORK ||= "testnet";
  process.env.BLOCKCHAIN_ENABLED ||= "false";
  const { walletSweeperInternals } = await import(
    "../services/wallet-sweeper.service"
  );
  assert.equal(
    walletSweeperInternals.shouldCreateSweep(10n, 10n, 0, 1),
    true,
  );
  assert.equal(
    walletSweeperInternals.shouldCreateSweep(9n, 10n, 0, 1),
    false,
  );
  assert.equal(
    walletSweeperInternals.shouldCreateSweep(20n, 10n, 1, 1),
    false,
  );
  assert.equal(
    walletSweeperInternals.calculateGasTopUp(0n, 100n, 50n),
    130n,
  );
  assert.equal(
    walletSweeperInternals.calculateGasTopUp(200n, 100n, 50n),
    0n,
  );
  assert.equal(
    walletSweeperInternals.fundGasJobKey("sweep-1"),
    "fund-gas:sweep-1",
  );
  assert.equal(
    walletSweeperInternals.sweepTokenJobKey("sweep-1"),
    "sweep-token:sweep-1",
  );
});
