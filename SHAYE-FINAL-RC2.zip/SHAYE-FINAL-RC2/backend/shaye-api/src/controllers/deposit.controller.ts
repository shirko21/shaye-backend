import { RequestHandler } from "express";
import * as service from "../services/deposit.service";
import { ok } from "../utils/response";
export const create: RequestHandler = async (req, res) => ok(res, await service.createDeposit(req.auth!.userId, req.body.amount, req.body.txHash), "درخواست واریز ثبت شد.", 201);
export const list: RequestHandler = async (req, res) => ok(res, await service.listUserDeposits(req.auth!.userId));

export const testCredit: RequestHandler = async (req, res) => ok(res, await service.createStage9ATestDeposit(req.auth!.userId, req.body.amount), "سرمایه آزمایشی اضافه شد.", 201);
