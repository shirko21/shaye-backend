import { RequestHandler } from "express";
import * as service from "../services/task.service";
import { ok } from "../utils/response";
export const status: RequestHandler = async (req, res) => ok(res, await service.taskStatus(req.auth!.userId));
export const claim: RequestHandler = async (req, res) => ok(res, await service.claimTask(req.auth!.userId), "پاداش ثبت شد.");
export const history: RequestHandler = async (req, res) => ok(res, await service.taskHistory(req.auth!.userId));
