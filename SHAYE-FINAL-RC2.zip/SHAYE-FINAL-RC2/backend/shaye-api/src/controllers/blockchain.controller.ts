import { RequestHandler } from "express";
import { getBlockchainStatus } from "../services/blockchain.service";
import { getDepositWatcherStatus } from "../services/deposit-watcher.service";
import { getDepositCreditStatus } from "../services/deposit-credit.service";
import { getWithdrawalExecutionStatus } from "../services/withdrawal-execution.service";
import { activateBlockchainEmergencyStop } from "../services/blockchain-database.service";
import { ok } from "../utils/response";
import {
  getAutomaticWithdrawalSettings,
  pauseAutomaticWithdrawals,
  updateAutomaticWithdrawalSettings,
} from "../services/automatic-withdrawal.service";
import {
  getSweeperSettings,
  pauseSweeper,
  updateSweeperSettings,
} from "../services/wallet-sweeper.service";

export const status: RequestHandler = async (_req, res) => {
  const result = await getBlockchainStatus();
  ok(res, result, "وضعیت اتصال بلاک‌چین دریافت شد.");
};

export const depositWatcherStatus: RequestHandler = async (_req, res) => {
  ok(res, await getDepositWatcherStatus(), "وضعیت پایش واریز دریافت شد.");
};

export const depositCreditStatus: RequestHandler = async (_req, res) => {
  ok(res, await getDepositCreditStatus(), "وضعیت اعتباردهی خودکار واریز دریافت شد.");
};

export const withdrawalExecutionStatus: RequestHandler = async (_req, res) => {
  ok(
    res,
    await getWithdrawalExecutionStatus(),
    "وضعیت Worker برداشت دریافت شد.",
  );
};

export const emergencyStop: RequestHandler = async (req, res) => {
  const result = await activateBlockchainEmergencyStop({
    actorId: req.auth!.userId,
    reason: req.body.reason,
  });
  ok(res, result, "توقف اضطراری بلاک‌چین فعال شد.");
};


export const automaticWithdrawalSettings: RequestHandler = async (_req, res) => {
  ok(
    res,
    await getAutomaticWithdrawalSettings(),
    "تنظیمات برداشت خودکار دریافت شد.",
  );
};

export const updateAutomaticWithdrawalPolicy: RequestHandler = async (req, res) => {
  await updateAutomaticWithdrawalSettings(req.auth!.userId, req.body);
  ok(
    res,
    await getAutomaticWithdrawalSettings(),
    "تنظیمات برداشت خودکار ذخیره شد.",
  );
};

export const pauseAutomaticWithdrawalPolicy: RequestHandler = async (req, res) => {
  await pauseAutomaticWithdrawals(req.body.reason, req.auth!.userId);
  ok(
    res,
    await getAutomaticWithdrawalSettings(),
    "برداشت خودکار متوقف شد.",
  );
};

export const sweeperSettings: RequestHandler = async (_req, res) => {
  ok(res, await getSweeperSettings(), "تنظیمات و وضعیت جمع‌آوری موجودی دریافت شد.");
};

export const updateSweeperPolicy: RequestHandler = async (req, res) => {
  await updateSweeperSettings(req.auth!.userId, req.body);
  ok(res, await getSweeperSettings(), "تنظیمات جمع‌آوری موجودی ذخیره شد.");
};

export const pauseSweeperPolicy: RequestHandler = async (req, res) => {
  await pauseSweeper(req.body.reason, req.auth!.userId);
  ok(res, await getSweeperSettings(), "جمع‌آوری موجودی متوقف شد.");
};
