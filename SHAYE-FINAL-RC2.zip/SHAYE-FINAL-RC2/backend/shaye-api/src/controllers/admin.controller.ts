import { RequestHandler } from "express";
import * as admin from "../services/admin.service";
import * as deposits from "../services/deposit.service";
import * as withdrawals from "../services/withdraw.service";
import { ok } from "../utils/response";
import * as extra from "../services/admin-extra.service";
import { listAdminDepositWallets } from "../services/deposit-wallet.service";
export const overview: RequestHandler = async (_req, res) => ok(res, await admin.overview());
export const users: RequestHandler = async (req, res) => ok(res, await admin.listUsers(String(req.query.search || "")));
export const setUserActive: RequestHandler = async (req, res) => { await admin.setUserActive(req.auth!.userId, req.params.id!, req.body.isActive); ok(res, null, "وضعیت کاربر تغییر کرد."); };
export const depositList: RequestHandler = async (req, res) => ok(res, await admin.listDeposits(req.query.status as string | undefined));
export const approveDeposit: RequestHandler = async (req, res) => { await deposits.approveDeposit(req.auth!.userId, req.params.id!, req.body.note); ok(res, null, "واریز تأیید شد."); };
export const rejectDeposit: RequestHandler = async (req, res) => { await deposits.rejectDeposit(req.auth!.userId, req.params.id!, req.body.note); ok(res, null, "واریز رد شد."); };
export const withdrawalList: RequestHandler = async (req, res) => ok(res, await admin.listWithdrawals(req.query.status as string | undefined));
export const approveWithdrawal: RequestHandler = async (req, res) => {
  ok(
    res,
    await withdrawals.approveWithdrawal(
      req.auth!.userId,
      req.params.id!,
      req.body.note,
    ),
    "برداشت تأیید و در صف ارسال Testnet قرار گرفت.",
  );
};
export const rejectWithdrawal: RequestHandler = async (req, res) => {
  ok(
    res,
    await withdrawals.rejectWithdrawal(
      req.auth!.userId,
      req.params.id!,
      req.body.note,
    ),
    "برداشت رد و موجودی بازگردانده شد.",
  );
};
export const settings: RequestHandler = async (_req, res) => ok(res, await admin.adminConfig());
export const updateSettings: RequestHandler = async (req, res) => ok(res, await admin.updateSettings(req.auth!.userId, req.body), "تنظیمات ذخیره شد.");
export const updateVipTiers: RequestHandler = async (req, res) => ok(res, await admin.updateVipTiers(req.auth!.userId, req.body.tiers), "سطوح VIP ذخیره شد.");
export const announcements: RequestHandler = async (_req, res) => ok(res, await admin.listAnnouncements(true));
export const saveAnnouncement: RequestHandler = async (req, res) => ok(res, await admin.saveAnnouncement(req.auth!.userId, req.body, req.params.id), "اطلاعیه ذخیره شد.");
export const deleteAnnouncement: RequestHandler = async (req, res) => { await admin.deleteAnnouncement(req.auth!.userId, req.params.id!); ok(res, null, "اطلاعیه حذف شد."); };

export const adjustBalances: RequestHandler = async (req,res)=>ok(res,await extra.adjustBalances(req.auth!.userId,req.params.id!,req.body),"موجودی کاربر به‌روزرسانی شد.");
export const wheelConfig: RequestHandler = async (_req,res)=>ok(res,await extra.wheelConfig());
export const updateWheel: RequestHandler = async (req,res)=>ok(res,await extra.updateWheel(req.auth!.userId,req.body),"تنظیمات گردونه ذخیره شد.");
export const setUserSpins: RequestHandler = async (req,res)=>ok(res,await extra.setUserSpins(req.auth!.userId,req.params.id!,req.body.spins),"فرصت کاربر ذخیره شد.");
export const wheelHistory: RequestHandler = async (req,res)=>ok(res,await extra.wheelHistory(String(req.query.search||""),Number(req.query.limit)||100));
export const referralWheelGrants: RequestHandler = async (req,res)=>ok(res,await extra.referralWheelGrants(String(req.query.search||""),Number(req.query.limit)||100));
export const supportThreads: RequestHandler = async (req,res)=>ok(res,await extra.supportThreads(String(req.query.search||"")));
export const supportThread: RequestHandler = async (req,res)=>ok(res,await extra.supportThread(req.params.id!));
export const supportReply: RequestHandler = async (req,res)=>ok(res,await extra.supportReply(req.auth!.userId,req.params.id!,req.body.body),"پاسخ ارسال شد.",201);
export const homeContent: RequestHandler = async (_req,res)=>ok(res,await extra.getHome());
export const updateHomeContent: RequestHandler = async (req,res)=>ok(res,await extra.updateHome(req.auth!.userId,req.body),"محتوای صفحه اصلی ذخیره شد.");

export const blockchainWallets: RequestHandler = async (req,res)=>ok(res,await listAdminDepositWallets(String(req.query.search||""),Number(req.query.limit)||100));
