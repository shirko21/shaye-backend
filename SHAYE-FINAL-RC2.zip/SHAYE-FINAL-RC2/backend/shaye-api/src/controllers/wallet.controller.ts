import { RequestHandler } from "express";
import * as service from "../services/wallet.service";
import { ok } from "../utils/response";
export const summary: RequestHandler = async (req, res) => ok(res, await service.summary(req.auth!.userId));
export const transactions: RequestHandler = async (req, res) => ok(res, await service.transactions(req.auth!.userId, Number(req.query.limit) || 50));
export const movePrincipal: RequestHandler = async (req, res) => { await service.movePrincipalToProfit(req.auth!.userId, req.body.amount); ok(res, null, "انتقال انجام شد."); };
export const reinvest: RequestHandler = async (req, res) => { await service.reinvest(req.auth!.userId, req.body.amount); ok(res, null, "سرمایه‌گذاری مجدد انجام شد."); };
