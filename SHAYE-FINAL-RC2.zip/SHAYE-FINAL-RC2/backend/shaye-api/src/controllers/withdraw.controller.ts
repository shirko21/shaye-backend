import { RequestHandler } from "express";
import * as service from "../services/withdraw.service";
import { ok } from "../utils/response";
export const create: RequestHandler = async (req, res) => ok(res, await service.createWithdrawal(req.auth!.userId, req.body.amount, req.body.walletAddress, req.body.password), "درخواست برداشت ثبت شد.", 201);
export const list: RequestHandler = async (req, res) => ok(res, await service.listUserWithdrawals(req.auth!.userId));
export const policy: RequestHandler = async (req, res) => ok(res, await service.getUserWithdrawalPolicy(req.auth!.userId));
