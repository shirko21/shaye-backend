import { RequestHandler } from "express";
import * as service from "../services/auth.service";
import { jwtConfig } from "../config/jwt";
import { ok } from "../utils/response";
export const register: RequestHandler = async (req, res) => { const result = await service.register(req.body); res.cookie(jwtConfig.cookieName, result.token, jwtConfig.cookieOptions); ok(res, { user: result.user }, "ثبت‌نام با موفقیت انجام شد.", 201); };
export const login: RequestHandler = async (req, res) => { const result = await service.login(req.body); res.cookie(jwtConfig.cookieName, result.token, jwtConfig.cookieOptions); ok(res, { user: result.user }, "ورود موفق بود."); };
export const logout: RequestHandler = async (_req, res) => { res.clearCookie(jwtConfig.cookieName, jwtConfig.cookieOptions); ok(res, null, "خروج انجام شد."); };
export const me: RequestHandler = async (req, res) => ok(res, await service.getCurrentUser(req.auth!.userId));
export const changePassword: RequestHandler = async (req, res) => { await service.changePassword(req.auth!.userId, req.body.currentPassword, req.body.newPassword); res.clearCookie(jwtConfig.cookieName, jwtConfig.cookieOptions); ok(res, null, "رمز تغییر کرد؛ دوباره وارد شوید."); };
