import { RequestHandler } from "express";
import * as service from "../services/user.service";
import { ok } from "../utils/response";
export const profile:RequestHandler=async(req,res)=>ok(res,await service.profile(req.auth!.userId));
export const updateWallet:RequestHandler=async(req,res)=>ok(res,await service.updateWalletAddress(req.auth!.userId,req.body.walletAddress),"آدرس کیف پول ذخیره شد.");
export const team:RequestHandler=async(req,res)=>ok(res,await service.team(req.auth!.userId));

export const notifications:RequestHandler=async(req,res)=>ok(res,await service.listNotifications(req.auth!.userId,String(req.query.unreadOnly||"")==="true",Number(req.query.limit||30)));
export const readNotification:RequestHandler=async(req,res)=>ok(res,await service.markNotificationRead(req.auth!.userId,req.params.id!),"اعلان خوانده شد.");
