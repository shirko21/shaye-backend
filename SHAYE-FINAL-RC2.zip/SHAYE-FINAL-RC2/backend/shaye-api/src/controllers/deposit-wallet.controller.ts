import { RequestHandler } from "express";
import {
  ensureUserDepositWallet,
  listUserBlockchainDeposits,
} from "../services/deposit-wallet.service";
import { ok } from "../utils/response";

export const getWallet: RequestHandler = async (req, res) => {
  ok(
    res,
    await ensureUserDepositWallet(req.auth!.userId),
    "آدرس اختصاصی واریز دریافت شد.",
  );
};

export const listDeposits: RequestHandler = async (req, res) => {
  ok(res, await listUserBlockchainDeposits(req.auth!.userId));
};
