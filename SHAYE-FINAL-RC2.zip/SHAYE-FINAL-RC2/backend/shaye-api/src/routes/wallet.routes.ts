import { Router } from "express";
import { z } from "zod";
import * as controller from "../controllers/wallet.controller";
import { requireAuth } from "../middlewares/auth.middleware";
import { requireOperational } from "../middlewares/maintenance.middleware";
import { validateBody } from "../middlewares/validation.middleware";
import { amountSchema } from "../utils/validator";
import { asyncHandler } from "../utils/response";
const router = Router(); router.use(requireAuth, requireOperational); router.get("/summary", asyncHandler(controller.summary)); router.get("/transactions", asyncHandler(controller.transactions)); router.post("/move-principal", validateBody(z.object({ amount: amountSchema })), asyncHandler(controller.movePrincipal)); router.post("/reinvest", validateBody(z.object({ amount: amountSchema })), asyncHandler(controller.reinvest)); export default router;
