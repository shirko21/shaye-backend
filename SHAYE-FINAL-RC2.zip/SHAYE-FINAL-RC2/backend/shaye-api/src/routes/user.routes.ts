import { Router } from "express";
import { z } from "zod";
import * as controller from "../controllers/user.controller";
import { requireAuth } from "../middlewares/auth.middleware";
import { requireOperational } from "../middlewares/maintenance.middleware";
import { validateBody } from "../middlewares/validation.middleware";
import { walletAddressSchema } from "../utils/validator";
import { asyncHandler } from "../utils/response";
const router=Router();router.use(requireAuth,requireOperational);router.get("/profile",asyncHandler(controller.profile));router.patch("/profile/wallet",validateBody(z.object({walletAddress:walletAddressSchema})),asyncHandler(controller.updateWallet));router.get("/team",asyncHandler(controller.team));router.get("/notifications",asyncHandler(controller.notifications));router.post("/notifications/:id/read",asyncHandler(controller.readNotification));export default router;
