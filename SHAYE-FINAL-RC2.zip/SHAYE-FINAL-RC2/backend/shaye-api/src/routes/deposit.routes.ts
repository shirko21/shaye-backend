import { Router } from "express";
import { z } from "zod";
import * as controller from "../controllers/deposit.controller";
import { requireAuth } from "../middlewares/auth.middleware";
import { requireOperational } from "../middlewares/maintenance.middleware";
import { validateBody } from "../middlewares/validation.middleware";
import { amountSchema } from "../utils/validator";
import { asyncHandler } from "../utils/response";
const router = Router(); router.use(requireAuth, requireOperational); router.get("/", asyncHandler(controller.list)); router.post("/test-credit", validateBody(z.object({ amount: amountSchema })), asyncHandler(controller.testCredit)); router.post("/", validateBody(z.object({ amount: amountSchema, txHash: z.string().trim().max(128).optional() })), asyncHandler(controller.create)); export default router;
