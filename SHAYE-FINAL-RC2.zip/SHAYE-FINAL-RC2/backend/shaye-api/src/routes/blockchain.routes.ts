import { Router } from "express";
import { z } from "zod";
import * as blockchainController from "../controllers/blockchain.controller";
import * as depositWalletController from "../controllers/deposit-wallet.controller";
import { requireAuth } from "../middlewares/auth.middleware";
import { requireAdmin } from "../middlewares/admin.middleware";
import { requireOperational } from "../middlewares/maintenance.middleware";
import { asyncHandler } from "../utils/response";
import { validateBody } from "../middlewares/validation.middleware";

const router = Router();

const automaticWithdrawalPolicySchema = z.object({
  enabled: z.boolean(),
  maxAmount: z.number().min(0).max(1_000_000_000),
  dailyLimit: z.number().min(0).max(1_000_000_000),
  dailyCountLimit: z.number().int().min(1).max(100_000),
  maxConcurrent: z.number().int().min(1).max(100),
  minTokenReserve: z.number().min(0).max(1_000_000_000),
  minBnbReserve: z.number().min(0).max(1_000_000),
});

const sweeperPolicySchema = z.object({
  enabled: z.boolean(),
  minAmount: z.number().positive().max(1_000_000_000),
  discoveryBatchSize: z.number().int().min(1).max(500),
  jobBatchSize: z.number().int().min(1).max(25),
  maxConcurrent: z.number().int().min(1).max(20),
  targetGasBnb: z.number().positive().max(10),
  gasWalletMinBnbReserve: z.number().min(0).max(1_000),
});


router.get("/status", asyncHandler(blockchainController.status));
router.get(
  "/deposit-watcher/status",
  requireAuth,
  requireAdmin,
  asyncHandler(blockchainController.depositWatcherStatus),
);
router.get(
  "/deposit-credit/status",
  requireAuth,
  requireAdmin,
  asyncHandler(blockchainController.depositCreditStatus),
);
router.get(
  "/withdrawals/status",
  requireAuth,
  requireAdmin,
  asyncHandler(blockchainController.withdrawalExecutionStatus),
);
router.get(
  "/withdrawals/automation",
  requireAuth,
  requireAdmin,
  asyncHandler(blockchainController.automaticWithdrawalSettings),
);
router.put(
  "/withdrawals/automation",
  requireAuth,
  requireAdmin,
  validateBody(automaticWithdrawalPolicySchema),
  asyncHandler(blockchainController.updateAutomaticWithdrawalPolicy),
);
router.post(
  "/withdrawals/automation/pause",
  requireAuth,
  requireAdmin,
  validateBody(z.object({ reason: z.string().trim().min(3).max(500) })),
  asyncHandler(blockchainController.pauseAutomaticWithdrawalPolicy),
);
router.get(
  "/sweeps/settings",
  requireAuth,
  requireAdmin,
  asyncHandler(blockchainController.sweeperSettings),
);
router.put(
  "/sweeps/settings",
  requireAuth,
  requireAdmin,
  validateBody(sweeperPolicySchema),
  asyncHandler(blockchainController.updateSweeperPolicy),
);
router.post(
  "/sweeps/pause",
  requireAuth,
  requireAdmin,
  validateBody(z.object({ reason: z.string().trim().min(3).max(500) })),
  asyncHandler(blockchainController.pauseSweeperPolicy),
);
router.post(
  "/emergency-stop",
  requireAuth,
  requireAdmin,
  validateBody(z.object({ reason: z.string().trim().min(3).max(500) })),
  asyncHandler(blockchainController.emergencyStop),
);
router.get(
  "/deposit-wallet",
  requireAuth,
  requireOperational,
  asyncHandler(depositWalletController.getWallet),
);
router.get(
  "/deposits",
  requireAuth,
  requireOperational,
  asyncHandler(depositWalletController.listDeposits),
);

export default router;
