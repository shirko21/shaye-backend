import { Router } from "express";
import * as controller from "../controllers/task.controller";
import { requireAuth } from "../middlewares/auth.middleware";
import { requireOperational } from "../middlewares/maintenance.middleware";
import { asyncHandler } from "../utils/response";
const router = Router(); router.use(requireAuth, requireOperational); router.get("/status", asyncHandler(controller.status)); router.post("/claim", asyncHandler(controller.claim)); router.get("/history", asyncHandler(controller.history)); export default router;
