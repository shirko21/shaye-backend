import { Router } from "express";
import auth from "./auth.routes";
import user from "./user.routes";
import wallet from "./wallet.routes";
import deposits from "./deposit.routes";
import withdrawals from "./withdraw.routes";
import tasks from "./task.routes";
import admin from "./admin.routes";
import wheel from "./wheel.routes";
import support from "./support.routes";
import blockchain from "./blockchain.routes";
import * as adminService from "../services/admin.service";
import * as content from "../services/content.service";
import { asyncHandler, ok } from "../utils/response";

const router = Router();

router.use("/auth", auth);
router.use("/user", user);
router.use("/wallet", wallet);
router.use("/deposits", deposits);
router.use("/withdrawals", withdrawals);
router.use("/tasks", tasks);
router.use("/wheel", wheel);
router.use("/support", support);
router.use("/admin", admin);
router.use("/blockchain", blockchain);

router.get(
  "/public/config",
  asyncHandler(async (_req, res) => ok(res, await adminService.publicConfig())),
);
router.get(
  "/public/announcements",
  asyncHandler(async (_req, res) =>
    ok(res, await adminService.listAnnouncements(false)),
  ),
);
router.get(
  "/public/home-content",
  asyncHandler(async (_req, res) => ok(res, await content.getHome())),
);

export default router;
