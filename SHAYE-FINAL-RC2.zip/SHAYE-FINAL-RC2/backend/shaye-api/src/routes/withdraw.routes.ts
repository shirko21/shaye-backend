import { Router } from "express";
import { z } from "zod";
import * as controller from "../controllers/withdraw.controller";
import { requireAuth } from "../middlewares/auth.middleware";
import { requireOperational } from "../middlewares/maintenance.middleware";
import { validateBody } from "../middlewares/validation.middleware";
import { amountSchema, walletAddressSchema } from "../utils/validator";
import { asyncHandler } from "../utils/response";
const router = Router();
router.use(requireAuth, requireOperational);
router.get("/", asyncHandler(controller.list));
router.get("/policy", asyncHandler(controller.policy));
router.post(
  "/",
  validateBody(
    z.object({
      amount: amountSchema,
      walletAddress: walletAddressSchema,
      password: z.string().min(1).max(128),
    }),
  ),
  asyncHandler(controller.create),
);
export default router;
