import { ErrorRequestHandler, RequestHandler } from "express";
import { ZodError } from "zod";
import { AppError } from "../utils/response";
import { logger } from "../utils/logger";

export const notFoundHandler: RequestHandler = (_req, res) => {
  res.status(404).json({
    success: false,
    message: "مسیر پیدا نشد.",
    code: "NOT_FOUND",
  });
};

export const errorHandler: ErrorRequestHandler = (
  error,
  _req,
  res,
  _next,
) => {
  if (error instanceof ZodError) {
    return res.status(400).json({
      success: false,
      message: "اطلاعات ورودی معتبر نیست.",
      code: "VALIDATION_ERROR",
      details: error.flatten(),
    });
  }

  if (error instanceof AppError) {
    return res.status(error.statusCode).json({
      success: false,
      message: error.message,
      code: error.code,
      details: error.details,
    });
  }

  if (error?.code === "23505") {
    return res.status(409).json({
      success: false,
      message: "این اطلاعات قبلاً ثبت شده است.",
      code: "DUPLICATE",
    });
  }

  if (error?.code === "23514" || error?.code === "22P02") {
    return res.status(400).json({
      success: false,
      message: "اطلاعات ورودی با قوانین سامانه سازگار نیست.",
      code: "DATABASE_VALIDATION_ERROR",
    });
  }

  if (String(error?.message || "").includes("CORS")) {
    return res.status(403).json({
      success: false,
      message: "مبدأ درخواست مجاز نیست.",
      code: "CORS_FORBIDDEN",
    });
  }

  logger.error(error);
  return res.status(500).json({
    success: false,
    message: "خطای داخلی سرور.",
    code: "INTERNAL_ERROR",
  });
};
