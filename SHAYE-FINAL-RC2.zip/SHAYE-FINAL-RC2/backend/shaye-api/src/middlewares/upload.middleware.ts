import { RequestHandler } from "express";
import { AppError } from "../utils/response";
export const rejectFileUploads: RequestHandler = (req, _res, next) => {
  if (req.headers["content-type"]?.includes("multipart/form-data")) return next(new AppError(415, "بارگذاری فایل فعال نیست؛ از آدرس تصویر استفاده کنید.", "UPLOAD_DISABLED"));
  next();
};
