import { RequestHandler } from "express";
import { query } from "../config/database";
import { AppError } from "../utils/response";

export const requireOperational: RequestHandler = async (req, _res, next) => {
  try {
    if (req.auth?.role === "ADMIN") return next();

    const result = await query<{ maintenance_mode: boolean }>(
      "SELECT maintenance_mode FROM app_settings WHERE id = 'default'",
    );

    if (result.rows[0]?.maintenance_mode) {
      return next(
        new AppError(
          503,
          "سامانه موقتاً در حال تعمیر است.",
          "MAINTENANCE_MODE",
        ),
      );
    }

    next();
  } catch (error) {
    next(error);
  }
};
