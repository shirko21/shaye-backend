import { RequestHandler } from "express";
import { jwtConfig } from "../config/jwt";
import { AppError } from "../utils/response";
import { verifyAuthToken } from "../utils/jwt";
import { query } from "../config/database";
export const requireAuth:RequestHandler=async(req,_res,next)=>{try{const bearer=req.headers.authorization?.startsWith("Bearer ")?req.headers.authorization.slice(7):null;const token=req.cookies?.[jwtConfig.cookieName]||bearer;if(!token)throw new AppError(401,"برای ادامه وارد حساب شوید.","UNAUTHORIZED");const p=verifyAuthToken(token);const r=await query<{id:string,email:string,role:"USER"|"ADMIN",is_active:boolean}>("SELECT id,email,role,is_active FROM users WHERE id=$1",[p.userId]);const u=r.rows[0];if(!u?.is_active)throw new AppError(401,"حساب معتبر نیست.","UNAUTHORIZED");req.auth={userId:u.id,email:u.email,role:u.role};next()}catch(e){next(e instanceof AppError?e:new AppError(401,"نشست شما منقضی شده است.","INVALID_TOKEN"))}};
