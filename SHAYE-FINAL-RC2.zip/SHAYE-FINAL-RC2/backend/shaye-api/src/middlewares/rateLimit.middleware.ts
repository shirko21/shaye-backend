import rateLimit from "express-rate-limit";
import { appConfig } from "../config/app";

export const apiLimiter = rateLimit({ ...appConfig.apiRateLimit, standardHeaders: true, legacyHeaders: false });
export const authLimiter = rateLimit({ ...appConfig.authRateLimit, standardHeaders: true, legacyHeaders: false, message: { success: false, message: "تلاش‌های بیش از حد؛ کمی بعد دوباره امتحان کنید.", code: "RATE_LIMIT" } });
