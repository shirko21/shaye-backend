import { RequestHandler } from "express";
import { ZodTypeAny } from "zod";

export const validateBody = (schema: ZodTypeAny): RequestHandler => (req, _res, next) => {
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return next(parsed.error);
  req.body = parsed.data;
  next();
};
