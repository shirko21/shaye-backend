import { RequestHandler } from "express";
import { AppError } from "../utils/response";
export const requireAdmin:RequestHandler=(req,_res,next)=>{if(!req.auth||req.auth.role!=="ADMIN")return next(new AppError(403,"دسترسی مدیر لازم است.","FORBIDDEN"));next()};
