import { PoolClient } from "pg";
import { query } from "../config/database";
import { randomId } from "../utils/helpers";
import { AppError } from "../utils/response";

export interface NotificationInput {
  userId: string;
  type: string;
  title: string;
  body: string;
  metadata?: Record<string, unknown>;
}

export async function createNotification(
  client: PoolClient,
  input: NotificationInput,
): Promise<string> {
  const id = randomId();
  await client.query(
    `INSERT INTO user_notifications(
       id, user_id, type, title, body, metadata
     ) VALUES($1,$2,$3,$4,$5,$6::jsonb)`,
    [
      id,
      input.userId,
      input.type.trim().slice(0, 80),
      input.title.trim().slice(0, 160),
      input.body.trim().slice(0, 2_000),
      JSON.stringify(input.metadata ?? {}),
    ],
  );
  return id;
}

export async function listNotifications(
  userId: string,
  unreadOnly = false,
  limit = 30,
) {
  const safeLimit = Math.max(1, Math.min(Math.trunc(limit) || 30, 100));
  const result = await query(
    `SELECT id, type, title, body, metadata, read_at, created_at
     FROM user_notifications
     WHERE user_id = $1
       AND ($2 = FALSE OR read_at IS NULL)
     ORDER BY created_at DESC
     LIMIT $3`,
    [userId, unreadOnly, safeLimit],
  );

  return result.rows.map((row) => ({
    id: row.id,
    type: row.type,
    title: row.title,
    body: row.body,
    metadata: row.metadata ?? {},
    readAt: row.read_at,
    createdAt: row.created_at,
  }));
}

export async function markNotificationRead(userId: string, id: string) {
  const result = await query(
    `UPDATE user_notifications
     SET read_at = COALESCE(read_at, now())
     WHERE id = $1 AND user_id = $2
     RETURNING id, read_at`,
    [id, userId],
  );
  if (!result.rows[0]) {
    throw new AppError(404, "اعلان پیدا نشد.", "NOTIFICATION_NOT_FOUND");
  }
  return { id: result.rows[0].id, readAt: result.rows[0].read_at };
}
