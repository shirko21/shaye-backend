import { query, withTransaction } from "../config/database";
import { AppError } from "../utils/response";
import { getSettings } from "./settings.service";
import { taskWindow } from "../utils/date";
import { percentage } from "../utils/wallet";
import { randomId } from "../utils/helpers";
import { releaseMaturedPositions } from "./wallet.service";

export async function taskStatus(userId: string) {
  await releaseMaturedPositions(userId);
  const settings = await getSettings();
  const window = taskWindow(
    new Date(),
    settings.timezone,
    settings.taskHour,
  );

  const [userResult, claimResult] = await Promise.all([
    query(
      `SELECT u.vip_level, u.locked_balance, v.daily_rate
       FROM users u
       LEFT JOIN vip_tiers v ON v.level = u.vip_level AND v.is_active = TRUE
       WHERE u.id = $1`,
      [userId],
    ),
    query(
      `SELECT * FROM task_claims
       WHERE user_id = $1 AND claim_date_key = $2`,
      [userId, window.key],
    ),
  ]);

  const user = userResult.rows[0];
  if (!user) throw new AppError(404, "کاربر پیدا نشد.", "USER_NOT_FOUND");

  const claim = claimResult.rows[0];
  const rate = Number(user.daily_rate || 0);
  const base = Number(user.locked_balance || 0);

  return {
    ...window,
    claimed: Boolean(claim),
    claim: claim
      ? {
          id: claim.id,
          claimDateKey: claim.claim_date_key,
          baseAmount: Number(claim.base_amount),
          rate: Number(claim.rate),
          reward: Number(claim.reward),
          createdAt: claim.created_at,
        }
      : null,
    vipLevel: user.vip_level || 0,
    lockedBalance: base,
    rate,
    estimatedReward: percentage(base, rate),
  };
}

export async function claimTask(userId: string) {
  await releaseMaturedPositions(userId);
  const settings = await getSettings();
  const window = taskWindow(
    new Date(),
    settings.timezone,
    settings.taskHour,
  );

  if (!window.isOpen) {
    throw new AppError(
      400,
      "وظیفه روزانه هنوز باز نشده است.",
      "TASK_CLOSED",
    );
  }

  return withTransaction(async (client) => {
    const userResult = await client.query(
      `SELECT u.vip_level, u.locked_balance, v.daily_rate
       FROM users u
       LEFT JOIN vip_tiers v ON v.level = u.vip_level AND v.is_active = TRUE
       WHERE u.id = $1
       FOR UPDATE OF u`,
      [userId],
    );
    const user = userResult.rows[0];

    if (
      !user ||
      Number(user.vip_level) === 0 ||
      Number(user.locked_balance) <= 0 ||
      Number(user.daily_rate) <= 0
    ) {
      throw new AppError(
        400,
        "برای دریافت پاداش باید سرمایه قفل‌شده و VIP فعال داشته باشید.",
        "VIP_REQUIRED",
      );
    }

    const reward = percentage(user.locked_balance, user.daily_rate);
    if (reward <= 0) {
      throw new AppError(
        400,
        "مقدار پاداش این دوره صفر است.",
        "ZERO_REWARD",
      );
    }

    const claimId = randomId();
    try {
      await client.query(
        `INSERT INTO task_claims(
          id, claim_date_key, base_amount, rate, reward, user_id
        ) VALUES($1, $2, $3, $4, $5, $6)`,
        [
          claimId,
          window.key,
          user.locked_balance,
          user.daily_rate,
          reward,
          userId,
        ],
      );
    } catch (error: any) {
      if (error?.code === "23505") {
        throw new AppError(
          409,
          "پاداش این دوره قبلاً دریافت شده است.",
          "ALREADY_CLAIMED",
        );
      }
      throw error;
    }

    await client.query(
      `UPDATE users
       SET profit_balance = profit_balance + $1,
           total_profit = total_profit + $1,
           updated_at = now()
       WHERE id = $2`,
      [reward, userId],
    );

    await client.query(
      `INSERT INTO transactions(
        id, type, amount, description, metadata, user_id
      ) VALUES($1, 'DAILY_REWARD', $2, $3, $4, $5)`,
      [
        randomId(),
        reward,
        `پاداش روزانه VIP ${user.vip_level}`,
        JSON.stringify({ claimId, claimDateKey: window.key }),
        userId,
      ],
    );

    return {
      id: claimId,
      claimDateKey: window.key,
      baseAmount: Number(user.locked_balance),
      rate: Number(user.daily_rate),
      reward,
    };
  });
}

export async function taskHistory(userId: string) {
  const result = await query(
    `SELECT * FROM task_claims
     WHERE user_id = $1
     ORDER BY created_at DESC
     LIMIT 100`,
    [userId],
  );

  return result.rows.map((claim) => ({
    id: claim.id,
    claimDateKey: claim.claim_date_key,
    baseAmount: Number(claim.base_amount),
    rate: Number(claim.rate),
    reward: Number(claim.reward),
    createdAt: claim.created_at,
  }));
}
