import fs from "fs";
import { JsonRpcProvider, Wallet, getAddress } from "ethers";
import { blockchainConfig } from "../config/blockchain";

let cachedWallet: Wallet | null = null;

function readPrivateKey(): string {
  const file = blockchainConfig.hotWalletPrivateKeyFile;
  let value = "";
  try {
    value = fs.readFileSync(file, "utf8").trim();
  } catch {
    throw new Error(`Hot wallet secret file is not readable: ${file}`);
  }

  if (!/^0x[0-9a-fA-F]{64}$/.test(value)) {
    throw new Error("Hot wallet private key secret is empty or invalid");
  }
  return value;
}

export function getHotWalletSigner(provider: JsonRpcProvider): Wallet {
  if (!blockchainConfig.hotWalletAddress) {
    throw new Error("HOT_WALLET_ADDRESS is not configured");
  }

  if (!cachedWallet) {
    cachedWallet = new Wallet(readPrivateKey());
  }

  const actual = getAddress(cachedWallet.address);
  const expected = getAddress(blockchainConfig.hotWalletAddress);
  if (actual !== expected) {
    throw new Error("Hot wallet private key does not match HOT_WALLET_ADDRESS");
  }

  return cachedWallet.connect(provider);
}

export function clearHotWalletSignerCache(): void {
  cachedWallet = null;
}
