import { PoolClient } from "pg";
import { blockchainConfig } from "../config/blockchain";
import { query, withTransaction } from "../config/database";
import {
  BlockchainControls,
  BlockchainJobRow,
  BlockchainJobType,
  LedgerPostingInput,
} from "../db/blockchain.types";
import { assertPositiveDecimal } from "../utils/decimal";
import { randomId } from "../utils/helpers";

export async function syncBlockchainSettingsFromRuntime(): Promise<void> {
  await query(
    `INSERT INTO blockchain_settings(
       id, network, chain_id, token_contract, token_decimals,
       required_confirmations, reorg_buffer_blocks, scan_batch_size
     ) VALUES('default',$1,$2,$3,$4,$5,$6,$7)
     ON CONFLICT(id) DO UPDATE SET
       network = EXCLUDED.network,
       chain_id = EXCLUDED.chain_id,
       token_contract = EXCLUDED.token_contract,
       token_decimals = EXCLUDED.token_decimals,
       required_confirmations = EXCLUDED.required_confirmations,
       reorg_buffer_blocks = EXCLUDED.reorg_buffer_blocks,
       scan_batch_size = EXCLUDED.scan_batch_size,
       updated_at = now()`,
    [
      blockchainConfig.network.name,
      blockchainConfig.network.chainId,
      blockchainConfig.tokenAddress,
      blockchainConfig.expectedTokenDecimals ?? 18,
      blockchainConfig.requiredConfirmations,
      blockchainConfig.reorgBufferBlocks,
      blockchainConfig.scanBatchSize,
    ],
  );
}

export async function getBlockchainControls(): Promise<BlockchainControls> {
  const result = await query(
    `SELECT network, chain_id, token_contract, token_symbol, token_decimals,
            required_confirmations, reorg_buffer_blocks, scan_batch_size,
            deposits_enabled, withdrawals_enabled, sweeps_enabled,
            sweep_worker_enabled, sweep_min_amount, sweep_discovery_batch_size,
            sweep_job_batch_size, sweep_max_concurrent, sweep_target_gas_bnb,
            sweep_gas_wallet_min_bnb_reserve, sweep_pause_reason, sweep_paused_at,
            auto_credit_enabled, withdrawal_worker_enabled,
            withdrawal_approval_required, auto_withdrawals_enabled,
            auto_withdrawal_max_amount, auto_withdrawal_daily_limit,
            auto_withdrawal_daily_count_limit, auto_withdrawal_max_concurrent,
            hot_wallet_min_token_reserve, hot_wallet_min_bnb_reserve,
            auto_withdrawal_pause_reason, auto_withdrawal_paused_at,
            emergency_stop, emergency_reason, updated_at
     FROM blockchain_settings
     WHERE id = 'default'`,
  );
  const row = result.rows[0];
  if (!row) {
    throw new Error("Blockchain settings row is missing");
  }

  return {
    network: row.network,
    chainId: Number(row.chain_id),
    tokenContract: row.token_contract,
    tokenSymbol: row.token_symbol,
    tokenDecimals: Number(row.token_decimals),
    requiredConfirmations: Number(row.required_confirmations),
    reorgBufferBlocks: Number(row.reorg_buffer_blocks),
    scanBatchSize: Number(row.scan_batch_size),
    depositsEnabled: row.deposits_enabled,
    withdrawalsEnabled: row.withdrawals_enabled,
    sweepsEnabled: row.sweeps_enabled,
    sweepWorkerEnabled: row.sweep_worker_enabled,
    sweepMinAmount: Number(row.sweep_min_amount),
    sweepDiscoveryBatchSize: Number(row.sweep_discovery_batch_size),
    sweepJobBatchSize: Number(row.sweep_job_batch_size),
    sweepMaxConcurrent: Number(row.sweep_max_concurrent),
    sweepTargetGasBnb: Number(row.sweep_target_gas_bnb),
    sweepGasWalletMinBnbReserve: Number(row.sweep_gas_wallet_min_bnb_reserve),
    sweepPauseReason: row.sweep_pause_reason,
    sweepPausedAt: row.sweep_paused_at,
    autoCreditEnabled: row.auto_credit_enabled,
    withdrawalWorkerEnabled: row.withdrawal_worker_enabled,
    withdrawalApprovalRequired: row.withdrawal_approval_required,
    autoWithdrawalsEnabled: row.auto_withdrawals_enabled,
    autoWithdrawalMaxAmount: Number(row.auto_withdrawal_max_amount),
    autoWithdrawalDailyLimit: Number(row.auto_withdrawal_daily_limit),
    autoWithdrawalDailyCountLimit: Number(row.auto_withdrawal_daily_count_limit),
    autoWithdrawalMaxConcurrent: Number(row.auto_withdrawal_max_concurrent),
    hotWalletMinTokenReserve: Number(row.hot_wallet_min_token_reserve),
    hotWalletMinBnbReserve: Number(row.hot_wallet_min_bnb_reserve),
    autoWithdrawalPauseReason: row.auto_withdrawal_pause_reason,
    autoWithdrawalPausedAt: row.auto_withdrawal_paused_at,
    emergencyStop: row.emergency_stop,
    emergencyReason: row.emergency_reason,
    updatedAt: row.updated_at,
  };
}

export async function enqueueBlockchainJob(input: {
  type: BlockchainJobType;
  idempotencyKey: string;
  payload?: Record<string, unknown>;
  priority?: number;
  maxAttempts?: number;
  runAfter?: Date;
}): Promise<BlockchainJobRow> {
  const result = await query<BlockchainJobRow>(
    `INSERT INTO blockchain_jobs(
       id, job_type, idempotency_key, payload, priority, max_attempts, run_after
     ) VALUES($1,$2,$3,$4::jsonb,$5,$6,$7)
     ON CONFLICT(idempotency_key) DO UPDATE
       SET idempotency_key = EXCLUDED.idempotency_key
     RETURNING *`,
    [
      randomId(),
      input.type,
      input.idempotencyKey,
      JSON.stringify(input.payload ?? {}),
      input.priority ?? 100,
      input.maxAttempts ?? 10,
      input.runAfter ?? new Date(),
    ],
  );
  return result.rows[0]!;
}

export async function claimBlockchainJobs(input: {
  workerId: string;
  types: BlockchainJobType[];
  limit?: number;
  leaseSeconds?: number;
}): Promise<BlockchainJobRow[]> {
  if (input.types.length === 0) return [];
  const limit = Math.max(1, Math.min(input.limit ?? 10, 100));
  const leaseSeconds = Math.max(10, Math.min(input.leaseSeconds ?? 60, 3600));

  return withTransaction(async (client) => {
    const result = await client.query<BlockchainJobRow>(
      `WITH candidates AS (
         SELECT id
         FROM blockchain_jobs
         WHERE job_type = ANY($1::text[])
           AND status IN ('PENDING','RETRY')
           AND run_after <= now()
         ORDER BY priority ASC, created_at ASC
         FOR UPDATE SKIP LOCKED
         LIMIT $2
       )
       UPDATE blockchain_jobs j
       SET status = 'RUNNING',
           attempts = attempts + 1,
           locked_by = $3,
           locked_at = now(),
           lock_expires_at = now() + ($4 || ' seconds')::interval,
           updated_at = now()
       FROM candidates c
       WHERE j.id = c.id
       RETURNING j.*`,
      [input.types, limit, input.workerId, leaseSeconds],
    );
    return result.rows;
  });
}

export async function completeBlockchainJob(
  jobId: string,
  workerId: string,
  result: Record<string, unknown> = {},
): Promise<boolean> {
  const update = await query(
    `UPDATE blockchain_jobs
     SET status = 'COMPLETED', result = $1::jsonb, completed_at = now(),
         locked_by = NULL, locked_at = NULL, lock_expires_at = NULL,
         last_error = NULL, updated_at = now()
     WHERE id = $2 AND status = 'RUNNING' AND locked_by = $3`,
    [JSON.stringify(result), jobId, workerId],
  );
  return update.rowCount === 1;
}

export async function failBlockchainJob(input: {
  jobId: string;
  workerId: string;
  error: string;
  retryDelaySeconds?: number;
}): Promise<boolean> {
  const retryDelay = Math.max(1, Math.min(input.retryDelaySeconds ?? 30, 86_400));
  const update = await query(
    `UPDATE blockchain_jobs
     SET status = CASE WHEN attempts >= max_attempts THEN 'FAILED' ELSE 'RETRY' END,
         run_after = CASE
           WHEN attempts >= max_attempts THEN run_after
           ELSE now() + ($1 || ' seconds')::interval
         END,
         last_error = left($2, 4000),
         locked_by = NULL, locked_at = NULL, lock_expires_at = NULL,
         updated_at = now()
     WHERE id = $3 AND status = 'RUNNING' AND locked_by = $4`,
    [retryDelay, input.error, input.jobId, input.workerId],
  );
  return update.rowCount === 1;
}

export async function recoverExpiredBlockchainJobs(): Promise<number> {
  const result = await query(
    `UPDATE blockchain_jobs
     SET status = CASE WHEN attempts >= max_attempts THEN 'FAILED' ELSE 'RETRY' END,
         run_after = now(),
         last_error = COALESCE(last_error, 'Worker lease expired'),
         locked_by = NULL, locked_at = NULL, lock_expires_at = NULL,
         updated_at = now()
     WHERE status = 'RUNNING'
       AND lock_expires_at IS NOT NULL
       AND lock_expires_at < now()`,
  );
  return result.rowCount ?? 0;
}

export async function ensureUserLedgerAccounts(
  client: PoolClient,
  userId: string,
  currency = "USDT",
): Promise<{ principalAccountId: string; profitAccountId: string }> {
  const normalizedCurrency = currency.trim().toUpperCase();
  const principalAccountId = `usr-${userId}-${normalizedCurrency.toLowerCase()}-principal`;
  const profitAccountId = `usr-${userId}-${normalizedCurrency.toLowerCase()}-profit`;

  await client.query(
    `INSERT INTO ledger_accounts(
       id, code, name, account_type, normal_side, currency, user_id
     ) VALUES
       ($1,$2,'User principal','LIABILITY','CREDIT',$3,$4),
       ($5,$6,'User profit','LIABILITY','CREDIT',$3,$4)
     ON CONFLICT(id) DO NOTHING`,
    [
      principalAccountId,
      `USR-${userId}-${normalizedCurrency}-PRINCIPAL`,
      normalizedCurrency,
      userId,
      profitAccountId,
      `USR-${userId}-${normalizedCurrency}-PROFIT`,
    ],
  );

  return { principalAccountId, profitAccountId };
}

export async function postLedgerJournal(
  client: PoolClient,
  input: LedgerPostingInput,
): Promise<string> {
  if (!input.idempotencyKey.trim()) {
    throw new Error("Ledger idempotency key is required");
  }
  if (!input.description.trim()) {
    throw new Error("Ledger description is required");
  }
  if (input.entries.length < 2) {
    throw new Error("A ledger journal requires at least two entries");
  }

  for (const entry of input.entries) {
    assertPositiveDecimal(entry.amount);
  }

  const existing = await client.query<{ id: string }>(
    "SELECT id FROM ledger_journals WHERE idempotency_key = $1",
    [input.idempotencyKey],
  );
  if (existing.rows[0]) return existing.rows[0].id;

  const journalId = randomId();
  await client.query(
    `INSERT INTO ledger_journals(
       id, idempotency_key, reference_type, reference_id, description, metadata
     ) VALUES($1,$2,$3,$4,$5,$6::jsonb)`,
    [
      journalId,
      input.idempotencyKey,
      input.referenceType ?? null,
      input.referenceId ?? null,
      input.description,
      JSON.stringify(input.metadata ?? {}),
    ],
  );

  for (const entry of input.entries) {
    await client.query(
      `INSERT INTO ledger_entries(
         id, journal_id, account_id, user_id, direction, amount, memo, metadata
       ) VALUES($1,$2,$3,$4,$5,$6,$7,$8::jsonb)`,
      [
        randomId(),
        journalId,
        entry.accountId,
        entry.userId ?? null,
        entry.direction,
        entry.amount,
        entry.memo ?? null,
        JSON.stringify(entry.metadata ?? {}),
      ],
    );
  }

  await client.query(
    `UPDATE ledger_journals
     SET status = 'POSTED', posted_at = now(), updated_at = now()
     WHERE id = $1`,
    [journalId],
  );

  return journalId;
}

export async function postLedgerJournalAtomically(
  input: LedgerPostingInput,
): Promise<string> {
  return withTransaction((client) => postLedgerJournal(client, input));
}


export async function activateBlockchainEmergencyStop(input: {
  actorId: string;
  reason: string;
}): Promise<BlockchainControls> {
  const reason = input.reason.trim().slice(0, 500);
  if (reason.length < 3) {
    throw new Error("Emergency stop reason is required");
  }

  await withTransaction(async (client) => {
    await client.query(
      `UPDATE blockchain_settings
       SET emergency_stop = TRUE,
           emergency_reason = $1,
           auto_credit_enabled = FALSE,
           withdrawal_worker_enabled = FALSE,
           withdrawals_enabled = FALSE,
           sweeps_enabled = FALSE,
           sweep_worker_enabled = FALSE,
           sweep_pause_reason = $1,
           sweep_paused_at = now(),
           updated_by = $2,
           updated_at = now()
       WHERE id = 'default'`,
      [reason, input.actorId],
    );
    await client.query(
      `INSERT INTO admin_action_logs(
         id, action, target_type, target_id, metadata, actor_id
       ) VALUES($1,'BLOCKCHAIN_EMERGENCY_STOP','BlockchainSettings','default',$2::jsonb,$3)`,
      [randomId(), JSON.stringify({ reason }), input.actorId],
    );
  });

  return getBlockchainControls();
}
