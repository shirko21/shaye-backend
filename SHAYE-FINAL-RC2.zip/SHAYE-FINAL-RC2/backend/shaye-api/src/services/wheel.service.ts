import crypto from "crypto";
import { PoolClient } from "pg";
import { query, withTransaction } from "../config/database";
import { AppError } from "../utils/response";
import { money, randomId } from "../utils/helpers";

const mapSettings = (row: any) => ({
  enabled: row.enabled,
  spinDurationMs: row.spin_duration_ms,
  registrationSpins: row.registration_spins,
  referralSpins: row.referral_spins,
  notice: row.notice,
  updatedAt: row.updated_at,
});

const mapPrize = (row: any) => ({
  id: row.id,
  title: row.title,
  subtitle: row.subtitle || "",
  amount: Number(row.amount),
  weight: Number(row.weight),
  isActive: row.is_active,
  sortOrder: row.sort_order,
});

export async function config() {
  const [settingsResult, prizesResult] = await Promise.all([
    query("SELECT * FROM wheel_settings WHERE id = 'default'"),
    query(
      "SELECT * FROM wheel_prizes WHERE is_active = TRUE ORDER BY sort_order, id",
    ),
  ]);

  return {
    settings: mapSettings(settingsResult.rows[0]),
    prizes: prizesResult.rows.map(mapPrize),
  };
}

export async function status(userId: string) {
  const [wheelConfig, userResult, historyResult] = await Promise.all([
    config(),
    query(
      "SELECT wheel_spins, wheel_spins_used FROM users WHERE id = $1",
      [userId],
    ),
    query(
      `SELECT h.*, p.title
       FROM wheel_history h
       LEFT JOIN wheel_prizes p ON p.id = h.prize_id
       WHERE h.user_id = $1
       ORDER BY h.created_at DESC
       LIMIT 50`,
      [userId],
    ),
  ]);

  const user = userResult.rows[0];
  if (!user) {
    throw new AppError(404, "کاربر پیدا نشد.", "USER_NOT_FOUND");
  }

  return {
    ...wheelConfig,
    spins: Number(user.wheel_spins),
    spinsUsed: Number(user.wheel_spins_used),
    history: historyResult.rows.map((row) => ({
      id: row.id,
      prizeId: row.prize_id,
      rewardAmount: Number(row.reward_amount),
      rewardText: row.reward_text,
      status: row.status,
      createdAt: row.created_at,
    })),
  };
}

function pickWeighted(rows: any[]) {
  const eligible = rows.filter(
    (row) => row.is_active && Number(row.weight) > 0,
  );

  if (!eligible.length) {
    throw new AppError(
      409,
      "جایزه فعالی برای گردونه تعریف نشده است.",
      "NO_WHEEL_PRIZE",
    );
  }

  // Millesimal precision keeps the total within crypto.randomInt's safe range.
  const weights = eligible.map((row) =>
    Math.max(1, Math.round(Number(row.weight) * 1_000)),
  );
  const total = weights.reduce((sum, value) => sum + value, 0);
  let random = crypto.randomInt(0, total);

  for (let index = 0; index < eligible.length; index += 1) {
    const weight = weights[index] ?? 0;
    if (random < weight) return eligible[index];
    random -= weight;
  }

  return eligible[eligible.length - 1];
}

export async function spin(userId: string) {
  return withTransaction(async (client) => {
    const settingsResult = await client.query(
      "SELECT * FROM wheel_settings WHERE id = 'default' FOR UPDATE",
    );
    const settings = settingsResult.rows[0];

    if (!settings?.enabled) {
      throw new AppError(
        409,
        "گردونه در حال حاضر غیرفعال است.",
        "WHEEL_DISABLED",
      );
    }

    const userResult = await client.query(
      "SELECT wheel_spins FROM users WHERE id = $1 FOR UPDATE",
      [userId],
    );
    const user = userResult.rows[0];

    if (!user) {
      throw new AppError(404, "کاربر پیدا نشد.", "USER_NOT_FOUND");
    }
    if (Number(user.wheel_spins) <= 0) {
      throw new AppError(400, "فرصت گردونه ندارید.", "NO_SPINS");
    }

    const prizesResult = await client.query(
      "SELECT * FROM wheel_prizes WHERE is_active = TRUE ORDER BY sort_order, id",
    );
    const prize = pickWeighted(prizesResult.rows);
    const reward = money(prize.amount);
    const historyId = randomId();

    await client.query(
      `UPDATE users
       SET wheel_spins = wheel_spins - 1,
           wheel_spins_used = wheel_spins_used + 1,
           profit_balance = profit_balance + $1,
           total_profit = total_profit + $1,
           updated_at = now()
       WHERE id = $2`,
      [reward, userId],
    );

    await client.query(
      `INSERT INTO wheel_history(
        id, user_id, prize_id, reward_amount, reward_text
      ) VALUES($1, $2, $3, $4, $5)`,
      [historyId, userId, prize.id, reward, prize.title],
    );

    await client.query(
      `INSERT INTO transactions(
        id, type, amount, description, metadata, user_id
      ) VALUES($1, 'WHEEL_REWARD', $2, $3, $4, $5)`,
      [
        randomId(),
        reward,
        "جایزه گردونه",
        JSON.stringify({ wheelHistoryId: historyId, prizeId: prize.id }),
        userId,
      ],
    );

    return {
      id: historyId,
      prize: mapPrize(prize),
      rewardAmount: reward,
      spinsRemaining: Number(user.wheel_spins) - 1,
      createdAt: new Date().toISOString(),
    };
  });
}

export async function adminConfig() {
  const [settingsResult, prizesResult] = await Promise.all([
    query("SELECT * FROM wheel_settings WHERE id = 'default'"),
    query("SELECT * FROM wheel_prizes ORDER BY sort_order, id"),
  ]);

  return {
    settings: mapSettings(settingsResult.rows[0]),
    prizes: prizesResult.rows.map(mapPrize),
  };
}

export async function updateConfig(adminId: string, input: any) {
  return withTransaction(async (client) => {
    await client.query(
      `UPDATE wheel_settings
       SET enabled = $1,
           spin_duration_ms = $2,
           registration_spins = $3,
           referral_spins = $4,
           notice = $5,
           updated_at = now()
       WHERE id = 'default'`,
      [
        input.enabled,
        input.spinDurationMs,
        input.registrationSpins,
        input.referralSpins,
        input.notice,
      ],
    );

    const submittedIds: string[] = [];
    for (let index = 0; index < input.prizes.length; index += 1) {
      const prize = input.prizes[index];
      const id = prize.id || randomId();
      submittedIds.push(id);

      await client.query(
        `INSERT INTO wheel_prizes(
          id, title, subtitle, amount, weight, is_active, sort_order
        ) VALUES($1, $2, $3, $4, $5, $6, $7)
        ON CONFLICT(id) DO UPDATE SET
          title = EXCLUDED.title,
          subtitle = EXCLUDED.subtitle,
          amount = EXCLUDED.amount,
          weight = EXCLUDED.weight,
          is_active = EXCLUDED.is_active,
          sort_order = EXCLUDED.sort_order,
          updated_at = now()`,
        [
          id,
          prize.title,
          prize.subtitle || null,
          money(prize.amount),
          Number(prize.weight),
          prize.isActive,
          index,
        ],
      );
    }

    await client.query(
      "DELETE FROM wheel_prizes WHERE NOT (id = ANY($1::text[]))",
      [submittedIds],
    );

    await client.query(
      `INSERT INTO admin_action_logs(
        id, action, target_type, target_id, metadata, actor_id
      ) VALUES($1, 'UPDATE_WHEEL', 'Wheel', 'default', $2, $3)`,
      [randomId(), JSON.stringify(input), adminId],
    );

    const settingsResult = await client.query(
      "SELECT * FROM wheel_settings WHERE id = 'default'",
    );
    const prizesResult = await client.query(
      "SELECT * FROM wheel_prizes ORDER BY sort_order, id",
    );

    return {
      settings: mapSettings(settingsResult.rows[0]),
      prizes: prizesResult.rows.map(mapPrize),
    };
  });
}

export async function setUserSpins(
  adminId: string,
  userId: string,
  spins: number,
) {
  return withTransaction(async (client) => {
    const result = await client.query(
      `UPDATE users
       SET wheel_spins = $1, updated_at = now()
       WHERE id = $2
       RETURNING id, email, wheel_spins, wheel_spins_used`,
      [spins, userId],
    );

    const user = result.rows[0];
    if (!user) {
      throw new AppError(404, "کاربر پیدا نشد.", "USER_NOT_FOUND");
    }

    await client.query(
      `INSERT INTO admin_action_logs(
        id, action, target_type, target_id, metadata, actor_id
      ) VALUES($1, 'SET_USER_SPINS', 'User', $2, $3, $4)`,
      [randomId(), userId, JSON.stringify({ spins }), adminId],
    );

    return {
      id: user.id,
      email: user.email,
      wheelSpins: Number(user.wheel_spins),
      wheelSpinsUsed: Number(user.wheel_spins_used),
    };
  });
}

export async function adminHistory(search = "", limit = 100) {
  const safeLimit = Math.min(Math.max(Math.trunc(limit), 10), 500);
  const result = await query(
    `SELECT h.*, u.email, p.title
     FROM wheel_history h
     JOIN users u ON u.id = h.user_id
     LEFT JOIN wheel_prizes p ON p.id = h.prize_id
     WHERE ($1 = '' OR u.email ILIKE '%' || $1 || '%'
       OR h.reward_text ILIKE '%' || $1 || '%')
     ORDER BY h.created_at DESC
     LIMIT $2`,
    [search.trim(), safeLimit],
  );

  return result.rows.map((row) => ({
    id: row.id,
    email: row.email,
    prizeId: row.prize_id,
    rewardAmount: Number(row.reward_amount),
    rewardText: row.reward_text,
    status: row.status,
    createdAt: row.created_at,
  }));
}

export function isFirstVipReferralGrantEligible(
  vipLevelBefore: number,
  vipLevelAfter: number,
): boolean {
  return Number(vipLevelBefore) === 0 && Number(vipLevelAfter) >= 1;
}

export function firstVipReferralSpinCount(configuredValue: number): number {
  return Number(configuredValue) > 0 ? 1 : 0;
}

export async function grantFirstVipReferralSpins(
  client: PoolClient,
  input: {
    inviterId: string;
    inviteeId: string;
    blockchainDepositId?: string | null;
    sourceDepositId?: string | null;
    vipLevelBefore: number;
    vipLevelAfter: number;
  },
): Promise<{ spins: number; grantId: string | null }> {
  if (!isFirstVipReferralGrantEligible(
    input.vipLevelBefore,
    input.vipLevelAfter,
  )) {
    return { spins: 0, grantId: null };
  }

  const settingsResult = await client.query(
    "SELECT referral_spins FROM wheel_settings WHERE id = 'default'",
  );
  // referral_spins acts only as an on/off switch for this rule. A qualifying
  // direct invitee can create exactly one lifetime chance, as required by the
  // product rule, even if an older configuration contains a larger number.
  const spins = firstVipReferralSpinCount(
    Number(settingsResult.rows[0]?.referral_spins || 0),
  );
  if (spins <= 0) return { spins: 0, grantId: null };

  const grantId = randomId();
  const inserted = await client.query<{ id: string }>(
    `INSERT INTO referral_wheel_grants(
       id, inviter_id, invitee_id, blockchain_deposit_id, source_deposit_id,
       vip_level_before, vip_level_after, spins_granted, metadata
     )
     SELECT $1,$2,$3,$4,$5,$6,$7,$8,$9::jsonb
     WHERE EXISTS (
       SELECT 1 FROM users
       WHERE id = $2 AND is_active = TRUE
     )
     ON CONFLICT(invitee_id) DO NOTHING
     RETURNING id`,
    [
      grantId,
      input.inviterId,
      input.inviteeId,
      input.blockchainDepositId ?? null,
      input.sourceDepositId ?? null,
      input.vipLevelBefore,
      input.vipLevelAfter,
      spins,
      JSON.stringify({ reason: "FIRST_VIP_ACTIVATION" }),
    ],
  );

  if (!inserted.rows[0]) return { spins: 0, grantId: null };

  const updated = await client.query(
    `UPDATE users
     SET wheel_spins = wheel_spins + $1, updated_at = now()
     WHERE id = $2 AND is_active = TRUE`,
    [spins, input.inviterId],
  );
  if (updated.rowCount !== 1) {
    throw new Error("Inviter became inactive while granting wheel spins");
  }

  return { spins, grantId: inserted.rows[0].id };
}


export async function adminReferralGrants(search = "", limit = 100) {
  const safeLimit = Math.min(Math.max(Math.trunc(limit), 10), 500);
  const result = await query(
    `SELECT g.*, inviter.email AS inviter_email, invitee.email AS invitee_email,
            COALESCE(bd.amount, d.amount) AS qualifying_amount
     FROM referral_wheel_grants g
     JOIN users inviter ON inviter.id = g.inviter_id
     JOIN users invitee ON invitee.id = g.invitee_id
     LEFT JOIN blockchain_deposits bd ON bd.id = g.blockchain_deposit_id
     LEFT JOIN deposits d ON d.id = g.source_deposit_id
     WHERE ($1 = '' OR inviter.email ILIKE '%' || $1 || '%'
       OR invitee.email ILIKE '%' || $1 || '%')
     ORDER BY g.created_at DESC
     LIMIT $2`,
    [search.trim(), safeLimit],
  );

  return result.rows.map((row) => ({
    id: row.id,
    inviterEmail: row.inviter_email,
    inviteeEmail: row.invitee_email,
    spinsGranted: Number(row.spins_granted),
    vipLevelBefore: Number(row.vip_level_before),
    vipLevelAfter: Number(row.vip_level_after),
    qualifyingAmount:
      row.qualifying_amount == null ? null : Number(row.qualifying_amount),
    reason: row.reason,
    createdAt: row.created_at,
  }));
}
