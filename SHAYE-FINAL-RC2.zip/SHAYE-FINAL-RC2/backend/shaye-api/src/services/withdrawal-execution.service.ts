import {
  Contract,
  Interface,
  TransactionReceipt,
  formatEther,
  formatUnits,
  getAddress,
  keccak256,
  parseEther,
  parseUnits,
  ZeroAddress,
} from "ethers";
import { PoolClient } from "pg";
import { blockchainConfig } from "../config/blockchain";
import { query, withTransaction } from "../config/database";
import { BlockchainJobRow } from "../db/blockchain.types";
import {
  claimBlockchainJobs,
  completeBlockchainJob,
  ensureUserLedgerAccounts,
  failBlockchainJob,
  getBlockchainControls,
  postLedgerJournal,
  recoverExpiredBlockchainJobs,
} from "./blockchain-database.service";
import { getBlockchainProvider } from "./blockchain.service";
import { createNotification } from "./notification.service";
import { getHotWalletSigner } from "./withdrawal-signer.service";
import { randomId } from "../utils/helpers";
import { getAutomaticWithdrawalSettings, pauseAutomaticWithdrawals } from "./automatic-withdrawal.service";

const ERC20_TRANSFER_INTERFACE = new Interface([
  "function transfer(address to, uint256 amount) returns (bool)",
]);
const ERC20_BALANCE_ABI = [
  "function balanceOf(address account) view returns (uint256)",
] as const;
type Erc20BalanceContract = Contract & {
  balanceOf(account: string): Promise<bigint>;
};

const WITHDRAWAL_WORKER_NAME = "withdrawal-worker";

async function upsertWithdrawalWorkerStatus(input: {
  instanceId: string;
  status: "STARTING" | "IDLE" | "HEALTHY" | "PAUSED" | "ERROR";
  cycleStarted?: boolean;
  cycleCompleted?: boolean;
  processed?: number;
  completed?: number;
  failed?: number;
  error?: string | null;
  metadata?: Record<string, unknown>;
}): Promise<void> {
  await query(
    `INSERT INTO blockchain_worker_status(
       worker_name, instance_id, status, chain_id, token_contract,
       detected_events, confirmed_events, orphaned_events,
       last_cycle_started_at, last_cycle_completed_at,
       heartbeat_at, last_error, metadata
     ) VALUES(
       $1,$2,$3,$4,$5,$6,$7,$8,
       CASE WHEN $9 THEN now() ELSE NULL END,
       CASE WHEN $10 THEN now() ELSE NULL END,
       now(),$11,$12::jsonb
     )
     ON CONFLICT(worker_name) DO UPDATE SET
       instance_id = EXCLUDED.instance_id,
       status = EXCLUDED.status,
       chain_id = EXCLUDED.chain_id,
       token_contract = EXCLUDED.token_contract,
       detected_events = blockchain_worker_status.detected_events + $6,
       confirmed_events = blockchain_worker_status.confirmed_events + $7,
       orphaned_events = blockchain_worker_status.orphaned_events + $8,
       last_cycle_started_at = CASE
         WHEN $9 THEN now() ELSE blockchain_worker_status.last_cycle_started_at
       END,
       last_cycle_completed_at = CASE
         WHEN $10 THEN now() ELSE blockchain_worker_status.last_cycle_completed_at
       END,
       heartbeat_at = now(),
       last_error = $11,
       metadata = blockchain_worker_status.metadata || EXCLUDED.metadata,
       updated_at = now()`,
    [
      WITHDRAWAL_WORKER_NAME,
      input.instanceId,
      input.status,
      blockchainConfig.network.chainId,
      blockchainConfig.tokenAddress ?? null,
      input.processed ?? 0,
      input.completed ?? 0,
      input.failed ?? 0,
      Boolean(input.cycleStarted),
      Boolean(input.cycleCompleted),
      input.error ?? null,
      JSON.stringify({
        lastProcessed: input.processed ?? 0,
        lastCompleted: input.completed ?? 0,
        lastFailed: input.failed ?? 0,
        ...(input.metadata ?? {}),
      }),
    ],
  );
}

export async function recordWithdrawalWorkerError(
  instanceId: string,
  error: unknown,
): Promise<void> {
  await upsertWithdrawalWorkerStatus({
    instanceId,
    status: "ERROR",
    cycleCompleted: true,
    error: safeError(error),
  });
}

type WithdrawalRow = {
  id: string;
  withdrawal_id: string;
  user_id: string;
  chain_id: string | number;
  token_contract: string;
  sender_address: string | null;
  destination_address: string;
  amount_raw: string;
  amount: string;
  nonce: string | number | null;
  tx_hash: string | null;
  raw_transaction: string | null;
  block_number: string | number | null;
  block_hash: string | null;
  confirmations: number;
  status: string;
  attempts: number;
  max_attempts: number;
  reservation_journal_id: string | null;
  completion_journal_id: string | null;
  refund_journal_id: string | null;
  business_status: string;
  approval_mode: "MANUAL" | "AUTOMATIC";
};

export class RetryableWithdrawalError extends Error {
  constructor(message: string, public readonly delaySeconds = 15) {
    super(message);
    this.name = "RetryableWithdrawalError";
  }
}

export class AutomaticWithdrawalSafetyPauseError extends RetryableWithdrawalError {
  constructor(message: string, delaySeconds = 300) {
    super(message, delaySeconds);
    this.name = "AutomaticWithdrawalSafetyPauseError";
  }
}

function safeError(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error);
  const sanitized = blockchainConfig.rpcUrl
    ? message.replace(blockchainConfig.rpcUrl, "[RPC]")
    : message;
  return sanitized.slice(0, 1000);
}

function sendJobKey(id: string): string {
  return `send-withdrawal:${id}`;
}

function confirmJobKey(id: string): string {
  return `confirm-withdrawal:${id}`;
}

function explorerTxUrl(txHash: string | null): string | null {
  return txHash
    ? `${blockchainConfig.network.explorerBaseUrl}/tx/${txHash}`
    : null;
}

async function loadWithdrawal(
  client: PoolClient,
  blockchainWithdrawalId: string,
  forUpdate = false,
): Promise<WithdrawalRow | null> {
  const result = await client.query<WithdrawalRow>(
    `SELECT bw.*, w.status AS business_status
     FROM blockchain_withdrawals bw
     JOIN withdrawals w ON w.id = bw.withdrawal_id
     WHERE bw.id = $1
     ${forUpdate ? "FOR UPDATE OF bw, w" : ""}`,
    [blockchainWithdrawalId],
  );
  return result.rows[0] ?? null;
}

async function insertJob(
  client: PoolClient,
  type: "SEND_WITHDRAWAL" | "CONFIRM_WITHDRAWAL",
  key: string,
  payload: Record<string, unknown>,
  maxAttempts: number,
  runAfter = new Date(),
): Promise<void> {
  await client.query(
    `INSERT INTO blockchain_jobs(
       id, job_type, idempotency_key, payload, priority, max_attempts, run_after
     ) VALUES($1,$2,$3,$4::jsonb,50,$5,$6)
     ON CONFLICT(idempotency_key) DO UPDATE SET
       status = CASE
         WHEN blockchain_jobs.status IN ('FAILED','CANCELLED') THEN 'RETRY'
         ELSE blockchain_jobs.status
       END,
       run_after = LEAST(blockchain_jobs.run_after, EXCLUDED.run_after),
       last_error = CASE
         WHEN blockchain_jobs.status IN ('FAILED','CANCELLED') THEN NULL
         ELSE blockchain_jobs.last_error
       END,
       updated_at = now()`,
    [randomId(), type, key, JSON.stringify(payload), maxAttempts, runAfter],
  );
}

function assertExecutionAllowed(controls: Awaited<ReturnType<typeof getBlockchainControls>>) {
  if (!blockchainConfig.enabled || !blockchainConfig.configured) {
    throw new Error("Blockchain connection is not configured");
  }
  if (!blockchainConfig.withdrawalWorkerEnabled) {
    throw new Error("Withdrawal worker is disabled in environment");
  }
  if (!controls.withdrawalsEnabled || !controls.withdrawalWorkerEnabled) {
    throw new Error("Blockchain withdrawals are disabled in database");
  }
  if (controls.emergencyStop) {
    throw new Error(
      `Blockchain emergency stop is active: ${controls.emergencyReason || "no reason"}`,
    );
  }
  if (blockchainConfig.network.name !== "testnet") {
    throw new Error("Stage 7 refuses Mainnet withdrawal execution");
  }
  if (!blockchainConfig.hotWalletAddress || !blockchainConfig.tokenAddress) {
    throw new Error("Hot wallet or token contract is not configured");
  }
}

export async function enqueueWithdrawalForExecution(
  client: PoolClient,
  blockchainWithdrawalId: string,
): Promise<void> {
  await insertJob(
    client,
    "SEND_WITHDRAWAL",
    sendJobKey(blockchainWithdrawalId),
    { blockchainWithdrawalId },
    20,
  );
}

async function prepareSignedTransaction(
  blockchainWithdrawalId: string,
): Promise<{ rawTransaction: string; txHash: string; alreadyBroadcast: boolean }> {
  const controls = await getBlockchainControls();
  assertExecutionAllowed(controls);

  const provider = getBlockchainProvider();
  const signer = getHotWalletSigner(provider);
  const network = await provider.getNetwork();
  if (Number(network.chainId) !== controls.chainId) {
    throw new Error("RPC chain id does not match database configuration");
  }

  return withTransaction(async (client) => {
    const row = await loadWithdrawal(client, blockchainWithdrawalId, true);
    if (!row) throw new Error("Blockchain withdrawal was not found");

    if (["COMPLETED", "CANCELLED", "FAILED"].includes(row.status)) {
      throw new Error(`Withdrawal is already terminal: ${row.status}`);
    }

    if (row.approval_mode === "AUTOMATIC" && !controls.autoWithdrawalsEnabled) {
      throw new RetryableWithdrawalError(
        controls.autoWithdrawalPauseReason
          ? `Automatic withdrawals are paused: ${controls.autoWithdrawalPauseReason}`
          : "Automatic withdrawals are paused",
        300,
      );
    }

    if (row.raw_transaction && row.tx_hash) {
      return {
        rawTransaction: row.raw_transaction,
        txHash: row.tx_hash,
        alreadyBroadcast: ["BROADCASTED", "CONFIRMING", "CONFIRMED"].includes(
          row.status,
        ),
      };
    }

    if (!["RESERVED", "SIGNING", "QUEUED"].includes(row.status)) {
      throw new Error(`Withdrawal cannot be signed from status ${row.status}`);
    }
    if (!["RESERVED", "PROCESSING"].includes(row.business_status)) {
      throw new Error(
        `Business withdrawal cannot be signed from status ${row.business_status}`,
      );
    }

    const sender = getAddress(signer.address);
    if (sender !== getAddress(blockchainConfig.hotWalletAddress!)) {
      throw new Error("Signer address mismatch");
    }

    await client.query("SELECT pg_advisory_xact_lock(hashtext($1))", [
      `${controls.chainId}:${sender.toLowerCase()}`,
    ]);

    const [pendingNonce, feeData, nativeBalance, tokenBalance] = await Promise.all([
      provider.getTransactionCount(sender, "pending"),
      provider.getFeeData(),
      provider.getBalance(sender),
      (new Contract(row.token_contract, ERC20_BALANCE_ABI, provider) as Erc20BalanceContract).balanceOf(
        sender,
      ) as Promise<bigint>,
    ]);

    const tokenReserveRaw = parseUnits(
      String(controls.hotWalletMinTokenReserve),
      controls.tokenDecimals,
    );
    const requiredTokenBalance = BigInt(row.amount_raw) + tokenReserveRaw;
    if (tokenBalance < requiredTokenBalance) {
      const message = `Hot wallet token safety reserve is insufficient. Available ${formatUnits(
        tokenBalance,
        controls.tokenDecimals,
      )} ${controls.tokenSymbol}; withdrawal ${formatUnits(
        BigInt(row.amount_raw),
        controls.tokenDecimals,
      )}; required reserve ${controls.hotWalletMinTokenReserve}`;
      if (row.approval_mode === "AUTOMATIC") {
        throw new AutomaticWithdrawalSafetyPauseError(message);
      }
      throw new RetryableWithdrawalError(message, 60);
    }

    const nonceResult = await client.query<{ max_nonce: string | null }>(
      `SELECT max(nonce)::text AS max_nonce
       FROM blockchain_withdrawals
       WHERE chain_id = $1
         AND lower(sender_address) = lower($2)
         AND nonce IS NOT NULL
         AND status NOT IN ('CANCELLED')`,
      [controls.chainId, sender],
    );
    const dbNext =
      nonceResult.rows[0]?.max_nonce == null
        ? 0
        : Number(nonceResult.rows[0].max_nonce) + 1;
    const nonce = Math.max(pendingNonce, dbNext);

    const data = ERC20_TRANSFER_INTERFACE.encodeFunctionData("transfer", [
      getAddress(row.destination_address),
      BigInt(row.amount_raw),
    ]);
    const estimatedGas = await provider.estimateGas({
      from: sender,
      to: getAddress(row.token_contract),
      data,
      value: 0n,
    });
    const gasLimit = (estimatedGas * 120n + 99n) / 100n;
    const gasPrice = feeData.gasPrice;
    if (!gasPrice || gasPrice <= 0n) {
      throw new RetryableWithdrawalError("RPC did not return a usable gas price");
    }
    const requiredNative = gasLimit * gasPrice;
    const nativeReserve = parseEther(String(controls.hotWalletMinBnbReserve));
    if (nativeBalance < requiredNative + nativeReserve) {
      const message = `Hot wallet BNB safety reserve is insufficient. Available ${formatEther(
        nativeBalance,
      )}; estimated fee ${formatEther(requiredNative)}; required reserve ${controls.hotWalletMinBnbReserve}`;
      if (row.approval_mode === "AUTOMATIC") {
        throw new AutomaticWithdrawalSafetyPauseError(message);
      }
      throw new RetryableWithdrawalError(message, 60);
    }

    const rawTransaction = await signer.signTransaction({
      chainId: controls.chainId,
      type: 0,
      nonce,
      to: getAddress(row.token_contract),
      data,
      value: 0n,
      gasLimit,
      gasPrice,
    });
    const txHash = keccak256(rawTransaction);

    await client.query(
      `UPDATE blockchain_withdrawals
       SET sender_address = $1,
           nonce = $2,
           raw_transaction = $3,
           tx_hash = $4,
           gas_limit = $5,
           gas_price_raw = $6,
           status = 'SIGNING',
           attempts = attempts + 1,
           last_error = NULL,
           updated_at = now()
       WHERE id = $7`,
      [
        sender,
        nonce,
        rawTransaction,
        txHash,
        gasLimit.toString(),
        gasPrice.toString(),
        blockchainWithdrawalId,
      ],
    );
    await client.query(
      `UPDATE withdrawals
       SET status = 'PROCESSING', tx_hash = $1, updated_at = now()
       WHERE id = $2`,
      [txHash, row.withdrawal_id],
    );

    return { rawTransaction, txHash, alreadyBroadcast: false };
  });
}

function isKnownTransactionError(error: unknown): boolean {
  const text = safeError(error).toLowerCase();
  return (
    text.includes("already known") ||
    text.includes("known transaction") ||
    text.includes("nonce too low") ||
    text.includes("transaction already imported")
  );
}

export async function sendApprovedWithdrawal(
  blockchainWithdrawalId: string,
): Promise<{ txHash: string; explorerUrl: string | null }> {
  const prepared = await prepareSignedTransaction(blockchainWithdrawalId);
  const provider = getBlockchainProvider();

  if (!prepared.alreadyBroadcast) {
    try {
      await provider.broadcastTransaction(prepared.rawTransaction);
    } catch (error) {
      if (!isKnownTransactionError(error)) throw error;
    }
  }

  await withTransaction(async (client) => {
    const row = await loadWithdrawal(client, blockchainWithdrawalId, true);
    if (!row) throw new Error("Blockchain withdrawal was not found");

    await client.query(
      `UPDATE blockchain_withdrawals
       SET status = CASE
             WHEN status IN ('COMPLETED','CONFIRMED') THEN status
             ELSE 'BROADCASTED'
           END,
           broadcast_at = COALESCE(broadcast_at, now()),
           last_error = NULL,
           updated_at = now()
       WHERE id = $1`,
      [blockchainWithdrawalId],
    );
    await client.query(
      `UPDATE withdrawals
       SET status = CASE
             WHEN status = 'COMPLETED' THEN status
             ELSE 'BROADCASTED'
           END,
           tx_hash = $1,
           broadcast_at = COALESCE(broadcast_at, now()),
           updated_at = now()
       WHERE id = $2`,
      [prepared.txHash, row.withdrawal_id],
    );
    await insertJob(
      client,
      "CONFIRM_WITHDRAWAL",
      confirmJobKey(blockchainWithdrawalId),
      { blockchainWithdrawalId },
      100,
      new Date(Date.now() + 8_000),
    );
  });

  return {
    txHash: prepared.txHash,
    explorerUrl: explorerTxUrl(prepared.txHash),
  };
}

async function refundFailedWithdrawal(
  blockchainWithdrawalId: string,
  reason: string,
): Promise<void> {
  await withTransaction(async (client) => {
    const row = await loadWithdrawal(client, blockchainWithdrawalId, true);
    if (!row) throw new Error("Blockchain withdrawal was not found");
    if (row.refund_journal_id || ["REJECTED", "CANCELLED"].includes(row.business_status)) {
      return;
    }
    if (row.business_status === "COMPLETED" || row.status === "COMPLETED") {
      throw new Error("A completed withdrawal cannot be refunded");
    }

    const accounts = await ensureUserLedgerAccounts(client, row.user_id);
    const journalId = await postLedgerJournal(client, {
      idempotencyKey: `ledger:withdrawal-refund:${row.withdrawal_id}`,
      referenceType: "Withdrawal",
      referenceId: row.withdrawal_id,
      description: "Refund failed blockchain withdrawal",
      metadata: { blockchainWithdrawalId, reason },
      entries: [
        {
          accountId: "sys-usdt-withdrawal-payable",
          direction: "DEBIT",
          amount: String(row.amount),
          memo: "Remove withdrawal payable after failed chain transaction",
        },
        {
          accountId: accounts.profitAccountId,
          direction: "CREDIT",
          amount: String(row.amount),
          userId: row.user_id,
          memo: "Restore user withdrawable balance",
        },
      ],
    });

    await client.query(
      `UPDATE users
       SET profit_balance = profit_balance + $1, updated_at = now()
       WHERE id = $2`,
      [row.amount, row.user_id],
    );
    await client.query(
      `UPDATE blockchain_withdrawals
       SET status = 'FAILED', failed_at = now(), failure_reason = $1,
           last_error = $1, refund_journal_id = $2, updated_at = now()
       WHERE id = $3`,
      [reason.slice(0, 1000), journalId, blockchainWithdrawalId],
    );
    await client.query(
      `UPDATE withdrawals
       SET status = 'FAILED', failure_reason = $1, refund_journal_id = $2,
           note = COALESCE(note, $1), updated_at = now()
       WHERE id = $3`,
      [reason.slice(0, 1000), journalId, row.withdrawal_id],
    );
    await client.query(
      `INSERT INTO transactions(
         id, type, amount, description, metadata, user_id
       ) VALUES($1,'WITHDRAWAL_FAILED_REFUND',$2,$3,$4::jsonb,$5)`,
      [
        randomId(),
        Number(row.amount),
        "برداشت بلاک‌چینی ناموفق و موجودی بازگردانده شد",
        JSON.stringify({ withdrawalId: row.withdrawal_id, reason }),
        row.user_id,
      ],
    );
    await createNotification(client, {
      userId: row.user_id,
      type: "WITHDRAWAL_FAILED_REFUND",
      title: "برداشت ناموفق بود",
      body: `برداشت ${Number(row.amount)} USDT روی شبکه ناموفق شد و مبلغ به موجودی قابل برداشت شما بازگشت.`,
      metadata: { withdrawalId: row.withdrawal_id, reason },
    });
  });
}

async function completeConfirmedWithdrawal(
  blockchainWithdrawalId: string,
  receipt: TransactionReceipt,
  confirmations: number,
): Promise<void> {
  await withTransaction(async (client) => {
    const row = await loadWithdrawal(client, blockchainWithdrawalId, true);
    if (!row) throw new Error("Blockchain withdrawal was not found");
    if (row.status === "COMPLETED" || row.business_status === "COMPLETED") return;
    if (!row.tx_hash) throw new Error("Withdrawal tx hash is missing");

    const journalId = await postLedgerJournal(client, {
      idempotencyKey: `ledger:withdrawal-complete:${row.withdrawal_id}`,
      referenceType: "Withdrawal",
      referenceId: row.withdrawal_id,
      description: "Settle confirmed blockchain withdrawal",
      metadata: {
        blockchainWithdrawalId,
        txHash: row.tx_hash,
        blockNumber: receipt.blockNumber,
      },
      entries: [
        {
          accountId: "sys-usdt-withdrawal-payable",
          direction: "DEBIT",
          amount: String(row.amount),
          memo: "Settle customer withdrawal payable",
        },
        {
          accountId: "sys-usdt-hot",
          direction: "CREDIT",
          amount: String(row.amount),
          memo: "USDT sent from hot wallet",
        },
      ],
    });

    await client.query(
      `UPDATE blockchain_withdrawals
       SET status = 'COMPLETED', block_number = $1, block_hash = $2,
           confirmations = $3, confirmed_at = COALESCE(confirmed_at, now()),
           completed_at = now(), completion_journal_id = $4,
           failure_reason = NULL, last_error = NULL, updated_at = now()
       WHERE id = $5`,
      [
        receipt.blockNumber,
        receipt.blockHash,
        confirmations,
        journalId,
        blockchainWithdrawalId,
      ],
    );
    await client.query(
      `UPDATE withdrawals
       SET status = 'COMPLETED', tx_hash = $1, confirmations = $2,
           completed_at = now(), completion_journal_id = $3,
           failure_reason = NULL, updated_at = now()
       WHERE id = $4`,
      [row.tx_hash, confirmations, journalId, row.withdrawal_id],
    );
    await client.query(
      `UPDATE users
       SET total_withdraw = total_withdraw + $1, updated_at = now()
       WHERE id = $2`,
      [row.amount, row.user_id],
    );
    await createNotification(client, {
      userId: row.user_id,
      type: "WITHDRAWAL_COMPLETED",
      title: "برداشت انجام شد",
      body: `برداشت ${Number(row.amount)} USDT با موفقیت روی شبکه ارسال و تأیید شد.`,
      metadata: {
        withdrawalId: row.withdrawal_id,
        txHash: row.tx_hash,
        explorerUrl: explorerTxUrl(row.tx_hash),
      },
    });
  });
}

export async function confirmBroadcastWithdrawal(
  blockchainWithdrawalId: string,
): Promise<{ status: string; confirmations: number; txHash: string }> {
  const controls = await getBlockchainControls();
  assertExecutionAllowed(controls);
  const provider = getBlockchainProvider();

  const result = await query<WithdrawalRow>(
    `SELECT bw.*, w.status AS business_status
     FROM blockchain_withdrawals bw
     JOIN withdrawals w ON w.id = bw.withdrawal_id
     WHERE bw.id = $1`,
    [blockchainWithdrawalId],
  );
  const row = result.rows[0];
  if (!row) throw new Error("Blockchain withdrawal was not found");
  if (row.status === "COMPLETED") {
    return {
      status: "completed",
      confirmations: Number(row.confirmations),
      txHash: row.tx_hash!,
    };
  }
  if (!row.tx_hash) throw new Error("Withdrawal tx hash is missing");

  const receipt = await provider.getTransactionReceipt(row.tx_hash);
  if (!receipt) {
    await query(
      `UPDATE blockchain_withdrawals
       SET status = 'CONFIRMING', last_error = NULL, updated_at = now()
       WHERE id = $1 AND status NOT IN ('COMPLETED','FAILED','CANCELLED')`,
      [blockchainWithdrawalId],
    );
    await query(
      `UPDATE withdrawals
       SET status = 'CONFIRMING', updated_at = now()
       WHERE id = $1 AND status NOT IN ('COMPLETED','FAILED','REJECTED','CANCELLED')`,
      [row.withdrawal_id],
    );
    throw new RetryableWithdrawalError("Transaction receipt is not available yet", 12);
  }

  if (receipt.status !== 1) {
    await refundFailedWithdrawal(
      blockchainWithdrawalId,
      `Blockchain transaction reverted: ${row.tx_hash}`,
    );
    return { status: "failed_refunded", confirmations: 0, txHash: row.tx_hash };
  }

  const latestBlock = await provider.getBlockNumber();
  const confirmations = Math.max(0, latestBlock - receipt.blockNumber + 1);

  await query(
    `UPDATE blockchain_withdrawals
     SET status = CASE WHEN $1 >= $2 THEN 'CONFIRMED' ELSE 'CONFIRMING' END,
         block_number = $3, block_hash = $4, confirmations = $1,
         confirmed_at = CASE WHEN $1 >= $2 THEN COALESCE(confirmed_at, now()) ELSE confirmed_at END,
         updated_at = now()
     WHERE id = $5`,
    [
      confirmations,
      controls.requiredConfirmations,
      receipt.blockNumber,
      receipt.blockHash,
      blockchainWithdrawalId,
    ],
  );
  await query(
    `UPDATE withdrawals
     SET status = 'CONFIRMING',
         confirmations = $1, tx_hash = $2, updated_at = now()
     WHERE id = $3 AND status <> 'COMPLETED'`,
    [confirmations, row.tx_hash, row.withdrawal_id],
  );

  if (confirmations < controls.requiredConfirmations) {
    throw new RetryableWithdrawalError(
      `Waiting for confirmations: ${confirmations}/${controls.requiredConfirmations}`,
      12,
    );
  }

  await completeConfirmedWithdrawal(
    blockchainWithdrawalId,
    receipt,
    confirmations,
  );
  return { status: "completed", confirmations, txHash: row.tx_hash };
}


async function markWithdrawalReviewRequired(
  blockchainWithdrawalId: string,
  reason: string,
): Promise<void> {
  await withTransaction(async (client) => {
    const updated = await client.query<{
      user_id: string;
      withdrawal_id: string;
      amount: string;
    }>(
      `UPDATE blockchain_withdrawals bw
       SET status = 'REVIEW_REQUIRED', failure_reason = $1, last_error = $1,
           failed_at = COALESCE(failed_at, now()), updated_at = now()
       WHERE bw.id = $2
         AND bw.status NOT IN ('COMPLETED','FAILED','CANCELLED','REVIEW_REQUIRED')
       RETURNING bw.user_id, bw.withdrawal_id, bw.amount::text`,
      [reason.slice(0, 1000), blockchainWithdrawalId],
    );
    const row = updated.rows[0];
    if (!row) return;

    await client.query(
      `UPDATE withdrawals
       SET status = 'REVIEW_REQUIRED', failure_reason = $1, updated_at = now()
       WHERE id = $2 AND status NOT IN ('COMPLETED','FAILED','REJECTED','CANCELLED')`,
      [reason.slice(0, 1000), row.withdrawal_id],
    );
    await createNotification(client, {
      userId: row.user_id,
      type: "WITHDRAWAL_REVIEW_REQUIRED",
      title: "برداشت در حال بررسی فنی است",
      body: `برداشت ${Number(row.amount)} USDT به بررسی فنی مدیر نیاز دارد. مبلغ همچنان به‌صورت رزروشده نگهداری می‌شود.`,
      metadata: { blockchainWithdrawalId, withdrawalId: row.withdrawal_id },
    });
  });
}

async function processJob(
  job: BlockchainJobRow,
  workerId: string,
): Promise<Record<string, unknown>> {
  const blockchainWithdrawalId = String(
    job.payload?.blockchainWithdrawalId || "",
  );
  if (!blockchainWithdrawalId) {
    throw new Error(`${job.job_type} payload is missing blockchainWithdrawalId`);
  }

  const result =
    job.job_type === "SEND_WITHDRAWAL"
      ? await sendApprovedWithdrawal(blockchainWithdrawalId)
      : await confirmBroadcastWithdrawal(blockchainWithdrawalId);

  await completeBlockchainJob(job.id, workerId, result);
  return result;
}

export async function runWithdrawalWorkerCycle(instanceId: string) {
  const controls = await getBlockchainControls();
  const enabled =
    blockchainConfig.enabled &&
    blockchainConfig.withdrawalWorkerEnabled &&
    controls.withdrawalsEnabled &&
    controls.withdrawalWorkerEnabled &&
    !controls.emergencyStop;

  if (!enabled) {
    const reason = controls.emergencyStop
      ? controls.emergencyReason || "Emergency stop is active"
      : "Withdrawal worker is disabled";
    await upsertWithdrawalWorkerStatus({
      instanceId,
      status: "PAUSED",
      cycleCompleted: true,
      error: null,
      metadata: { pauseReason: reason },
    });
    return {
      enabled: false,
      processed: 0,
      reason,
    };
  }

  assertExecutionAllowed(controls);
  await upsertWithdrawalWorkerStatus({
    instanceId,
    status: "STARTING",
    cycleStarted: true,
    error: null,
  });
  await recoverExpiredBlockchainJobs();

  const jobs = await claimBlockchainJobs({
    workerId: instanceId,
    types: ["SEND_WITHDRAWAL", "CONFIRM_WITHDRAWAL"],
    limit: blockchainConfig.withdrawalBatchSize,
    leaseSeconds: blockchainConfig.withdrawalJobLeaseSeconds,
  });

  let completed = 0;
  let failed = 0;
  for (const job of jobs) {
    try {
      await processJob(job, instanceId);
      completed += 1;
    } catch (error) {
      failed += 1;
      if (error instanceof AutomaticWithdrawalSafetyPauseError) {
        await pauseAutomaticWithdrawals(
          `Automatic withdrawals paused by worker safety check: ${safeError(error)}`,
        );
      }
      const delay =
        error instanceof RetryableWithdrawalError
          ? error.delaySeconds
          : Math.min(300, 15 * Math.max(1, job.attempts));
      const errorText = safeError(error);
      await failBlockchainJob({
        jobId: job.id,
        workerId: instanceId,
        error: errorText,
        retryDelaySeconds: delay,
      });
      if (job.attempts >= job.max_attempts) {
        const blockchainWithdrawalId = String(
          job.payload?.blockchainWithdrawalId || "",
        );
        if (blockchainWithdrawalId) {
          await markWithdrawalReviewRequired(
            blockchainWithdrawalId,
            `Worker attempts exhausted: ${errorText}`,
          );
        }
      }
    }
  }

  await upsertWithdrawalWorkerStatus({
    instanceId,
    status: jobs.length > 0 ? "HEALTHY" : "IDLE",
    cycleCompleted: true,
    processed: jobs.length,
    completed,
    failed,
    error: failed > 0 ? `${failed} withdrawal job(s) need retry` : null,
  });

  return { enabled: true, processed: jobs.length, completed, failed };
}

export async function getWithdrawalExecutionStatus() {
  const controls = await getBlockchainControls();
  const [counts, workerResult, automaticSettings] = await Promise.all([
    query(
      `SELECT
         count(*) FILTER (WHERE status = 'AWAITING_APPROVAL')::int AS awaiting_approval,
         count(*) FILTER (WHERE status IN ('RESERVED','SIGNING','BROADCASTED','CONFIRMING','CONFIRMED'))::int AS active,
         count(*) FILTER (WHERE status = 'COMPLETED')::int AS completed,
         count(*) FILTER (WHERE status IN ('FAILED','REVIEW_REQUIRED'))::int AS attention
       FROM blockchain_withdrawals`,
    ),
    query(
      `SELECT instance_id, status, last_cycle_started_at,
              last_cycle_completed_at, heartbeat_at, last_error, metadata
       FROM blockchain_worker_status
       WHERE worker_name = $1`,
      [WITHDRAWAL_WORKER_NAME],
    ),
    getAutomaticWithdrawalSettings(),
  ]);

  const workerRow = workerResult.rows[0] ?? null;
  const heartbeatAt = workerRow?.heartbeat_at
    ? new Date(workerRow.heartbeat_at)
    : null;
  const staleAfterMs = Math.max(
    60_000,
    blockchainConfig.withdrawalWorkerIntervalMs * 4,
  );
  const worker = workerRow
    ? {
        instanceId: workerRow.instance_id,
        status: workerRow.status,
        heartbeatAt,
        heartbeatStale:
          !heartbeatAt || Date.now() - heartbeatAt.getTime() > staleAfterMs,
        lastCycleStartedAt: workerRow.last_cycle_started_at,
        lastCycleCompletedAt: workerRow.last_cycle_completed_at,
        lastError: workerRow.last_error,
        metadata: workerRow.metadata,
      }
    : null;

  let hotWallet: Record<string, unknown> | null = null;
  let error: string | null = null;
  if (
    blockchainConfig.enabled &&
    blockchainConfig.configured &&
    blockchainConfig.hotWalletAddress &&
    blockchainConfig.tokenAddress
  ) {
    try {
      const provider = getBlockchainProvider();
      const token = new Contract(
        blockchainConfig.tokenAddress,
        ERC20_BALANCE_ABI,
        provider,
      ) as Erc20BalanceContract;
      const [bnb, tokenBalance] = await Promise.all([
        provider.getBalance(blockchainConfig.hotWalletAddress),
        token.balanceOf(blockchainConfig.hotWalletAddress) as Promise<bigint>,
      ]);
      hotWallet = {
        address: blockchainConfig.hotWalletAddress,
        bnb: formatEther(bnb),
        token: formatUnits(tokenBalance, controls.tokenDecimals),
        tokenSymbol: controls.tokenSymbol,
      };
    } catch (e) {
      error = safeError(e);
    }
  }

  return {
    environmentEnabled: blockchainConfig.withdrawalWorkerEnabled,
    databaseEnabled: controls.withdrawalWorkerEnabled,
    withdrawalsEnabled: controls.withdrawalsEnabled,
    approvalRequired: controls.withdrawalApprovalRequired,
    automaticWithdrawals: automaticSettings,
    emergencyStop: controls.emergencyStop,
    network: controls.network,
    chainId: controls.chainId,
    mainnetExecutionAllowed: false,
    hotWallet,
    worker,
    counts: counts.rows[0],
    error,
  };
}

export const withdrawalExecutionInternals = {
  sendJobKey,
  confirmJobKey,
  explorerTxUrl,
  isKnownTransactionError,
  parseBusinessAmountToRaw(amount: number, decimals: number) {
    return parseUnits(String(amount), decimals).toString();
  },
  isZeroAddress(address: string) {
    return getAddress(address) === ZeroAddress;
  },
};
