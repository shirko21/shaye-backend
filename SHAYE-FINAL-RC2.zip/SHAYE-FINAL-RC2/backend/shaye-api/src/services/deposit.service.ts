import crypto from "crypto";
import { PoolClient } from "pg";
import { query, withTransaction } from "../config/database";
import { AppError } from "../utils/response";
import { getSettings, syncVipLevel } from "./settings.service";
import { money, randomCode, randomId } from "../utils/helpers";
import { percentage } from "../utils/wallet";
import { grantFirstVipReferralSpins } from "./wheel.service";
import { createNotification } from "./notification.service";

export async function createDeposit(
  userId: string,
  value: number,
  txHash?: string,
) {
  const settings = await getSettings();
  const amount = money(value);

  if (amount < settings.minDeposit) {
    throw new AppError(
      400,
      `حداقل واریز ${settings.minDeposit} USDT است.`,
      "MIN_DEPOSIT",
    );
  }

  const id = randomId();
  const referenceCode = randomCode("DEP");

  await withTransaction(async (client) => {
    await client.query(
      `INSERT INTO deposits(
        id, amount, reference_code, tx_hash, user_id
      ) VALUES($1, $2, $3, $4, $5)`,
      [id, amount, referenceCode, txHash?.trim() || null, userId],
    );

    await client.query(
      `INSERT INTO transactions(
        id, type, amount, description, metadata, user_id
      ) VALUES($1, 'DEPOSIT_REQUEST', $2, $3, $4, $5)`,
      [
        randomId(),
        amount,
        "ثبت درخواست واریز",
        JSON.stringify({ depositId: id }),
        userId,
      ],
    );
  });

  return {
    id,
    amount,
    referenceCode,
    txHash: txHash?.trim() || null,
    status: "PENDING",
  };
}

export async function createStage9ATestDeposit(
  userId: string,
  value: number,
) {
  if (process.env.STAGE9A_TEST_MODE !== "true") {
    throw new AppError(404, "این مسیر فقط در محیط آزمایشی مرحله ۹A فعال است.", "TEST_MODE_DISABLED");
  }

  const amount = money(value);
  if (amount > 10_000) {
    throw new AppError(400, "حداکثر افزایش آزمایشی ۱۰٬۰۰۰ USDT است.", "TEST_AMOUNT_LIMIT");
  }

  const txHash = `0x${crypto.randomBytes(32).toString("hex")}`;
  const deposit = await createDeposit(userId, amount, txHash);
  await approveDeposit(userId, deposit.id, "Stage 9A Codespaces test credit");

  return {
    ...deposit,
    status: "APPROVED",
    testMode: true,
  };
}

export async function listUserDeposits(userId: string) {
  const result = await query(
    `SELECT * FROM deposits
     WHERE user_id = $1
     ORDER BY created_at DESC`,
    [userId],
  );

  return result.rows.map((deposit) => ({
    id: deposit.id,
    amount: Number(deposit.amount),
    referenceCode: deposit.reference_code,
    txHash: deposit.tx_hash,
    status: deposit.status,
    note: deposit.note,
    createdAt: deposit.created_at,
    updatedAt: deposit.updated_at,
  }));
}

async function creditReferral(
  client: PoolClient,
  userId: string,
  amount: number,
  rate: number,
  level: 1 | 2,
  sourceUserId: string,
  sourceDepositId: string,
) {
  const reward = percentage(amount, rate);
  if (reward <= 0) return;

  await client.query(
    `UPDATE users
     SET profit_balance = profit_balance + $1,
         total_profit = total_profit + $1,
         referral_profit = referral_profit + $1,
         updated_at = now()
     WHERE id = $2 AND is_active = TRUE`,
    [reward, userId],
  );

  await client.query(
    `INSERT INTO transactions(
      id, type, amount, description, metadata, user_id
    ) VALUES($1, 'REFERRAL_REWARD', $2, $3, $4, $5)`,
    [
      randomId(),
      reward,
      `پاداش معرفی سطح ${level}`,
      JSON.stringify({ sourceUserId, sourceDepositId, level, rate }),
      userId,
    ],
  );
}

export async function approveDeposit(
  adminId: string,
  id: string,
  note?: string,
) {
  const settings = await getSettings();

  await withTransaction(async (client) => {
    const result = await client.query(
      `SELECT d.*, u.referred_by_id, u.vip_level,
              referrer.referred_by_id AS second_referrer_id
       FROM deposits d
       JOIN users u ON u.id = d.user_id
       LEFT JOIN users referrer ON referrer.id = u.referred_by_id
       WHERE d.id = $1
       FOR UPDATE OF d`,
      [id],
    );
    const deposit = result.rows[0];

    if (!deposit) {
      throw new AppError(
        404,
        "درخواست واریز پیدا نشد.",
        "DEPOSIT_NOT_FOUND",
      );
    }
    if (deposit.status !== "PENDING") {
      throw new AppError(
        409,
        "این درخواست قبلاً بررسی شده است.",
        "ALREADY_REVIEWED",
      );
    }

    await client.query(
      `UPDATE deposits
       SET status = 'APPROVED', note = $1, reviewed_by = $2,
           reviewed_at = now(), updated_at = now()
       WHERE id = $3`,
      [note || null, adminId, id],
    );

    await client.query(
      `INSERT INTO lock_positions(
        id, amount, unlock_at, source_deposit_id, user_id, lock_days_snapshot
      ) VALUES($1, $2, now() + ($3 || ' days')::interval, $4, $5, $3)`,
      [
        randomId(),
        deposit.amount,
        settings.lockDays,
        id,
        deposit.user_id,
      ],
    );

    await client.query(
      `UPDATE users
       SET locked_balance = locked_balance + $1,
           total_deposit = total_deposit + $1,
           updated_at = now()
       WHERE id = $2`,
      [deposit.amount, deposit.user_id],
    );

    await client.query(
      `INSERT INTO transactions(
        id, type, amount, description, metadata, user_id
      ) VALUES($1, 'DEPOSIT_APPROVED', $2, $3, $4, $5)`,
      [
        randomId(),
        deposit.amount,
        "تأیید واریز و قفل سرمایه",
        JSON.stringify({ depositId: id }),
        deposit.user_id,
      ],
    );

    const vipBefore = Number(deposit.vip_level || 0);
    const vipAfter = await syncVipLevel(deposit.user_id, client);

    if (deposit.referred_by_id) {
      const wheelGrant = await grantFirstVipReferralSpins(client, {
        inviterId: deposit.referred_by_id,
        inviteeId: deposit.user_id,
        sourceDepositId: id,
        vipLevelBefore: vipBefore,
        vipLevelAfter: vipAfter,
      });
      if (wheelGrant.spins > 0) {
        await createNotification(client, {
          userId: deposit.referred_by_id,
          type: "REFERRAL_FIRST_VIP_WHEEL_SPIN",
          title: "فرصت جدید گردونه",
          body: `${wheelGrant.spins} فرصت گردونه به‌دلیل فعال‌شدن اولین VIP زیرمجموعه مستقیم شما اضافه شد. این پاداش برای هر زیرمجموعه فقط یک‌بار داده می‌شود.`,
          metadata: {
            sourceDepositId: id,
            inviteeId: deposit.user_id,
            vipLevelBefore: vipBefore,
            vipLevelAfter: vipAfter,
            wheelGrantId: wheelGrant.grantId,
          },
        });
      }
      await creditReferral(
        client,
        deposit.referred_by_id,
        Number(deposit.amount),
        settings.level1ReferralRate,
        1,
        deposit.user_id,
        id,
      );
    }

    if (deposit.second_referrer_id) {
      await creditReferral(
        client,
        deposit.second_referrer_id,
        Number(deposit.amount),
        settings.level2ReferralRate,
        2,
        deposit.user_id,
        id,
      );
    }

    await client.query(
      `INSERT INTO admin_action_logs(
        id, action, target_type, target_id, metadata, actor_id
      ) VALUES($1, 'APPROVE_DEPOSIT', 'Deposit', $2, $3, $4)`,
      [
        randomId(),
        id,
        JSON.stringify({ amount: deposit.amount, userId: deposit.user_id }),
        adminId,
      ],
    );

  });
}

export async function rejectDeposit(
  adminId: string,
  id: string,
  note?: string,
) {
  await withTransaction(async (client) => {
    const result = await client.query(
      "SELECT * FROM deposits WHERE id = $1 FOR UPDATE",
      [id],
    );
    const deposit = result.rows[0];

    if (!deposit) {
      throw new AppError(
        404,
        "درخواست واریز پیدا نشد.",
        "DEPOSIT_NOT_FOUND",
      );
    }
    if (deposit.status !== "PENDING") {
      throw new AppError(
        409,
        "این درخواست قبلاً بررسی شده است.",
        "ALREADY_REVIEWED",
      );
    }

    await client.query(
      `UPDATE deposits
       SET status = 'REJECTED', note = $1, reviewed_by = $2,
           reviewed_at = now(), updated_at = now()
       WHERE id = $3`,
      [note || null, adminId, id],
    );

    await client.query(
      `INSERT INTO transactions(
        id, type, amount, description, metadata, user_id
      ) VALUES($1, 'DEPOSIT_REJECTED', $2, $3, $4, $5)`,
      [
        randomId(),
        deposit.amount,
        "رد درخواست واریز",
        JSON.stringify({ depositId: id }),
        deposit.user_id,
      ],
    );

    await client.query(
      `INSERT INTO admin_action_logs(
        id, action, target_type, target_id, actor_id
      ) VALUES($1, 'REJECT_DEPOSIT', 'Deposit', $2, $3)`,
      [randomId(), id, adminId],
    );
  });
}
