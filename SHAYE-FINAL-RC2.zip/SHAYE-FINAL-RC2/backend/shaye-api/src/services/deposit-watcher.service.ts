import {
  Filter,
  Interface,
  Log,
  id,
  formatUnits,
  getAddress,
  zeroPadValue,
} from "ethers";
import { blockchainConfig } from "../config/blockchain";
import { query, withTransaction } from "../config/database";
import { randomId } from "../utils/helpers";
import { getBlockchainControls } from "./blockchain-database.service";
import {
  getBlockchainProvider,
  getBlockchainStatus,
} from "./blockchain.service";

const WORKER_NAME = "deposit-watcher";
const STREAM_NAME = "erc20-transfer-to-deposit-wallet";
const TRANSFER_TOPIC = id("Transfer(address,address,uint256)");
const TRANSFER_INTERFACE = new Interface([
  "event Transfer(address indexed from, address indexed to, uint256 value)",
]);

interface DepositWalletRow {
  id: string;
  user_id: string;
  address: string;
}

interface CursorRow {
  id: string;
  last_scanned_block: string | number;
  last_finalized_block: string | number;
  last_block_hash: string | null;
  lock_owner: string | null;
  lock_expires_at: Date | null;
}

interface ParsedTransfer {
  txHash: string;
  logIndex: number;
  blockNumber: number;
  blockHash: string;
  fromAddress: string;
  toAddress: string;
  amountRaw: string;
  amount: string;
}

export interface DepositWatcherCycleResult {
  status: "paused" | "locked" | "scanned";
  latestBlock: number | null;
  fromBlock: number | null;
  toBlock: number | null;
  detected: number;
  confirmed: number;
  orphaned: number;
  message?: string;
}

function shortError(error: unknown): string {
  const value = error instanceof Error ? error.message : String(error);
  return value.replace(blockchainConfig.rpcUrl || "", "[RPC]").slice(0, 1_000);
}

function chunks<T>(items: T[], size: number): T[][] {
  const output: T[][] = [];
  for (let index = 0; index < items.length; index += size) {
    output.push(items.slice(index, index + size));
  }
  return output;
}

function cursorId(): string {
  return `${WORKER_NAME}:${blockchainConfig.network.chainId}:${String(
    blockchainConfig.tokenAddress,
  ).toLowerCase()}`;
}

async function upsertWorkerStatus(input: {
  instanceId: string;
  status: "STOPPED" | "STARTING" | "IDLE" | "SCANNING" | "HEALTHY" | "PAUSED" | "ERROR";
  latestBlock?: number | null;
  lastScannedBlock?: number | null;
  lastFinalizedBlock?: number | null;
  detectedDelta?: number;
  confirmedDelta?: number;
  orphanedDelta?: number;
  error?: string | null;
  cycleStarted?: boolean;
  cycleCompleted?: boolean;
  metadata?: Record<string, unknown>;
}): Promise<void> {
  await query(
    `INSERT INTO blockchain_worker_status(
       worker_name, instance_id, status, chain_id, token_contract,
       latest_chain_block, last_scanned_block, last_finalized_block,
       detected_events, confirmed_events, orphaned_events,
       last_cycle_started_at, last_cycle_completed_at,
       heartbeat_at, last_error, metadata
     ) VALUES(
       $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,
       CASE WHEN $12 THEN now() ELSE NULL END,
       CASE WHEN $13 THEN now() ELSE NULL END,
       now(),$14,$15::jsonb
     )
     ON CONFLICT(worker_name) DO UPDATE SET
       instance_id = EXCLUDED.instance_id,
       status = EXCLUDED.status,
       chain_id = EXCLUDED.chain_id,
       token_contract = EXCLUDED.token_contract,
       latest_chain_block = COALESCE(EXCLUDED.latest_chain_block, blockchain_worker_status.latest_chain_block),
       last_scanned_block = COALESCE(EXCLUDED.last_scanned_block, blockchain_worker_status.last_scanned_block),
       last_finalized_block = COALESCE(EXCLUDED.last_finalized_block, blockchain_worker_status.last_finalized_block),
       detected_events = blockchain_worker_status.detected_events + $9,
       confirmed_events = blockchain_worker_status.confirmed_events + $10,
       orphaned_events = blockchain_worker_status.orphaned_events + $11,
       last_cycle_started_at = CASE WHEN $12 THEN now() ELSE blockchain_worker_status.last_cycle_started_at END,
       last_cycle_completed_at = CASE WHEN $13 THEN now() ELSE blockchain_worker_status.last_cycle_completed_at END,
       heartbeat_at = now(),
       last_error = $14,
       metadata = blockchain_worker_status.metadata || EXCLUDED.metadata,
       updated_at = now()`,
    [
      WORKER_NAME,
      input.instanceId,
      input.status,
      blockchainConfig.network.chainId,
      blockchainConfig.tokenAddress ?? null,
      input.latestBlock ?? null,
      input.lastScannedBlock ?? null,
      input.lastFinalizedBlock ?? null,
      input.detectedDelta ?? 0,
      input.confirmedDelta ?? 0,
      input.orphanedDelta ?? 0,
      Boolean(input.cycleStarted),
      Boolean(input.cycleCompleted),
      input.error ?? null,
      JSON.stringify(input.metadata ?? {}),
    ],
  );
}

async function ensureCursor(initialLastScannedBlock: number): Promise<void> {
  const initialFinalized = Math.max(
    0,
    Math.min(
      initialLastScannedBlock,
      initialLastScannedBlock - blockchainConfig.requiredConfirmations + 1,
    ),
  );

  await query(
    `INSERT INTO blockchain_cursors(
       id, worker_name, stream_name, chain_id, token_contract,
       last_scanned_block, last_finalized_block, metadata
     ) VALUES($1,$2,$3,$4,$5,$6,$7,$8::jsonb)
     ON CONFLICT(id) DO NOTHING`,
    [
      cursorId(),
      WORKER_NAME,
      STREAM_NAME,
      blockchainConfig.network.chainId,
      blockchainConfig.tokenAddress,
      initialLastScannedBlock,
      initialFinalized,
      JSON.stringify({ createdByStage: 4 }),
    ],
  );
}

async function acquireCursorLease(instanceId: string): Promise<CursorRow | null> {
  const result = await query<CursorRow>(
    `UPDATE blockchain_cursors
     SET lock_owner = $1,
         lock_expires_at = now() + ($2 || ' seconds')::interval,
         updated_at = now()
     WHERE id = $3
       AND (
         lock_owner = $1 OR
         lock_expires_at IS NULL OR
         lock_expires_at < now()
       )
     RETURNING id, last_scanned_block, last_finalized_block,
               last_block_hash, lock_owner, lock_expires_at`,
    [instanceId, blockchainConfig.cursorLeaseSeconds, cursorId()],
  );
  return result.rows[0] ?? null;
}

async function finishCursorLease(input: {
  instanceId: string;
  lastScannedBlock: number;
  lastFinalizedBlock: number;
  lastBlockHash: string | null;
  metadata?: Record<string, unknown>;
}): Promise<void> {
  const updated = await query(
    `UPDATE blockchain_cursors
     SET last_scanned_block = $1,
         last_finalized_block = LEAST($1, $2),
         last_block_hash = $3,
         metadata = metadata || $4::jsonb,
         lock_owner = NULL,
         lock_expires_at = NULL,
         updated_at = now()
     WHERE id = $5 AND lock_owner = $6`,
    [
      input.lastScannedBlock,
      input.lastFinalizedBlock,
      input.lastBlockHash,
      JSON.stringify(input.metadata ?? {}),
      cursorId(),
      input.instanceId,
    ],
  );
  if (updated.rowCount !== 1) {
    throw new Error("Deposit watcher cursor lease was lost before completion");
  }
}

async function releaseCursorLease(instanceId: string): Promise<void> {
  await query(
    `UPDATE blockchain_cursors
     SET lock_owner = NULL, lock_expires_at = NULL, updated_at = now()
     WHERE id = $1 AND lock_owner = $2`,
    [cursorId(), instanceId],
  );
}

async function activeDepositWallets(): Promise<DepositWalletRow[]> {
  const result = await query<DepositWalletRow>(
    `SELECT id, user_id, address
     FROM blockchain_wallets
     WHERE purpose = 'DEPOSIT'
       AND status = 'ACTIVE'
       AND chain_id = $1
     ORDER BY derivation_index ASC`,
    [blockchainConfig.network.chainId],
  );
  return result.rows;
}

function parseTransferLog(log: Log, tokenDecimals: number): ParsedTransfer {
  const parsed = TRANSFER_INTERFACE.parseLog({
    topics: [...log.topics],
    data: log.data,
  });
  if (!parsed) throw new Error("Unable to parse ERC20 Transfer log");
  if (!log.blockHash || !log.transactionHash) {
    throw new Error("Transfer log is missing canonical chain identifiers");
  }

  const value = BigInt(parsed.args[2]);
  if (value <= 0n) throw new Error("Transfer amount must be positive");

  return {
    txHash: log.transactionHash,
    logIndex: log.index,
    blockNumber: log.blockNumber,
    blockHash: log.blockHash,
    fromAddress: getAddress(String(parsed.args[0])),
    toAddress: getAddress(String(parsed.args[1])),
    amountRaw: value.toString(),
    amount: formatUnits(value, tokenDecimals),
  };
}

async function fetchMatchingTransferLogs(input: {
  wallets: DepositWalletRow[];
  fromBlock: number;
  toBlock: number;
}): Promise<Log[]> {
  if (input.wallets.length === 0) return [];
  if (!blockchainConfig.tokenAddress) throw new Error("Token contract is missing");

  const provider = getBlockchainProvider();
  const seen = new Set<string>();
  const output: Log[] = [];

  for (const group of chunks(input.wallets, blockchainConfig.addressTopicBatchSize)) {
    const destinationTopics = group.map((wallet) =>
      zeroPadValue(getAddress(wallet.address), 32),
    );
    const filter: Filter = {
      address: blockchainConfig.tokenAddress,
      fromBlock: input.fromBlock,
      toBlock: input.toBlock,
      topics: [TRANSFER_TOPIC, null, destinationTopics],
    };
    const logs = await provider.getLogs(filter);
    for (const log of logs) {
      const key = `${log.transactionHash.toLowerCase()}:${log.index}`;
      if (seen.has(key)) continue;
      seen.add(key);
      output.push(log);
    }
  }

  output.sort((left, right) =>
    left.blockNumber === right.blockNumber
      ? left.index - right.index
      : left.blockNumber - right.blockNumber,
  );
  return output;
}

async function markOrphanedDeposits(
  fromBlock: number,
  toBlock: number,
): Promise<number> {
  const candidates = await query<{
    id: string;
    user_id: string;
    status: string;
    block_number: string | number;
    block_hash: string;
  }>(
    `SELECT id, user_id, status, block_number, block_hash
     FROM blockchain_deposits
     WHERE chain_id = $1
       AND lower(token_contract) = lower($2)
       AND block_number BETWEEN $3 AND $4
       AND status NOT IN ('ORPHANED','IGNORED','FAILED','REVIEW_REQUIRED')`,
    [
      blockchainConfig.network.chainId,
      blockchainConfig.tokenAddress,
      fromBlock,
      toBlock,
    ],
  );
  if (candidates.rows.length === 0) return 0;

  const provider = getBlockchainProvider();
  const canonicalHashes = new Map<number, string | null>();
  for (const candidate of candidates.rows) {
    const blockNumber = Number(candidate.block_number);
    if (!canonicalHashes.has(blockNumber)) {
      const block = await provider.getBlock(blockNumber);
      canonicalHashes.set(blockNumber, block?.hash ?? null);
    }
  }

  const orphaned = candidates.rows.filter((candidate) => {
    const canonical = canonicalHashes.get(Number(candidate.block_number));
    return !canonical || canonical.toLowerCase() !== candidate.block_hash.toLowerCase();
  });

  if (orphaned.length === 0) return 0;
  const credited = orphaned.filter((candidate) => candidate.status === "CREDITED");
  const uncreditedIds = orphaned
    .filter((candidate) => candidate.status !== "CREDITED")
    .map((candidate) => candidate.id);

  return withTransaction(async (client) => {
    let affected = 0;
    if (uncreditedIds.length > 0) {
      const result = await client.query(
        `UPDATE blockchain_deposits
         SET status = 'ORPHANED', orphaned_at = now(),
             failure_reason = 'Block hash changed during canonical-chain recheck',
             updated_at = now()
         WHERE id = ANY($1::text[])
           AND status NOT IN ('ORPHANED','CREDITED','REVIEW_REQUIRED')`,
        [uncreditedIds],
      );
      affected += result.rowCount ?? 0;
    }

    if (credited.length > 0) {
      const creditedIds = credited.map((candidate) => candidate.id);
      const result = await client.query(
        `UPDATE blockchain_deposits
         SET status = 'REVIEW_REQUIRED', orphaned_at = now(),
             failure_reason = 'A credited deposit changed block hash and requires manual reconciliation',
             updated_at = now()
         WHERE id = ANY($1::text[]) AND status = 'CREDITED'`,
        [creditedIds],
      );
      affected += result.rowCount ?? 0;

      await client.query(
        `UPDATE blockchain_settings
         SET emergency_stop = TRUE,
             emergency_reason = 'Credited deposit reorg detected; manual reconciliation required',
             updated_at = now()
         WHERE id = 'default'`,
      );

      for (const candidate of credited) {
        await client.query(
          `INSERT INTO user_notifications(id,user_id,type,title,body,metadata)
           VALUES($1,$2,'DEPOSIT_REORG_REVIEW',$3,$4,$5::jsonb)`,
          [
            randomId(),
            candidate.user_id,
            "بررسی فنی واریز",
            "یکی از واریزهای تأییدشده به‌دلیل تغییر زنجیره نیازمند بررسی مدیر است. تا پایان بررسی، عملیات بلاک‌چین متوقف شده است.",
            JSON.stringify({ blockchainDepositId: candidate.id }),
          ],
        );
      }
    }
    return affected;
  });
}

async function saveTransferEvents(input: {
  logs: Log[];
  wallets: DepositWalletRow[];
  latestBlock: number;
  tokenDecimals: number;
  requiredConfirmations: number;
}): Promise<number> {
  const walletByAddress = new Map(
    input.wallets.map((wallet) => [getAddress(wallet.address).toLowerCase(), wallet]),
  );
  let affected = 0;

  await withTransaction(async (client) => {
    for (const log of input.logs) {
      const transfer = parseTransferLog(log, input.tokenDecimals);
      const wallet = walletByAddress.get(transfer.toAddress.toLowerCase());
      if (!wallet) continue;

      const confirmations = Math.max(0, input.latestBlock - transfer.blockNumber + 1);
      const status =
        confirmations >= input.requiredConfirmations ? "CONFIRMED" : "CONFIRMING";
      const idempotencyKey = `${blockchainConfig.network.chainId}:${transfer.txHash.toLowerCase()}:${transfer.logIndex}`;

      const result = await client.query<{ inserted: boolean }>(
        `INSERT INTO blockchain_deposits(
           id, user_id, wallet_id, chain_id, token_contract,
           tx_hash, log_index, block_number, block_hash,
           from_address, to_address, amount_raw, amount,
           confirmations, status, detected_at, confirmed_at, metadata
         ) VALUES(
           $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,
           now(),CASE WHEN $15 = 'CONFIRMED' THEN now() ELSE NULL END,$16::jsonb
         )
         ON CONFLICT(chain_id, (lower(tx_hash)), log_index) DO UPDATE SET
           user_id = EXCLUDED.user_id,
           wallet_id = EXCLUDED.wallet_id,
           token_contract = EXCLUDED.token_contract,
           block_number = EXCLUDED.block_number,
           block_hash = EXCLUDED.block_hash,
           from_address = EXCLUDED.from_address,
           to_address = EXCLUDED.to_address,
           amount_raw = EXCLUDED.amount_raw,
           amount = EXCLUDED.amount,
           confirmations = EXCLUDED.confirmations,
           status = CASE
             WHEN blockchain_deposits.status = 'CREDITED' THEN 'CREDITED'
             WHEN EXCLUDED.status = 'CONFIRMED' THEN 'CONFIRMED'
             ELSE 'CONFIRMING'
           END,
           confirmed_at = CASE
             WHEN blockchain_deposits.confirmed_at IS NOT NULL THEN blockchain_deposits.confirmed_at
             WHEN EXCLUDED.status = 'CONFIRMED' THEN now()
             ELSE NULL
           END,
           orphaned_at = NULL,
           failure_reason = NULL,
           metadata = blockchain_deposits.metadata || EXCLUDED.metadata,
           updated_at = now()
         RETURNING (xmax = 0) AS inserted`,
        [
          randomId(),
          wallet.user_id,
          wallet.id,
          blockchainConfig.network.chainId,
          blockchainConfig.tokenAddress,
          transfer.txHash,
          transfer.logIndex,
          transfer.blockNumber,
          transfer.blockHash,
          transfer.fromAddress,
          transfer.toAddress,
          transfer.amountRaw,
          transfer.amount,
          confirmations,
          status,
          JSON.stringify({ idempotencyKey, detectedBy: WORKER_NAME }),
        ],
      );
      if (result.rows[0]?.inserted) affected += 1;
    }
  });

  return affected;
}

async function refreshDepositConfirmations(input: {
  latestBlock: number;
  requiredConfirmations: number;
}): Promise<number> {
  const result = await query<{ newly_confirmed: number }>(
    `WITH candidates AS (
       SELECT id, status AS previous_status
       FROM blockchain_deposits
       WHERE chain_id = $3
         AND lower(token_contract) = lower($4)
         AND status IN ('DETECTED','CONFIRMING','CONFIRMED')
     ), updated AS (
       UPDATE blockchain_deposits d
       SET confirmations = GREATEST(0, $1 - d.block_number + 1),
           status = CASE
             WHEN d.status = 'CREDITED' THEN 'CREDITED'
             WHEN ($1 - d.block_number + 1) >= $2 THEN 'CONFIRMED'
             ELSE 'CONFIRMING'
           END,
           confirmed_at = CASE
             WHEN d.confirmed_at IS NOT NULL THEN d.confirmed_at
             WHEN ($1 - d.block_number + 1) >= $2 THEN now()
             ELSE NULL
           END,
           updated_at = now()
       FROM candidates c
       WHERE d.id = c.id
         AND (
           d.confirmations IS DISTINCT FROM GREATEST(0, $1 - d.block_number + 1) OR
           d.status IS DISTINCT FROM CASE
             WHEN ($1 - d.block_number + 1) >= $2 THEN 'CONFIRMED'
             ELSE 'CONFIRMING'
           END
         )
       RETURNING c.previous_status, d.status
     )
     SELECT COUNT(*) FILTER (
       WHERE previous_status <> 'CONFIRMED' AND status = 'CONFIRMED'
     )::int AS newly_confirmed
     FROM updated`,
    [
      input.latestBlock,
      input.requiredConfirmations,
      blockchainConfig.network.chainId,
      blockchainConfig.tokenAddress,
    ],
  );
  return Number(result.rows[0]?.newly_confirmed ?? 0);
}

export async function runDepositWatcherCycle(
  instanceId: string,
): Promise<DepositWatcherCycleResult> {
  const controls = await getBlockchainControls();
  const status = await getBlockchainStatus({ forceRefresh: true });

  if (
    !blockchainConfig.enabled ||
    !blockchainConfig.depositScannerEnabled ||
    !controls.depositsEnabled ||
    controls.emergencyStop
  ) {
    const reason = !blockchainConfig.enabled
      ? "Blockchain integration is disabled"
      : !blockchainConfig.depositScannerEnabled
        ? "Deposit scanner is disabled in environment"
        : !controls.depositsEnabled
          ? "Deposits are disabled in database controls"
          : controls.emergencyReason || "Blockchain emergency stop is active";
    await upsertWorkerStatus({
      instanceId,
      status: "PAUSED",
      latestBlock: status.latestBlock,
      error: null,
      cycleCompleted: true,
      metadata: { pauseReason: reason },
    });
    return {
      status: "paused",
      latestBlock: status.latestBlock,
      fromBlock: null,
      toBlock: null,
      detected: 0,
      confirmed: 0,
      orphaned: 0,
      message: reason,
    };
  }

  if (!status.healthy || status.latestBlock === null) {
    throw new Error(status.error || "Blockchain health probe failed");
  }
  if (!blockchainConfig.tokenAddress) throw new Error("Token contract is missing");
  if (controls.tokenDecimals > 18) {
    throw new Error("Token decimals greater than 18 are not supported by this ledger schema");
  }

  const latestBlock = status.latestBlock;
  const configuredStart = blockchainConfig.depositScanStartBlock;
  const startBlock =
    configuredStart === undefined
      ? Math.max(0, latestBlock - blockchainConfig.initialLookbackBlocks)
      : Math.min(configuredStart, latestBlock);

  await ensureCursor(Math.max(0, startBlock - 1));
  const cursor = await acquireCursorLease(instanceId);
  if (!cursor) {
    await upsertWorkerStatus({
      instanceId,
      status: "IDLE",
      latestBlock,
      error: null,
      cycleCompleted: true,
      metadata: { reason: "cursor-locked-by-another-instance" },
    });
    return {
      status: "locked",
      latestBlock,
      fromBlock: null,
      toBlock: null,
      detected: 0,
      confirmed: 0,
      orphaned: 0,
      message: "Another deposit watcher instance owns the cursor lease",
    };
  }

  await upsertWorkerStatus({
    instanceId,
    status: "SCANNING",
    latestBlock,
    lastScannedBlock: Number(cursor.last_scanned_block),
    lastFinalizedBlock: Number(cursor.last_finalized_block),
    error: null,
    cycleStarted: true,
  });

  try {
    const cursorLastScanned = Number(cursor.last_scanned_block);
    if (latestBlock + controls.reorgBufferBlocks < cursorLastScanned) {
      throw new Error(
        `RPC head ${latestBlock} is too far behind deposit cursor ${cursorLastScanned}`,
      );
    }
    const previousLastScanned = Math.max(
      Number(cursor.last_scanned_block),
      Math.max(0, startBlock - 1),
    );
    const fromBlock = Math.max(
      startBlock,
      previousLastScanned - controls.reorgBufferBlocks + 1,
    );
    const toBlock = Math.min(
      latestBlock,
      previousLastScanned + controls.scanBatchSize,
    );
    const wallets = await activeDepositWallets();
    const orphaned = await markOrphanedDeposits(fromBlock, toBlock);
    const logs = await fetchMatchingTransferLogs({ wallets, fromBlock, toBlock });
    const detected = await saveTransferEvents({
      logs,
      wallets,
      latestBlock,
      tokenDecimals: controls.tokenDecimals,
      requiredConfirmations: controls.requiredConfirmations,
    });
    const confirmed = await refreshDepositConfirmations({
      latestBlock,
      requiredConfirmations: controls.requiredConfirmations,
    });

    const newLastScanned = Math.max(previousLastScanned, toBlock);
    const finalizedHead = Math.max(
      0,
      latestBlock - controls.requiredConfirmations + 1,
    );
    const lastFinalized = Math.min(newLastScanned, finalizedHead);
    const endBlock = await getBlockchainProvider().getBlock(newLastScanned);

    await finishCursorLease({
      instanceId,
      lastScannedBlock: newLastScanned,
      lastFinalizedBlock: lastFinalized,
      lastBlockHash: endBlock?.hash ?? null,
      metadata: {
        latestBlock,
        activeWallets: wallets.length,
        logsMatched: logs.length,
        lastCycleAt: new Date().toISOString(),
      },
    });

    await upsertWorkerStatus({
      instanceId,
      status: "HEALTHY",
      latestBlock,
      lastScannedBlock: newLastScanned,
      lastFinalizedBlock: lastFinalized,
      detectedDelta: detected,
      confirmedDelta: confirmed,
      orphanedDelta: orphaned,
      error: null,
      cycleCompleted: true,
      metadata: { activeWallets: wallets.length, logsMatched: logs.length },
    });

    return {
      status: "scanned",
      latestBlock,
      fromBlock,
      toBlock,
      detected,
      confirmed,
      orphaned,
    };
  } catch (error) {
    await releaseCursorLease(instanceId);
    await upsertWorkerStatus({
      instanceId,
      status: "ERROR",
      latestBlock,
      error: shortError(error),
      cycleCompleted: true,
    });
    throw error;
  }
}

export async function getDepositWatcherStatus() {
  const [worker, cursor, counts] = await Promise.all([
    query(
      `SELECT worker_name, instance_id, status, chain_id, token_contract,
              latest_chain_block, last_scanned_block, last_finalized_block,
              detected_events, confirmed_events, orphaned_events,
              last_cycle_started_at, last_cycle_completed_at,
              heartbeat_at, last_error, metadata, updated_at
       FROM blockchain_worker_status
       WHERE worker_name = $1`,
      [WORKER_NAME],
    ),
    query(
      `SELECT last_scanned_block, last_finalized_block, last_block_hash,
              lock_owner, lock_expires_at, metadata, updated_at
       FROM blockchain_cursors WHERE id = $1`,
      [cursorId()],
    ),
    query(
      `SELECT status, COUNT(*)::int AS count
       FROM blockchain_deposits
       WHERE chain_id = $1 AND lower(token_contract) = lower($2)
       GROUP BY status`,
      [blockchainConfig.network.chainId, blockchainConfig.tokenAddress],
    ),
  ]);

  return {
    configured: blockchainConfig.configured,
    environmentEnabled:
      blockchainConfig.enabled && blockchainConfig.depositScannerEnabled,
    worker: worker.rows[0] ?? null,
    cursor: cursor.rows[0] ?? null,
    depositCounts: Object.fromEntries(
      counts.rows.map((row) => [row.status, Number(row.count)]),
    ),
    checkedAt: new Date().toISOString(),
  };
}

export const depositWatcherInternals = {
  chunks,
  parseTransferLog,
  transferTopic: TRANSFER_TOPIC,
};
