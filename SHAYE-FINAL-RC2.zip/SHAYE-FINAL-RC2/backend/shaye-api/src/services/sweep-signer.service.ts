import fs from "node:fs";
import {
  HDNodeWallet,
  JsonRpcProvider,
  Wallet,
  getAddress,
} from "ethers";
import { blockchainConfig } from "../config/blockchain";
import { depositWalletConfig } from "../config/deposit-wallet";

let cachedGasWallet: Wallet | null = null;
let cachedMnemonic: string | null = null;

function readSecret(file: string, label: string): string {
  try {
    const value = fs.readFileSync(file, "utf8").trim();
    if (!value) throw new Error(`${label} is empty`);
    return value;
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error);
    throw new Error(`${label} secret is not readable: ${file} (${reason})`);
  }
}

export function getGasWalletSigner(provider: JsonRpcProvider): Wallet {
  if (!blockchainConfig.gasWalletAddress) {
    throw new Error("GAS_WALLET_ADDRESS is not configured");
  }
  if (!cachedGasWallet) {
    const privateKey = readSecret(
      blockchainConfig.gasWalletPrivateKeyFile,
      "Gas wallet private key",
    );
    if (!/^0x[0-9a-fA-F]{64}$/.test(privateKey)) {
      throw new Error("Gas wallet private key is invalid");
    }
    cachedGasWallet = new Wallet(privateKey);
  }
  const actual = getAddress(cachedGasWallet.address);
  const expected = getAddress(blockchainConfig.gasWalletAddress);
  if (actual !== expected) {
    throw new Error("Gas wallet private key does not match GAS_WALLET_ADDRESS");
  }
  return cachedGasWallet.connect(provider);
}

export function getDepositWalletSigner(
  provider: JsonRpcProvider,
  derivationIndex: number,
  expectedAddress: string,
): HDNodeWallet {
  if (!Number.isSafeInteger(derivationIndex) || derivationIndex < 0) {
    throw new Error("Deposit wallet derivation index is invalid");
  }
  if (!cachedMnemonic) {
    cachedMnemonic = readSecret(
      blockchainConfig.depositWalletMnemonicFile,
      "Deposit wallet mnemonic",
    );
  }
  const account = HDNodeWallet.fromPhrase(
    cachedMnemonic,
    undefined,
    depositWalletConfig.accountPath,
  );
  const child = account.derivePath(
    `${depositWalletConfig.changeIndex}/${derivationIndex}`,
  );
  if (getAddress(child.address) !== getAddress(expectedAddress)) {
    throw new Error(
      "Derived deposit-wallet key does not match the public address in PostgreSQL",
    );
  }
  return child.connect(provider);
}

export function clearSweepSignerCache(): void {
  cachedGasWallet = null;
  cachedMnemonic = null;
}
