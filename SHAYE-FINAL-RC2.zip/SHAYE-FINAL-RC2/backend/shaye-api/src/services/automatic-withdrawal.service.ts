import { PoolClient } from "pg";
import { query, withTransaction } from "../config/database";
import { getBlockchainControls } from "./blockchain-database.service";
import { randomId } from "../utils/helpers";
import { getSettings } from "./settings.service";
import { dateKey as makeDateKey } from "../utils/date";

export interface AutoWithdrawalPolicyInput {
  enabled: boolean;
  maxAmount: number;
  dailyLimit: number;
  dailyCountLimit: number;
  maxConcurrent: number;
}

export interface AutoWithdrawalDecisionInput {
  amount: number;
  currentDailyAmount: number;
  currentDailyCount: number;
  currentConcurrent: number;
}

export interface AutoWithdrawalDecision {
  automatic: boolean;
  reason: string;
}

export function evaluateAutoWithdrawalEligibility(
  policy: AutoWithdrawalPolicyInput,
  input: AutoWithdrawalDecisionInput,
): AutoWithdrawalDecision {
  if (!policy.enabled) {
    return { automatic: false, reason: "AUTO_WITHDRAW_DISABLED" };
  }
  if (input.amount <= 0) {
    return { automatic: false, reason: "INVALID_AMOUNT" };
  }
  if (input.amount > policy.maxAmount) {
    return { automatic: false, reason: "ABOVE_PER_REQUEST_LIMIT" };
  }
  if (input.currentDailyCount >= policy.dailyCountLimit) {
    return { automatic: false, reason: "DAILY_COUNT_LIMIT_REACHED" };
  }
  if (input.currentDailyAmount + input.amount > policy.dailyLimit) {
    return { automatic: false, reason: "DAILY_AMOUNT_LIMIT_REACHED" };
  }
  if (input.currentConcurrent >= policy.maxConcurrent) {
    return { automatic: false, reason: "CONCURRENT_LIMIT_REACHED" };
  }
  return { automatic: true, reason: "WITHIN_AUTOMATIC_LIMITS" };
}

export async function reserveAutomaticWithdrawalBudget(
  client: PoolClient,
  input: {
    amount: number;
    dateKey: string;
  },
): Promise<AutoWithdrawalDecision & { policy: AutoWithdrawalPolicyInput }> {
  const settingsResult = await client.query(
    `SELECT auto_withdrawals_enabled, auto_withdrawal_max_amount,
            auto_withdrawal_daily_limit, auto_withdrawal_daily_count_limit,
            auto_withdrawal_max_concurrent, withdrawals_enabled,
            withdrawal_worker_enabled, emergency_stop
     FROM blockchain_settings
     WHERE id = 'default'
     FOR UPDATE`,
  );
  const row = settingsResult.rows[0];
  if (!row) throw new Error("Blockchain settings row is missing");

  const policy: AutoWithdrawalPolicyInput = {
    enabled:
      Boolean(row.auto_withdrawals_enabled) &&
      Boolean(row.withdrawals_enabled) &&
      Boolean(row.withdrawal_worker_enabled) &&
      !Boolean(row.emergency_stop),
    maxAmount: Number(row.auto_withdrawal_max_amount),
    dailyLimit: Number(row.auto_withdrawal_daily_limit),
    dailyCountLimit: Number(row.auto_withdrawal_daily_count_limit),
    maxConcurrent: Number(row.auto_withdrawal_max_concurrent),
  };

  await client.query(
    `INSERT INTO withdrawal_auto_daily_usage(date_key)
     VALUES($1)
     ON CONFLICT(date_key) DO NOTHING`,
    [input.dateKey],
  );
  const usageResult = await client.query(
    `SELECT total_amount, request_count
     FROM withdrawal_auto_daily_usage
     WHERE date_key = $1
     FOR UPDATE`,
    [input.dateKey],
  );
  const usage = usageResult.rows[0];
  const concurrentResult = await client.query<{ count: number }>(
    `SELECT count(*)::int AS count
     FROM blockchain_withdrawals
     WHERE approval_mode = 'AUTOMATIC'
       AND status IN ('QUEUED','RESERVED','SIGNING','BROADCASTED','CONFIRMING','CONFIRMED')`,
  );

  const decision = evaluateAutoWithdrawalEligibility(policy, {
    amount: input.amount,
    currentDailyAmount: Number(usage?.total_amount ?? 0),
    currentDailyCount: Number(usage?.request_count ?? 0),
    currentConcurrent: Number(concurrentResult.rows[0]?.count ?? 0),
  });

  if (decision.automatic) {
    await client.query(
      `UPDATE withdrawal_auto_daily_usage
       SET total_amount = total_amount + $1,
           request_count = request_count + 1,
           updated_at = now()
       WHERE date_key = $2`,
      [input.amount, input.dateKey],
    );
  }

  return { ...decision, policy };
}

export async function getAutomaticWithdrawalSettings(timezoneDateKey?: string) {
  const [controls, appSettings] = await Promise.all([
    getBlockchainControls(),
    getSettings(),
  ]);
  const dateKey = timezoneDateKey ?? makeDateKey(new Date(), appSettings.timezone);
  const [usageResult, countsResult] = await Promise.all([
    query(
      `SELECT total_amount, request_count, updated_at
       FROM withdrawal_auto_daily_usage
       WHERE date_key = $1`,
      [dateKey],
    ),
    query(
      `SELECT
         count(*) FILTER (WHERE approval_mode='AUTOMATIC')::int AS automatic_total,
         count(*) FILTER (
           WHERE approval_mode='AUTOMATIC'
             AND status IN ('QUEUED','RESERVED','SIGNING','BROADCASTED','CONFIRMING','CONFIRMED')
         )::int AS automatic_active,
         count(*) FILTER (WHERE approval_mode='MANUAL' AND status='AWAITING_APPROVAL')::int AS manual_waiting
       FROM blockchain_withdrawals`,
    ),
  ]);

  const usage = usageResult.rows[0] ?? {
    total_amount: 0,
    request_count: 0,
    updated_at: null,
  };
  return {
    enabled: controls.autoWithdrawalsEnabled,
    maxAmount: controls.autoWithdrawalMaxAmount,
    dailyLimit: controls.autoWithdrawalDailyLimit,
    dailyCountLimit: controls.autoWithdrawalDailyCountLimit,
    maxConcurrent: controls.autoWithdrawalMaxConcurrent,
    minTokenReserve: controls.hotWalletMinTokenReserve,
    minBnbReserve: controls.hotWalletMinBnbReserve,
    pauseReason: controls.autoWithdrawalPauseReason,
    pausedAt: controls.autoWithdrawalPausedAt,
    dateKey,
    usage: {
      amount: Number(usage.total_amount ?? 0),
      count: Number(usage.request_count ?? 0),
      updatedAt: usage.updated_at ?? null,
    },
    counts: countsResult.rows[0],
  };
}

export async function updateAutomaticWithdrawalSettings(
  adminId: string,
  input: {
    enabled: boolean;
    maxAmount: number;
    dailyLimit: number;
    dailyCountLimit: number;
    maxConcurrent: number;
    minTokenReserve: number;
    minBnbReserve: number;
  },
) {
  return withTransaction(async (client) => {
    const updated = await client.query(
      `UPDATE blockchain_settings
       SET auto_withdrawals_enabled = $1,
           auto_withdrawal_max_amount = $2,
           auto_withdrawal_daily_limit = $3,
           auto_withdrawal_daily_count_limit = $4,
           auto_withdrawal_max_concurrent = $5,
           hot_wallet_min_token_reserve = $6,
           hot_wallet_min_bnb_reserve = $7,
           auto_withdrawal_pause_reason = CASE WHEN $1 THEN NULL ELSE auto_withdrawal_pause_reason END,
           auto_withdrawal_paused_at = CASE WHEN $1 THEN NULL ELSE auto_withdrawal_paused_at END,
           updated_by = $8,
           updated_at = now()
       WHERE id = 'default'
       RETURNING *`,
      [
        input.enabled,
        input.maxAmount,
        input.dailyLimit,
        input.dailyCountLimit,
        input.maxConcurrent,
        input.minTokenReserve,
        input.minBnbReserve,
        adminId,
      ],
    );
    await client.query(
      `INSERT INTO admin_action_logs(
         id, action, target_type, target_id, metadata, actor_id
       ) VALUES($1,'UPDATE_AUTO_WITHDRAWAL_POLICY','BlockchainSettings','default',$2::jsonb,$3)`,
      [randomId(), JSON.stringify(input), adminId],
    );
    return updated.rows[0];
  });
}

export async function pauseAutomaticWithdrawals(
  reason: string,
  actorId?: string | null,
) {
  const result = await query(
    `UPDATE blockchain_settings
     SET auto_withdrawals_enabled = FALSE,
         auto_withdrawal_pause_reason = left($1, 1000),
         auto_withdrawal_paused_at = now(),
         updated_by = COALESCE($2, updated_by),
         updated_at = now()
     WHERE id = 'default'
     RETURNING auto_withdrawals_enabled, auto_withdrawal_pause_reason,
               auto_withdrawal_paused_at`,
    [reason, actorId ?? null],
  );
  return result.rows[0];
}
