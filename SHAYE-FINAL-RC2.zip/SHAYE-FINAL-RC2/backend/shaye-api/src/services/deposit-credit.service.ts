import { PoolClient } from "pg";
import { blockchainConfig } from "../config/blockchain";
import { query, withTransaction } from "../config/database";
import { BlockchainJobRow, LedgerPostingEntry } from "../db/blockchain.types";
import {
  claimBlockchainJobs,
  completeBlockchainJob,
  enqueueBlockchainJob,
  ensureUserLedgerAccounts,
  failBlockchainJob,
  getBlockchainControls,
  postLedgerJournal,
} from "./blockchain-database.service";
import { createNotification } from "./notification.service";
import { syncVipLevel } from "./settings.service";
import { grantFirstVipReferralSpins } from "./wheel.service";
import { money, randomId } from "../utils/helpers";
import { percentage } from "../utils/wallet";

const WORKER_NAME = "deposit-credit-worker";
const MAX_BUSINESS_AMOUNT = 999_999_999_999;

interface BlockchainDepositRow {
  id: string;
  deposit_id: string | null;
  user_id: string;
  chain_id: string | number;
  token_contract: string;
  tx_hash: string;
  log_index: number;
  block_number: string | number;
  amount: string | number;
  confirmations: number;
  status: string;
  confirmed_at: Date | null;
  credited_at: Date | null;
}

interface AppSettingsRow {
  min_deposit: string | number;
  lock_days: number;
  level1_referral_rate: string | number;
  level2_referral_rate: string | number;
  funding_mode: "MANUAL" | "BLOCKCHAIN";
}

interface UserCreditRow {
  id: string;
  email: string;
  referred_by_id: string | null;
  vip_level: number;
  is_active: boolean;
}

interface CreditResult {
  blockchainDepositId: string;
  status: "credited" | "already_credited" | "ignored" | "skipped";
  depositId?: string;
  amount?: number;
  vipLevelBefore?: number;
  vipLevelAfter?: number;
  unlockAt?: Date;
  level1Reward?: number;
  level2Reward?: number;
  wheelSpinsGranted?: number;
  reason?: string;
}

function shortError(error: unknown): string {
  return (error instanceof Error ? error.message : String(error)).slice(0, 4_000);
}

function businessAmount(value: string | number): number {
  const amount = money(value);
  if (!Number.isFinite(amount) || amount <= 0 || amount > MAX_BUSINESS_AMOUNT) {
    throw new Error("Blockchain deposit amount cannot be represented by the business ledger");
  }
  return amount;
}

function percentageReward(amount: number, rate: number): number {
  const reward = percentage(amount, rate);
  return reward > 0 ? reward : 0;
}

function creditJobKey(blockchainDepositId: string): string {
  return `credit-deposit:${blockchainDepositId}`;
}

function referenceCode(row: BlockchainDepositRow): string {
  return `BC-${row.chain_id}-${row.tx_hash.slice(2).toUpperCase()}-${row.log_index}`;
}

async function upsertWorkerStatus(input: {
  instanceId: string;
  status: "STARTING" | "IDLE" | "HEALTHY" | "PAUSED" | "ERROR";
  processedDelta?: number;
  creditedDelta?: number;
  ignoredDelta?: number;
  failedDelta?: number;
  error?: string | null;
  cycleStarted?: boolean;
  cycleCompleted?: boolean;
  metadata?: Record<string, unknown>;
}) {
  await query(
    `INSERT INTO blockchain_worker_status(
       worker_name, instance_id, status, chain_id, token_contract,
       detected_events, confirmed_events, orphaned_events,
       last_cycle_started_at, last_cycle_completed_at,
       heartbeat_at, last_error, metadata
     ) VALUES(
       $1,$2,$3,$4,$5,$6,$7,$8,
       CASE WHEN $9 THEN now() ELSE NULL END,
       CASE WHEN $10 THEN now() ELSE NULL END,
       now(),$11,$12::jsonb
     )
     ON CONFLICT(worker_name) DO UPDATE SET
       instance_id = EXCLUDED.instance_id,
       status = EXCLUDED.status,
       chain_id = EXCLUDED.chain_id,
       token_contract = EXCLUDED.token_contract,
       detected_events = blockchain_worker_status.detected_events + $6,
       confirmed_events = blockchain_worker_status.confirmed_events + $7,
       orphaned_events = blockchain_worker_status.orphaned_events + $8,
       last_cycle_started_at = CASE WHEN $9 THEN now() ELSE blockchain_worker_status.last_cycle_started_at END,
       last_cycle_completed_at = CASE WHEN $10 THEN now() ELSE blockchain_worker_status.last_cycle_completed_at END,
       heartbeat_at = now(),
       last_error = $11,
       metadata = blockchain_worker_status.metadata || EXCLUDED.metadata,
       updated_at = now()`,
    [
      WORKER_NAME,
      input.instanceId,
      input.status,
      blockchainConfig.network.chainId,
      blockchainConfig.tokenAddress ?? null,
      input.processedDelta ?? 0,
      input.creditedDelta ?? 0,
      input.ignoredDelta ?? 0,
      Boolean(input.cycleStarted),
      Boolean(input.cycleCompleted),
      input.error ?? null,
      JSON.stringify({
        failedDelta: input.failedDelta ?? 0,
        ...(input.metadata ?? {}),
      }),
    ],
  );
}

export async function enqueueConfirmedDepositCreditJobs(limit = 100): Promise<number> {
  const safeLimit = Math.max(1, Math.min(Math.trunc(limit) || 100, 500));
  const result = await query<{ id: string }>(
    `SELECT d.id
     FROM blockchain_deposits d
     WHERE d.status = 'CONFIRMED'
       AND d.chain_id = $1
       AND lower(d.token_contract) = lower($2)
       AND NOT EXISTS (
         SELECT 1 FROM deposit_credit_settlements s
         WHERE s.blockchain_deposit_id = d.id
       )
     ORDER BY d.confirmed_at ASC NULLS LAST, d.created_at ASC
     LIMIT $3`,
    [blockchainConfig.network.chainId, blockchainConfig.tokenAddress, safeLimit],
  );

  for (const row of result.rows) {
    await enqueueBlockchainJob({
      type: "CREDIT_DEPOSIT",
      idempotencyKey: creditJobKey(row.id),
      payload: { blockchainDepositId: row.id },
      priority: 20,
      maxAttempts: 20,
    });
    await query(
      `UPDATE blockchain_deposits
       SET credit_job_enqueued_at = COALESCE(credit_job_enqueued_at, now()),
           updated_at = now()
       WHERE id = $1`,
      [row.id],
    );
  }

  return result.rows.length;
}

async function lockCreditUsers(
  client: PoolClient,
  sourceUserId: string,
): Promise<Map<string, UserCreditRow>> {
  const source = await client.query<UserCreditRow>(
    `SELECT id, email, referred_by_id, vip_level, is_active
     FROM users WHERE id = $1`,
    [sourceUserId],
  );
  const sourceUser = source.rows[0];
  if (!sourceUser) throw new Error("Deposit owner no longer exists");

  let secondReferrerId: string | null = null;
  if (sourceUser.referred_by_id) {
    const direct = await client.query<{ referred_by_id: string | null }>(
      "SELECT referred_by_id FROM users WHERE id = $1",
      [sourceUser.referred_by_id],
    );
    secondReferrerId = direct.rows[0]?.referred_by_id ?? null;
  }

  const ids = [...new Set([
    sourceUser.id,
    sourceUser.referred_by_id,
    secondReferrerId,
  ].filter((value): value is string => Boolean(value)))].sort();

  const locked = await client.query<UserCreditRow>(
    `SELECT id, email, referred_by_id, vip_level, is_active
     FROM users
     WHERE id = ANY($1::text[])
     ORDER BY id
     FOR UPDATE`,
    [ids],
  );
  return new Map(locked.rows.map((row) => [row.id, row]));
}

async function addReferralReward(input: {
  client: PoolClient;
  referrer: UserCreditRow | undefined;
  amount: number;
  rate: number;
  level: 1 | 2;
  sourceUserId: string;
  blockchainDepositId: string;
  depositId: string;
}): Promise<{ reward: number; profitAccountId: string | null }> {
  const { client, referrer } = input;
  if (!referrer?.is_active) return { reward: 0, profitAccountId: null };

  const reward = percentageReward(input.amount, input.rate);
  if (reward <= 0) return { reward: 0, profitAccountId: null };

  const updated = await client.query(
    `UPDATE users
     SET profit_balance = profit_balance + $1,
         total_profit = total_profit + $1,
         referral_profit = referral_profit + $1,
         updated_at = now()
     WHERE id = $2 AND is_active = TRUE`,
    [reward, referrer.id],
  );
  if (updated.rowCount !== 1) return { reward: 0, profitAccountId: null };

  await client.query(
    `INSERT INTO transactions(
       id, type, amount, description, metadata, user_id
     ) VALUES($1,'REFERRAL_REWARD',$2,$3,$4::jsonb,$5)`,
    [
      randomId(),
      reward,
      `پاداش معرفی سطح ${input.level}`,
      JSON.stringify({
        sourceUserId: input.sourceUserId,
        blockchainDepositId: input.blockchainDepositId,
        sourceDepositId: input.depositId,
        level: input.level,
        rate: input.rate,
      }),
      referrer.id,
    ],
  );

  await createNotification(client, {
    userId: referrer.id,
    type: "REFERRAL_REWARD",
    title: `پاداش معرفی سطح ${input.level}`,
    body: `${reward} USDT پاداش معرفی به موجودی قابل برداشت شما اضافه شد.`,
    metadata: {
      sourceUserId: input.sourceUserId,
      blockchainDepositId: input.blockchainDepositId,
      amount: reward,
      level: input.level,
    },
  });

  const accounts = await ensureUserLedgerAccounts(client, referrer.id);
  return { reward, profitAccountId: accounts.profitAccountId };
}

export async function creditConfirmedBlockchainDeposit(
  blockchainDepositId: string,
): Promise<CreditResult> {
  return withTransaction(async (client) => {
    const depositResult = await client.query<BlockchainDepositRow>(
      `SELECT id, deposit_id, user_id, chain_id, token_contract, tx_hash,
              log_index, block_number, amount, confirmations, status,
              confirmed_at, credited_at
       FROM blockchain_deposits
       WHERE id = $1
       FOR UPDATE`,
      [blockchainDepositId],
    );
    const chainDeposit = depositResult.rows[0];
    if (!chainDeposit) throw new Error("Blockchain deposit does not exist");

    const existingSettlement = await client.query<{
      deposit_id: string;
      amount: string | number;
      vip_level_before: number;
      vip_level_after: number;
      unlock_at: Date;
      level1_referral_reward: string | number;
      level2_referral_reward: string | number;
      wheel_spins_granted: number;
    }>(
      `SELECT deposit_id, amount, vip_level_before, vip_level_after,
              unlock_at, level1_referral_reward, level2_referral_reward,
              wheel_spins_granted
       FROM deposit_credit_settlements
       WHERE blockchain_deposit_id = $1`,
      [blockchainDepositId],
    );
    if (existingSettlement.rows[0]) {
      const prior = existingSettlement.rows[0];
      if (chainDeposit.status !== "CREDITED") {
        await client.query(
          `UPDATE blockchain_deposits
           SET status = 'CREDITED', deposit_id = $1,
               credited_at = COALESCE(credited_at, now()), updated_at = now()
           WHERE id = $2`,
          [prior.deposit_id, blockchainDepositId],
        );
      }
      return {
        blockchainDepositId,
        status: "already_credited",
        depositId: prior.deposit_id,
        amount: Number(prior.amount),
        vipLevelBefore: Number(prior.vip_level_before),
        vipLevelAfter: Number(prior.vip_level_after),
        unlockAt: prior.unlock_at,
        level1Reward: Number(prior.level1_referral_reward),
        level2Reward: Number(prior.level2_referral_reward),
        wheelSpinsGranted: Number(prior.wheel_spins_granted),
      };
    }

    if (chainDeposit.status === "CREDITED") {
      return {
        blockchainDepositId,
        status: "already_credited",
        depositId: chainDeposit.deposit_id ?? undefined,
      };
    }
    if (chainDeposit.status !== "CONFIRMED") {
      return {
        blockchainDepositId,
        status: "skipped",
        reason: `Deposit status is ${chainDeposit.status}`,
      };
    }

    const settingsResult = await client.query<AppSettingsRow>(
      `SELECT min_deposit, lock_days, level1_referral_rate,
              level2_referral_rate, funding_mode
       FROM app_settings
       WHERE id = 'default'
       FOR SHARE`,
    );
    const settings = settingsResult.rows[0];
    if (!settings) throw new Error("Application settings are missing");
    if (settings.funding_mode !== "BLOCKCHAIN") {
      throw new Error("Automatic blockchain credit is disabled by application funding mode");
    }

    const amount = businessAmount(chainDeposit.amount);
    const minimum = Number(settings.min_deposit);
    if (amount < minimum) {
      const reason = `Amount ${amount} is below minimum deposit ${minimum}`;
      await client.query(
        `UPDATE blockchain_deposits
         SET status = 'IGNORED', credit_failure_reason = $1,
             failure_reason = $1, updated_at = now()
         WHERE id = $2`,
        [reason, blockchainDepositId],
      );
      await createNotification(client, {
        userId: chainDeposit.user_id,
        type: "DEPOSIT_BELOW_MINIMUM",
        title: "واریز کمتر از حداقل مجاز",
        body: `واریز ${amount} USDT شناسایی شد اما حداقل واریز ${minimum} USDT است و به سرمایه فعال اضافه نشد.`,
        metadata: {
          blockchainDepositId,
          txHash: chainDeposit.tx_hash,
          amount,
          minimum,
        },
      });
      return { blockchainDepositId, status: "ignored", amount, reason };
    }

    const users = await lockCreditUsers(client, chainDeposit.user_id);
    const sourceUser = users.get(chainDeposit.user_id);
    if (!sourceUser) throw new Error("Deposit owner could not be locked");
    const directReferrer = sourceUser.referred_by_id
      ? users.get(sourceUser.referred_by_id)
      : undefined;
    const secondReferrer = directReferrer?.referred_by_id
      ? users.get(directReferrer.referred_by_id)
      : undefined;

    const vipBefore = Number(sourceUser.vip_level || 0);
    const lockDays = Number(settings.lock_days);
    const level1Rate = Number(settings.level1_referral_rate);
    const level2Rate = Number(settings.level2_referral_rate);
    const businessDepositId = randomId();
    const lockPositionId = randomId();
    const settlementId = randomId();

    await client.query(
      `INSERT INTO deposits(
         id, amount, reference_code, tx_hash, status, note,
         reviewed_at, user_id, source, chain_id, token_contract
       ) VALUES($1,$2,$3,$4,'APPROVED',$5,now(),$6,'BLOCKCHAIN',$7,$8)`,
      [
        businessDepositId,
        amount,
        referenceCode(chainDeposit),
        chainDeposit.tx_hash,
        `تأیید خودکار پس از ${chainDeposit.confirmations} تأیید شبکه`,
        chainDeposit.user_id,
        chainDeposit.chain_id,
        chainDeposit.token_contract,
      ],
    );

    const lockResult = await client.query<{ unlock_at: Date }>(
      `INSERT INTO lock_positions(
         id, amount, unlock_at, source_deposit_id, user_id,
         lock_days_snapshot, source_blockchain_deposit_id, metadata
       ) VALUES(
         $1,$2,now() + ($3 || ' days')::interval,$4,$5,$3,$6,$7::jsonb
       )
       RETURNING unlock_at`,
      [
        lockPositionId,
        amount,
        lockDays,
        businessDepositId,
        chainDeposit.user_id,
        blockchainDepositId,
        JSON.stringify({
          chainId: Number(chainDeposit.chain_id),
          txHash: chainDeposit.tx_hash,
          logIndex: chainDeposit.log_index,
        }),
      ],
    );
    const unlockAt = lockResult.rows[0]!.unlock_at;

    await client.query(
      `UPDATE users
       SET locked_balance = locked_balance + $1,
           total_deposit = total_deposit + $1,
           updated_at = now()
       WHERE id = $2`,
      [amount, chainDeposit.user_id],
    );

    await client.query(
      `INSERT INTO transactions(
         id, type, amount, description, metadata, user_id
       ) VALUES($1,'BLOCKCHAIN_DEPOSIT_CREDITED',$2,$3,$4::jsonb,$5)`,
      [
        randomId(),
        amount,
        "واریز بلاک‌چینی تأیید و اصل سرمایه قفل شد",
        JSON.stringify({
          blockchainDepositId,
          depositId: businessDepositId,
          lockPositionId,
          lockDays,
          unlockAt,
          txHash: chainDeposit.tx_hash,
        }),
        chainDeposit.user_id,
      ],
    );

    const sourceAccounts = await ensureUserLedgerAccounts(client, chainDeposit.user_id);
    const principalJournalId = await postLedgerJournal(client, {
      idempotencyKey: `ledger:deposit-credit:${blockchainDepositId}`,
      referenceType: "BlockchainDeposit",
      referenceId: blockchainDepositId,
      description: "Credit confirmed blockchain deposit principal",
      metadata: {
        depositId: businessDepositId,
        txHash: chainDeposit.tx_hash,
        lockPositionId,
      },
      entries: [
        {
          accountId: "sys-usdt-in-transit",
          direction: "DEBIT",
          amount: String(amount),
          memo: "Confirmed token received in user deposit address",
        },
        {
          accountId: sourceAccounts.principalAccountId,
          direction: "CREDIT",
          amount: String(amount),
          userId: chainDeposit.user_id,
          memo: "User locked principal liability",
        },
      ],
    });

    const level1 = await addReferralReward({
      client,
      referrer: directReferrer,
      amount,
      rate: level1Rate,
      level: 1,
      sourceUserId: chainDeposit.user_id,
      blockchainDepositId,
      depositId: businessDepositId,
    });
    const level2 = await addReferralReward({
      client,
      referrer: secondReferrer,
      amount,
      rate: level2Rate,
      level: 2,
      sourceUserId: chainDeposit.user_id,
      blockchainDepositId,
      depositId: businessDepositId,
    });

    let referralJournalId: string | null = null;
    const referralTotal = money(level1.reward + level2.reward);
    if (referralTotal > 0) {
      const entries: LedgerPostingEntry[] = [
        {
          accountId: "sys-usdt-referral-expense",
          direction: "DEBIT",
          amount: String(referralTotal),
          memo: "Referral rewards generated by confirmed deposit",
        },
      ];
      if (level1.reward > 0 && level1.profitAccountId && directReferrer) {
        entries.push({
          accountId: level1.profitAccountId,
          direction: "CREDIT",
          amount: String(level1.reward),
          userId: directReferrer.id,
          memo: "Level 1 referral reward payable",
        });
      }
      if (level2.reward > 0 && level2.profitAccountId && secondReferrer) {
        entries.push({
          accountId: level2.profitAccountId,
          direction: "CREDIT",
          amount: String(level2.reward),
          userId: secondReferrer.id,
          memo: "Level 2 referral reward payable",
        });
      }
      referralJournalId = await postLedgerJournal(client, {
        idempotencyKey: `ledger:deposit-referral:${blockchainDepositId}`,
        referenceType: "BlockchainDeposit",
        referenceId: blockchainDepositId,
        description: "Post referral rewards for confirmed blockchain deposit",
        metadata: { level1Rate, level2Rate },
        entries,
      });
    }

    const vipAfter = await syncVipLevel(chainDeposit.user_id, client);
    const wheelGrant =
      directReferrer?.is_active
        ? await grantFirstVipReferralSpins(client, {
            inviterId: directReferrer.id,
            inviteeId: chainDeposit.user_id,
            blockchainDepositId,
            sourceDepositId: businessDepositId,
            vipLevelBefore: vipBefore,
            vipLevelAfter: vipAfter,
          })
        : { spins: 0, grantId: null };
    const wheelSpinsGranted = wheelGrant.spins;

    if (wheelSpinsGranted > 0 && directReferrer) {
      await createNotification(client, {
        userId: directReferrer.id,
        type: "REFERRAL_FIRST_VIP_WHEEL_SPIN",
        title: "فرصت جدید گردونه",
        body: `${wheelSpinsGranted} فرصت گردونه به‌دلیل فعال‌شدن اولین VIP زیرمجموعه مستقیم شما اضافه شد. این پاداش برای هر زیرمجموعه فقط یک‌بار داده می‌شود.`,
        metadata: {
          blockchainDepositId,
          inviteeId: chainDeposit.user_id,
          vipLevelBefore: vipBefore,
          vipLevelAfter: vipAfter,
          wheelSpinsGranted,
          wheelGrantId: wheelGrant.grantId,
        },
      });
    }

    await createNotification(client, {
      userId: chainDeposit.user_id,
      type: "BLOCKCHAIN_DEPOSIT_CREDITED",
      title: "واریز با موفقیت تأیید شد",
      body: `${amount} USDT به سرمایه قفل‌شده شما اضافه شد. زمان آزادسازی این واریز: ${unlockAt.toISOString()}`,
      metadata: {
        blockchainDepositId,
        depositId: businessDepositId,
        amount,
        lockDays,
        unlockAt,
        vipLevelBefore: vipBefore,
        vipLevelAfter: vipAfter,
        txHash: chainDeposit.tx_hash,
      },
    });

    await client.query(
      `INSERT INTO deposit_credit_settlements(
         id, blockchain_deposit_id, deposit_id, lock_position_id, user_id,
         amount, lock_days_snapshot, unlock_at,
         vip_level_before, vip_level_after,
         level1_referral_reward, level2_referral_reward,
         wheel_spins_granted, wheel_grant_id,
         principal_journal_id, referral_journal_id, metadata
       ) VALUES(
         $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17::jsonb
       )`,
      [
        settlementId,
        blockchainDepositId,
        businessDepositId,
        lockPositionId,
        chainDeposit.user_id,
        amount,
        lockDays,
        unlockAt,
        vipBefore,
        vipAfter,
        level1.reward,
        level2.reward,
        wheelSpinsGranted,
        wheelGrant.grantId,
        principalJournalId,
        referralJournalId,
        JSON.stringify({
          fundingMode: settings.funding_mode,
          minimumDeposit: minimum,
          level1Rate,
          level2Rate,
        }),
      ],
    );

    if (wheelGrant.grantId) {
      await client.query(
        `UPDATE referral_wheel_grants
         SET deposit_credit_settlement_id = $1
         WHERE id = $2`,
        [settlementId, wheelGrant.grantId],
      );
    }

    await client.query(
      `UPDATE blockchain_deposits
       SET deposit_id = $1,
           status = 'CREDITED',
           credited_at = now(),
           credited_amount = $2,
           lock_days_snapshot = $3,
           level1_referral_rate_snapshot = $4,
           level2_referral_rate_snapshot = $5,
           vip_level_before = $6,
           vip_level_after = $7,
           credit_journal_id = $8,
           credit_failure_reason = NULL,
           failure_reason = NULL,
           updated_at = now()
       WHERE id = $9`,
      [
        businessDepositId,
        amount,
        lockDays,
        level1Rate,
        level2Rate,
        vipBefore,
        vipAfter,
        principalJournalId,
        blockchainDepositId,
      ],
    );

    return {
      blockchainDepositId,
      status: "credited",
      depositId: businessDepositId,
      amount,
      vipLevelBefore: vipBefore,
      vipLevelAfter: vipAfter,
      unlockAt,
      level1Reward: level1.reward,
      level2Reward: level2.reward,
      wheelSpinsGranted,
    };
  });
}

async function processJob(job: BlockchainJobRow, workerId: string): Promise<CreditResult> {
  const blockchainDepositId = String(job.payload?.blockchainDepositId || "");
  if (!blockchainDepositId) {
    throw new Error("CREDIT_DEPOSIT job payload is missing blockchainDepositId");
  }
  const result = await creditConfirmedBlockchainDeposit(blockchainDepositId);
  await completeBlockchainJob(job.id, workerId, result as unknown as Record<string, unknown>);
  return result;
}

export async function runDepositCreditCycle(instanceId: string) {
  const [controls, appSettingsResult] = await Promise.all([
    getBlockchainControls(),
    query<{ funding_mode: "MANUAL" | "BLOCKCHAIN" }>(
      "SELECT funding_mode FROM app_settings WHERE id = 'default'",
    ),
  ]);
  const fundingMode = appSettingsResult.rows[0]?.funding_mode ?? "MANUAL";
  const enabled =
    blockchainConfig.enabled &&
    blockchainConfig.autoCreditEnabled &&
    controls.depositsEnabled &&
    controls.autoCreditEnabled &&
    fundingMode === "BLOCKCHAIN" &&
    !controls.emergencyStop;

  if (!enabled) {
    const reason = !blockchainConfig.enabled
      ? "Blockchain integration is disabled"
      : !blockchainConfig.autoCreditEnabled
        ? "Automatic credit is disabled in environment"
        : !controls.depositsEnabled
          ? "Deposits are disabled in database controls"
          : !controls.autoCreditEnabled
            ? "Automatic credit is disabled in database controls"
            : fundingMode !== "BLOCKCHAIN"
              ? "Application funding mode is MANUAL"
              : controls.emergencyReason || "Blockchain emergency stop is active";
    await upsertWorkerStatus({
      instanceId,
      status: "PAUSED",
      cycleCompleted: true,
      error: null,
      metadata: { pauseReason: reason },
    });
    return { status: "paused" as const, reason, enqueued: 0, processed: 0, credited: 0, ignored: 0, failed: 0 };
  }

  await upsertWorkerStatus({
    instanceId,
    status: "IDLE",
    cycleStarted: true,
    error: null,
  });

  const enqueued = await enqueueConfirmedDepositCreditJobs(
    blockchainConfig.creditBatchSize * 5,
  );
  const jobs = await claimBlockchainJobs({
    workerId: instanceId,
    types: ["CREDIT_DEPOSIT"],
    limit: blockchainConfig.creditBatchSize,
    leaseSeconds: blockchainConfig.creditJobLeaseSeconds,
  });

  let credited = 0;
  let ignored = 0;
  let failed = 0;
  for (const job of jobs) {
    try {
      const result = await processJob(job, instanceId);
      if (result.status === "credited" || result.status === "already_credited") credited += 1;
      if (result.status === "ignored") ignored += 1;
    } catch (error) {
      failed += 1;
      await failBlockchainJob({
        jobId: job.id,
        workerId: instanceId,
        error: shortError(error),
        retryDelaySeconds: Math.min(300, 15 * Math.max(1, job.attempts)),
      });
      const depositId = String(job.payload?.blockchainDepositId || "");
      if (depositId) {
        await query(
          `UPDATE blockchain_deposits
           SET credit_failure_reason = $1, updated_at = now()
           WHERE id = $2 AND status = 'CONFIRMED'`,
          [shortError(error), depositId],
        );
      }
    }
  }

  await upsertWorkerStatus({
    instanceId,
    status: failed > 0 ? "ERROR" : "HEALTHY",
    processedDelta: jobs.length,
    creditedDelta: credited,
    ignoredDelta: ignored,
    failedDelta: failed,
    error: failed > 0 ? `${failed} credit job(s) failed in the latest cycle` : null,
    cycleCompleted: true,
    metadata: { enqueued, processed: jobs.length, credited, ignored, failed },
  });

  return {
    status: failed > 0 ? ("partial" as const) : ("healthy" as const),
    enqueued,
    processed: jobs.length,
    credited,
    ignored,
    failed,
  };
}

export async function getDepositCreditStatus() {
  const [controls, appSettings, worker, deposits, jobs, settlements] = await Promise.all([
    getBlockchainControls(),
    query<{ funding_mode: "MANUAL" | "BLOCKCHAIN" }>(
      "SELECT funding_mode FROM app_settings WHERE id = 'default'",
    ),
    query(
      `SELECT worker_name, instance_id, status, heartbeat_at,
              last_cycle_started_at, last_cycle_completed_at,
              last_error, metadata, updated_at
       FROM blockchain_worker_status
       WHERE worker_name = $1`,
      [WORKER_NAME],
    ),
    query(
      `SELECT status, COUNT(*)::int AS count
       FROM blockchain_deposits
       WHERE chain_id = $1 AND lower(token_contract) = lower($2)
       GROUP BY status`,
      [blockchainConfig.network.chainId, blockchainConfig.tokenAddress],
    ),
    query(
      `SELECT status, COUNT(*)::int AS count
       FROM blockchain_jobs
       WHERE job_type = 'CREDIT_DEPOSIT'
       GROUP BY status`,
    ),
    query(
      `SELECT COUNT(*)::int AS count,
              COALESCE(SUM(amount),0) AS amount,
              COALESCE(SUM(level1_referral_reward + level2_referral_reward),0) AS referral_rewards
       FROM deposit_credit_settlements`,
    ),
  ]);

  return {
    environmentEnabled: blockchainConfig.autoCreditEnabled,
    databaseEnabled: controls.autoCreditEnabled,
    fundingMode: appSettings.rows[0]?.funding_mode ?? "MANUAL",
    emergencyStop: controls.emergencyStop,
    worker: worker.rows[0] ?? null,
    depositCounts: Object.fromEntries(
      deposits.rows.map((row) => [row.status, Number(row.count)]),
    ),
    jobCounts: Object.fromEntries(
      jobs.rows.map((row) => [row.status, Number(row.count)]),
    ),
    settlements: {
      count: Number(settlements.rows[0]?.count ?? 0),
      amount: Number(settlements.rows[0]?.amount ?? 0),
      referralRewards: Number(settlements.rows[0]?.referral_rewards ?? 0),
    },
    checkedAt: new Date().toISOString(),
  };
}

export const depositCreditInternals = {
  businessAmount,
  creditJobKey,
  percentageReward,
};
