import {
  Contract,
  Interface,
  formatEther,
  formatUnits,
  getAddress,
  keccak256,
  parseEther,
  parseUnits,
  ZeroAddress,
} from "ethers";
import { PoolClient } from "pg";
import { blockchainConfig } from "../config/blockchain";
import { query, withTransaction } from "../config/database";
import { BlockchainJobRow } from "../db/blockchain.types";
import {
  claimBlockchainJobs,
  completeBlockchainJob,
  failBlockchainJob,
  getBlockchainControls,
  recoverExpiredBlockchainJobs,
} from "./blockchain-database.service";
import { getBlockchainProvider } from "./blockchain.service";
import {
  clearSweepSignerCache,
  getDepositWalletSigner,
  getGasWalletSigner,
} from "./sweep-signer.service";
import { randomId } from "../utils/helpers";

const ERC20_INTERFACE = new Interface([
  "function transfer(address to, uint256 amount) returns (bool)",
]);
const ERC20_ABI = [
  "function balanceOf(address account) view returns (uint256)",
] as const;
type Erc20BalanceContract = Contract & {
  balanceOf(account: string): Promise<bigint>;
};
const SWEEP_WORKER_NAME = "sweep-worker";
const ACTIVE_SWEEP_STATUSES = [
  "QUEUED",
  "DISCOVERED",
  "GAS_REQUIRED",
  "GAS_SIGNING",
  "GAS_SENT",
  "GAS_CONFIRMING",
  "TOKEN_SIGNING",
  "BROADCASTED",
  "CONFIRMING",
] as const;

interface SweepRow {
  id: string;
  wallet_id: string;
  user_id: string;
  chain_id: string | number;
  token_contract: string;
  from_address: string;
  treasury_address: string;
  amount_raw: string;
  amount: string;
  gas_funding_amount_raw: string | null;
  gas_funding_tx_hash: string | null;
  gas_funding_nonce: string | number | null;
  gas_funding_raw_transaction: string | null;
  gas_funding_block_number: string | number | null;
  gas_funding_confirmations: number;
  sweep_tx_hash: string | null;
  sweep_raw_transaction: string | null;
  sweep_block_number: string | number | null;
  sweep_confirmations: number;
  nonce: string | number | null;
  status: string;
  attempts: number;
  max_attempts: number;
  derivation_index: string | number;
  derivation_path: string;
  wallet_status: string;
}

interface SweepPolicyInput {
  enabled: boolean;
  minAmount: number;
  maxConcurrent: number;
}

export class RetryableSweepError extends Error {
  constructor(message: string, public readonly delaySeconds = 20) {
    super(message);
    this.name = "RetryableSweepError";
  }
}

function safeError(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error);
  const sanitized = blockchainConfig.rpcUrl
    ? message.replace(blockchainConfig.rpcUrl, "[RPC]")
    : message;
  return sanitized.slice(0, 1000);
}

function knownTransactionError(error: unknown): boolean {
  const message = safeError(error).toLowerCase();
  return (
    message.includes("already known") ||
    message.includes("known transaction") ||
    message.includes("nonce too low") ||
    message.includes("replacement transaction underpriced")
  );
}

export function shouldCreateSweep(
  tokenBalanceRaw: bigint,
  minimumRaw: bigint,
  activeSweepCount: number,
  maxConcurrent: number,
): boolean {
  return (
    tokenBalanceRaw >= minimumRaw &&
    minimumRaw > 0n &&
    activeSweepCount < maxConcurrent
  );
}

export function calculateGasTopUp(
  currentNativeBalance: bigint,
  estimatedFee: bigint,
  configuredTarget: bigint,
): bigint {
  const feeWithBuffer = (estimatedFee * 130n + 99n) / 100n;
  const target = configuredTarget > feeWithBuffer ? configuredTarget : feeWithBuffer;
  return currentNativeBalance >= target ? 0n : target - currentNativeBalance;
}

export function fundGasJobKey(sweepId: string): string {
  return `fund-gas:${sweepId}`;
}

export function sweepTokenJobKey(sweepId: string): string {
  return `sweep-token:${sweepId}`;
}

function confirmations(currentBlock: number, minedBlock: number | null): number {
  if (minedBlock == null || minedBlock > currentBlock) return 0;
  return currentBlock - minedBlock + 1;
}

function assertSweeperAllowed(
  controls: Awaited<ReturnType<typeof getBlockchainControls>>,
): void {
  if (!blockchainConfig.enabled || !blockchainConfig.configured) {
    throw new Error("Blockchain connection is not configured");
  }
  if (!blockchainConfig.sweepWorkerEnabled) {
    throw new Error("Sweep worker is disabled in environment");
  }
  if (!controls.sweepsEnabled || !controls.sweepWorkerEnabled) {
    throw new Error("Wallet sweeping is disabled in PostgreSQL");
  }
  if (controls.emergencyStop) {
    throw new Error(
      `Blockchain emergency stop is active: ${controls.emergencyReason || "no reason"}`,
    );
  }
  if (blockchainConfig.network.name !== "testnet") {
    throw new Error("Stage 8 refuses Mainnet sweep execution");
  }
  if (!blockchainConfig.tokenAddress) {
    throw new Error("Token contract is not configured");
  }
  if (!blockchainConfig.gasWalletAddress) {
    throw new Error("Gas wallet address is not configured");
  }
  if (!blockchainConfig.treasuryWalletAddress) {
    throw new Error("Treasury wallet address is not configured");
  }
  if (
    getAddress(blockchainConfig.treasuryWalletAddress) === getAddress(ZeroAddress)
  ) {
    throw new Error("Treasury wallet cannot be the zero address");
  }
}

async function upsertSweepWorkerStatus(input: {
  instanceId: string;
  status: "STARTING" | "IDLE" | "HEALTHY" | "PAUSED" | "ERROR";
  cycleStarted?: boolean;
  cycleCompleted?: boolean;
  discovered?: number;
  completed?: number;
  failed?: number;
  error?: string | null;
  metadata?: Record<string, unknown>;
}): Promise<void> {
  await query(
    `INSERT INTO blockchain_worker_status(
       worker_name, instance_id, status, chain_id, token_contract,
       detected_events, confirmed_events, orphaned_events,
       last_cycle_started_at, last_cycle_completed_at,
       heartbeat_at, last_error, metadata
     ) VALUES(
       $1,$2,$3,$4,$5,$6,$7,$8,
       CASE WHEN $9 THEN now() ELSE NULL END,
       CASE WHEN $10 THEN now() ELSE NULL END,
       now(),$11,$12::jsonb
     )
     ON CONFLICT(worker_name) DO UPDATE SET
       instance_id = EXCLUDED.instance_id,
       status = EXCLUDED.status,
       chain_id = EXCLUDED.chain_id,
       token_contract = EXCLUDED.token_contract,
       detected_events = blockchain_worker_status.detected_events + $6,
       confirmed_events = blockchain_worker_status.confirmed_events + $7,
       orphaned_events = blockchain_worker_status.orphaned_events + $8,
       last_cycle_started_at = CASE
         WHEN $9 THEN now() ELSE blockchain_worker_status.last_cycle_started_at
       END,
       last_cycle_completed_at = CASE
         WHEN $10 THEN now() ELSE blockchain_worker_status.last_cycle_completed_at
       END,
       heartbeat_at = now(),
       last_error = $11,
       metadata = blockchain_worker_status.metadata || EXCLUDED.metadata,
       updated_at = now()`,
    [
      SWEEP_WORKER_NAME,
      input.instanceId,
      input.status,
      blockchainConfig.network.chainId,
      blockchainConfig.tokenAddress ?? null,
      input.discovered ?? 0,
      input.completed ?? 0,
      input.failed ?? 0,
      Boolean(input.cycleStarted),
      Boolean(input.cycleCompleted),
      input.error ?? null,
      JSON.stringify({
        lastDiscovered: input.discovered ?? 0,
        lastCompleted: input.completed ?? 0,
        lastFailed: input.failed ?? 0,
        ...(input.metadata ?? {}),
      }),
    ],
  );
}

async function loadSweep(
  client: PoolClient,
  sweepId: string,
  forUpdate = false,
): Promise<SweepRow | null> {
  const result = await client.query<SweepRow>(
    `SELECT s.*, w.derivation_index, w.derivation_path,
            w.status AS wallet_status
     FROM wallet_sweeps s
     JOIN blockchain_wallets w ON w.id = s.wallet_id
     WHERE s.id = $1
     ${forUpdate ? "FOR UPDATE OF s, w" : ""}`,
    [sweepId],
  );
  return result.rows[0] ?? null;
}

async function insertJob(
  client: PoolClient,
  type: "FUND_GAS" | "SWEEP_TOKEN",
  key: string,
  sweepId: string,
  runAfter = new Date(),
): Promise<void> {
  await client.query(
    `INSERT INTO blockchain_jobs(
       id, job_type, idempotency_key, payload, priority, max_attempts, run_after
     ) VALUES($1,$2,$3,$4::jsonb,60,30,$5)
     ON CONFLICT(idempotency_key) DO UPDATE SET
       status = CASE
         WHEN blockchain_jobs.status IN ('FAILED','CANCELLED','COMPLETED') THEN 'RETRY'
         ELSE blockchain_jobs.status
       END,
       run_after = LEAST(blockchain_jobs.run_after, EXCLUDED.run_after),
       last_error = CASE
         WHEN blockchain_jobs.status IN ('FAILED','CANCELLED','COMPLETED') THEN NULL
         ELSE blockchain_jobs.last_error
       END,
       completed_at = CASE
         WHEN blockchain_jobs.status IN ('FAILED','CANCELLED','COMPLETED') THEN NULL
         ELSE blockchain_jobs.completed_at
       END,
       updated_at = now()`,
    [randomId(), type, key, JSON.stringify({ sweepId }), runAfter],
  );
}

async function ensureInfrastructureWalletRecords(): Promise<void> {
  const gas = blockchainConfig.gasWalletAddress;
  const treasury = blockchainConfig.treasuryWalletAddress;
  if (!gas || !treasury) return;
  await query(
    `INSERT INTO blockchain_wallets(
       id, user_id, purpose, chain_id, address, status, metadata
     ) VALUES($1,NULL,'GAS',$2,$3,'ACTIVE',$4::jsonb)
     ON CONFLICT DO NOTHING`,
    [
      `gas-${blockchainConfig.network.chainId}`,
      blockchainConfig.network.chainId,
      gas,
      JSON.stringify({ stage: 8 }),
    ],
  );
  await query(
    `UPDATE blockchain_wallets
     SET purpose='GAS', status='ACTIVE', metadata=metadata || $1::jsonb,
         updated_at=now()
     WHERE chain_id=$2 AND lower(address)=lower($3)`,
    [JSON.stringify({ stage: 8 }), blockchainConfig.network.chainId, gas],
  );
  await query(
    `INSERT INTO blockchain_wallets(
       id, user_id, purpose, chain_id, address, status, metadata
     ) VALUES($1,NULL,'TREASURY',$2,$3,'ACTIVE',$4::jsonb)
     ON CONFLICT DO NOTHING`,
    [
      `treasury-${blockchainConfig.network.chainId}`,
      blockchainConfig.network.chainId,
      treasury,
      JSON.stringify({ stage: 8 }),
    ],
  );
  await query(
    `UPDATE blockchain_wallets
     SET purpose='TREASURY', status='ACTIVE', metadata=metadata || $1::jsonb,
         updated_at=now()
     WHERE chain_id=$2 AND lower(address)=lower($3)`,
    [JSON.stringify({ stage: 8 }), blockchainConfig.network.chainId, treasury],
  );
}

async function discoverSweeps(
  controls: Awaited<ReturnType<typeof getBlockchainControls>>,
): Promise<number> {
  assertSweeperAllowed(controls);
  const activeResult = await query<{ count: number }>(
    `SELECT count(*)::int AS count
     FROM wallet_sweeps
     WHERE status = ANY($1::text[])`,
    [ACTIVE_SWEEP_STATUSES],
  );
  let activeCount = Number(activeResult.rows[0]?.count ?? 0);
  if (activeCount >= controls.sweepMaxConcurrent) return 0;

  const wallets = await query<{
    id: string;
    user_id: string;
    address: string;
    derivation_index: string | number;
  }>(
    `SELECT w.id, w.user_id, w.address, w.derivation_index
     FROM blockchain_wallets w
     WHERE w.purpose = 'DEPOSIT'
       AND w.chain_id = $1
       AND w.status = 'ACTIVE'
       AND NOT EXISTS (
         SELECT 1 FROM wallet_sweeps s
         WHERE s.wallet_id = w.id
           AND s.status = ANY($2::text[])
       )
     ORDER BY w.derivation_index ASC
     LIMIT $3`,
    [
      controls.chainId,
      ACTIVE_SWEEP_STATUSES,
      controls.sweepDiscoveryBatchSize,
    ],
  );

  const provider = getBlockchainProvider();
  const token = new Contract(controls.tokenContract!, ERC20_ABI, provider) as Erc20BalanceContract;
  const minimumRaw = parseUnits(
    String(controls.sweepMinAmount),
    controls.tokenDecimals,
  );
  let created = 0;

  for (const wallet of wallets.rows) {
    if (activeCount >= controls.sweepMaxConcurrent) break;
    const address = getAddress(wallet.address);
    const balance = (await token.balanceOf(address)) as bigint;
    if (!shouldCreateSweep(balance, minimumRaw, activeCount, controls.sweepMaxConcurrent)) {
      continue;
    }

    try {
      await withTransaction(async (client) => {
        const sweepId = randomId();
        await client.query(
          `INSERT INTO wallet_sweeps(
             id, wallet_id, user_id, chain_id, token_contract,
             from_address, treasury_address, amount_raw, amount,
             token_balance_at_detection_raw, status, idempotency_key, metadata
           ) VALUES(
             $1,$2,$3,$4,$5,$6,$7,$8,$9,$8,'DISCOVERED',$10,$11::jsonb
           )`,
          [
            sweepId,
            wallet.id,
            wallet.user_id,
            controls.chainId,
            controls.tokenContract,
            address,
            blockchainConfig.treasuryWalletAddress,
            balance.toString(),
            formatUnits(balance, controls.tokenDecimals),
            `sweep:${controls.chainId}:${wallet.id}:${sweepId}`,
            JSON.stringify({
              discoveredBy: SWEEP_WORKER_NAME,
              derivationIndex: Number(wallet.derivation_index),
            }),
          ],
        );
        await insertJob(client, "FUND_GAS", fundGasJobKey(sweepId), sweepId);
      });
      created += 1;
      activeCount += 1;
    } catch (error) {
      const code = (error as { code?: string }).code;
      if (code !== "23505") throw error;
    }
  }
  return created;
}

async function rebroadcast(rawTransaction: string): Promise<void> {
  try {
    await getBlockchainProvider().broadcastTransaction(rawTransaction);
  } catch (error) {
    if (!knownTransactionError(error)) throw error;
  }
}

async function processExistingGasFunding(
  row: SweepRow,
  controls: Awaited<ReturnType<typeof getBlockchainControls>>,
): Promise<{ completed: boolean; state: string }> {
  if (!row.gas_funding_tx_hash || !row.gas_funding_raw_transaction) {
    return { completed: false, state: "MISSING" };
  }
  const provider = getBlockchainProvider();
  const receipt = await provider.getTransactionReceipt(row.gas_funding_tx_hash);
  if (!receipt) {
    await rebroadcast(row.gas_funding_raw_transaction);
    throw new RetryableSweepError("Gas funding transaction is still pending", 15);
  }
  if (receipt.status !== 1) {
    await query(
      `UPDATE wallet_sweeps
       SET status='REVIEW_REQUIRED', failure_reason='Gas funding transaction reverted',
           gas_funding_block_number=$1, gas_funding_block_hash=$2,
           updated_at=now()
       WHERE id=$3`,
      [receipt.blockNumber, receipt.blockHash, row.id],
    );
    return { completed: true, state: "REVERTED" };
  }
  const currentBlock = await provider.getBlockNumber();
  const count = confirmations(currentBlock, receipt.blockNumber);
  await query(
    `UPDATE wallet_sweeps
     SET status = CASE WHEN $1 >= $2 THEN 'TOKEN_SIGNING' ELSE 'GAS_CONFIRMING' END,
         gas_funding_block_number=$3, gas_funding_block_hash=$4,
         gas_funding_confirmations=$1,
         gas_confirmed_at=CASE WHEN $1 >= $2 THEN COALESCE(gas_confirmed_at,now()) ELSE gas_confirmed_at END,
         updated_at=now()
     WHERE id=$5`,
    [count, controls.requiredConfirmations, receipt.blockNumber, receipt.blockHash, row.id],
  );
  if (count < controls.requiredConfirmations) {
    throw new RetryableSweepError(
      `Gas funding has ${count}/${controls.requiredConfirmations} confirmations`,
      15,
    );
  }
  await withTransaction(async (client) => {
    await insertJob(client, "SWEEP_TOKEN", sweepTokenJobKey(row.id), row.id);
  });
  return { completed: true, state: "CONFIRMED" };
}

async function fundGas(sweepId: string): Promise<Record<string, unknown>> {
  const controls = await getBlockchainControls();
  assertSweeperAllowed(controls);
  const provider = getBlockchainProvider();
  const network = await provider.getNetwork();
  if (Number(network.chainId) !== controls.chainId) {
    throw new Error("RPC chain id does not match PostgreSQL settings");
  }

  const current = await withTransaction(async (client) => {
    const row = await loadSweep(client, sweepId, true);
    if (!row) throw new Error("Sweep record was not found");
    if (["COMPLETED", "CANCELLED", "REVIEW_REQUIRED"].includes(row.status)) {
      return row;
    }
    if (row.wallet_status !== "ACTIVE") {
      await client.query(
        `UPDATE wallet_sweeps SET status='REVIEW_REQUIRED',
         failure_reason='Deposit wallet is not active', updated_at=now() WHERE id=$1`,
        [row.id],
      );
      return { ...row, status: "REVIEW_REQUIRED" };
    }
    return row;
  });
  if (["COMPLETED", "CANCELLED", "REVIEW_REQUIRED"].includes(current.status)) {
    return { sweepId, status: current.status };
  }
  if (current.gas_funding_tx_hash && current.gas_funding_raw_transaction) {
    const state = await processExistingGasFunding(current, controls);
    return { sweepId, gasFunding: state.state };
  }

  const token = new Contract(current.token_contract, ERC20_ABI, provider) as Erc20BalanceContract;
  const tokenBalance = (await token.balanceOf(current.from_address)) as bigint;
  const minimumRaw = parseUnits(String(controls.sweepMinAmount), controls.tokenDecimals);
  if (tokenBalance < minimumRaw) {
    await query(
      `UPDATE wallet_sweeps
       SET status='CANCELLED', failure_reason='Token balance fell below sweep minimum',
           amount_raw=$1, amount=$2, updated_at=now()
       WHERE id=$3`,
      [tokenBalance.toString(), formatUnits(tokenBalance, controls.tokenDecimals), sweepId],
    );
    return { sweepId, status: "CANCELLED" };
  }

  const feeData = await provider.getFeeData();
  const gasPrice = feeData.gasPrice;
  if (!gasPrice || gasPrice <= 0n) {
    throw new RetryableSweepError("RPC did not return a usable gas price");
  }
  const transferData = ERC20_INTERFACE.encodeFunctionData("transfer", [
    getAddress(current.treasury_address),
    tokenBalance,
  ]);
  const estimatedGas = await provider.estimateGas({
    from: getAddress(current.from_address),
    to: getAddress(current.token_contract),
    data: transferData,
    value: 0n,
  });
  const gasLimit = (estimatedGas * 120n + 99n) / 100n;
  const estimatedFee = gasLimit * gasPrice;
  const nativeBalance = await provider.getBalance(current.from_address);
  const target = parseEther(String(controls.sweepTargetGasBnb));
  const topUp = calculateGasTopUp(nativeBalance, estimatedFee, target);

  if (topUp === 0n) {
    await withTransaction(async (client) => {
      await client.query(
        `UPDATE wallet_sweeps
         SET status='TOKEN_SIGNING', gas_required_raw=$1,
             amount_raw=$2, amount=$3, updated_at=now()
         WHERE id=$4`,
        [estimatedFee.toString(), tokenBalance.toString(), formatUnits(tokenBalance, controls.tokenDecimals), sweepId],
      );
      await insertJob(client, "SWEEP_TOKEN", sweepTokenJobKey(sweepId), sweepId);
    });
    return { sweepId, gasFunding: "NOT_REQUIRED" };
  }

  const gasSigner = getGasWalletSigner(provider);
  const gasAddress = getAddress(gasSigner.address);
  if (gasAddress !== getAddress(blockchainConfig.gasWalletAddress!)) {
    throw new Error("Gas wallet signer mismatch");
  }

  const prepared = await withTransaction(async (client) => {
    await client.query("SELECT pg_advisory_xact_lock(hashtext($1))", [
      `${controls.chainId}:gas:${gasAddress.toLowerCase()}`,
    ]);
    const [pendingNonce, gasWalletBalance] = await Promise.all([
      provider.getTransactionCount(gasAddress, "pending"),
      provider.getBalance(gasAddress),
    ]);
    const dbNonceResult = await client.query<{ max_nonce: string | null }>(
      `SELECT max(gas_funding_nonce)::text AS max_nonce
       FROM wallet_sweeps
       WHERE chain_id=$1 AND gas_funding_nonce IS NOT NULL
         AND status <> 'CANCELLED'`,
      [controls.chainId],
    );
    const dbNext = dbNonceResult.rows[0]?.max_nonce == null
      ? 0
      : Number(dbNonceResult.rows[0].max_nonce) + 1;
    const nonce = Math.max(pendingNonce, dbNext);
    const fundingGasLimit = 21_000n;
    const fundingFee = fundingGasLimit * gasPrice;
    const pendingFundingResult = await client.query<{
      pending_value_raw: string;
      pending_count: string | number;
    }>(
      `SELECT COALESCE(sum(gas_funding_amount_raw),0)::text AS pending_value_raw,
              count(*)::int AS pending_count
       FROM wallet_sweeps
       WHERE chain_id=$1
         AND gas_funding_tx_hash IS NOT NULL
         AND gas_funding_block_number IS NULL
         AND status IN ('GAS_SIGNING','GAS_SENT','GAS_CONFIRMING')`,
      [controls.chainId],
    );
    const pendingValue = BigInt(
      pendingFundingResult.rows[0]?.pending_value_raw ?? "0",
    );
    const pendingCount = BigInt(
      Number(pendingFundingResult.rows[0]?.pending_count ?? 0),
    );
    const pendingFeeReserve = pendingCount * fundingFee;
    const committedPending = pendingValue + pendingFeeReserve;
    const availableAfterPending = gasWalletBalance > committedPending
      ? gasWalletBalance - committedPending
      : 0n;
    const reserve = parseEther(String(controls.sweepGasWalletMinBnbReserve));
    if (availableAfterPending < topUp + fundingFee + reserve) {
      throw new RetryableSweepError(
        `Gas wallet reserve is insufficient. Latest balance ${formatEther(gasWalletBalance)} BNB; pending commitments ${formatEther(committedPending)}; top-up ${formatEther(topUp)}; fee ${formatEther(fundingFee)}; reserve ${controls.sweepGasWalletMinBnbReserve}`,
        120,
      );
    }
    const rawTransaction = await gasSigner.signTransaction({
      chainId: controls.chainId,
      type: 0,
      nonce,
      to: getAddress(current.from_address),
      value: topUp,
      gasLimit: fundingGasLimit,
      gasPrice,
    });
    const txHash = keccak256(rawTransaction);
    await client.query(
      `UPDATE wallet_sweeps
       SET status='GAS_SIGNING', gas_required_raw=$1,
           gas_funding_amount_raw=$2, gas_funding_nonce=$3,
           gas_funding_raw_transaction=$4, gas_funding_tx_hash=$5,
           amount_raw=$6, amount=$7, attempts=attempts+1,
           last_error=NULL, updated_at=now()
       WHERE id=$8`,
      [
        estimatedFee.toString(),
        topUp.toString(),
        nonce,
        rawTransaction,
        txHash,
        tokenBalance.toString(),
        formatUnits(tokenBalance, controls.tokenDecimals),
        sweepId,
      ],
    );
    return { rawTransaction, txHash };
  });
  await rebroadcast(prepared.rawTransaction);
  await query(
    `UPDATE wallet_sweeps
     SET status='GAS_SENT', gas_broadcast_at=COALESCE(gas_broadcast_at,now()), updated_at=now()
     WHERE id=$1`,
    [sweepId],
  );
  throw new RetryableSweepError("Gas funding transaction was broadcast", 15);
}

async function processExistingTokenSweep(
  row: SweepRow,
  controls: Awaited<ReturnType<typeof getBlockchainControls>>,
): Promise<Record<string, unknown>> {
  if (!row.sweep_tx_hash || !row.sweep_raw_transaction) {
    throw new Error("Stored sweep transaction is incomplete");
  }
  const provider = getBlockchainProvider();
  const receipt = await provider.getTransactionReceipt(row.sweep_tx_hash);
  if (!receipt) {
    await rebroadcast(row.sweep_raw_transaction);
    throw new RetryableSweepError("Token sweep transaction is still pending", 15);
  }
  if (receipt.status !== 1) {
    await query(
      `UPDATE wallet_sweeps
       SET status='REVIEW_REQUIRED', failure_reason='Token sweep transaction reverted',
           sweep_block_number=$1, sweep_block_hash=$2, updated_at=now()
       WHERE id=$3`,
      [receipt.blockNumber, receipt.blockHash, row.id],
    );
    return { sweepId: row.id, status: "REVIEW_REQUIRED" };
  }
  const currentBlock = await provider.getBlockNumber();
  const count = confirmations(currentBlock, receipt.blockNumber);
  await query(
    `UPDATE wallet_sweeps
     SET status=CASE WHEN $1 >= $2 THEN 'COMPLETED' ELSE 'CONFIRMING' END,
         sweep_block_number=$3, sweep_block_hash=$4,
         sweep_confirmations=$1,
         sweep_confirmed_at=CASE WHEN $1 >= $2 THEN COALESCE(sweep_confirmed_at,now()) ELSE sweep_confirmed_at END,
         completed_at=CASE WHEN $1 >= $2 THEN COALESCE(completed_at,now()) ELSE completed_at END,
         updated_at=now()
     WHERE id=$5`,
    [count, controls.requiredConfirmations, receipt.blockNumber, receipt.blockHash, row.id],
  );
  if (count < controls.requiredConfirmations) {
    throw new RetryableSweepError(
      `Token sweep has ${count}/${controls.requiredConfirmations} confirmations`,
      15,
    );
  }
  return {
    sweepId: row.id,
    status: "COMPLETED",
    txHash: row.sweep_tx_hash,
    amount: Number(row.amount),
  };
}

async function sweepToken(sweepId: string): Promise<Record<string, unknown>> {
  const controls = await getBlockchainControls();
  assertSweeperAllowed(controls);
  const provider = getBlockchainProvider();
  const row = await withTransaction(async (client) => {
    const loaded = await loadSweep(client, sweepId, true);
    if (!loaded) throw new Error("Sweep record was not found");
    return loaded;
  });
  if (["COMPLETED", "CANCELLED", "REVIEW_REQUIRED"].includes(row.status)) {
    return { sweepId, status: row.status };
  }
  if (row.sweep_tx_hash && row.sweep_raw_transaction) {
    return processExistingTokenSweep(row, controls);
  }

  const token = new Contract(row.token_contract, ERC20_ABI, provider) as Erc20BalanceContract;
  const tokenBalance = (await token.balanceOf(row.from_address)) as bigint;
  const minimumRaw = parseUnits(String(controls.sweepMinAmount), controls.tokenDecimals);
  if (tokenBalance < minimumRaw) {
    await query(
      `UPDATE wallet_sweeps SET status='CANCELLED',
       failure_reason='Token balance fell below sweep minimum before signing',
       amount_raw=$1, amount=$2, updated_at=now() WHERE id=$3`,
      [tokenBalance.toString(), formatUnits(tokenBalance, controls.tokenDecimals), sweepId],
    );
    return { sweepId, status: "CANCELLED" };
  }

  const signer = getDepositWalletSigner(
    provider,
    Number(row.derivation_index),
    row.from_address,
  );
  const sender = getAddress(signer.address);
  await withTransaction(async (client) => {
    await client.query("SELECT pg_advisory_xact_lock(hashtext($1))", [
      `${controls.chainId}:deposit:${sender.toLowerCase()}`,
    ]);
  });

  const feeData = await provider.getFeeData();
  const gasPrice = feeData.gasPrice;
  if (!gasPrice || gasPrice <= 0n) {
    throw new RetryableSweepError("RPC did not return a usable gas price");
  }
  const data = ERC20_INTERFACE.encodeFunctionData("transfer", [
    getAddress(row.treasury_address),
    tokenBalance,
  ]);
  const estimatedGas = await provider.estimateGas({
    from: sender,
    to: getAddress(row.token_contract),
    data,
    value: 0n,
  });
  const gasLimit = (estimatedGas * 120n + 99n) / 100n;
  const requiredNative = gasLimit * gasPrice;
  const nativeBalance = await provider.getBalance(sender);
  if (nativeBalance < requiredNative) {
    await withTransaction(async (client) => {
      await client.query(
        `UPDATE wallet_sweeps SET status='GAS_REQUIRED', gas_required_raw=$1,
         last_error='Deposit wallet needs more BNB before token sweep', updated_at=now()
         WHERE id=$2`,
        [requiredNative.toString(), sweepId],
      );
      await insertJob(client, "FUND_GAS", fundGasJobKey(sweepId), sweepId);
    });
    return { sweepId, status: "GAS_REQUIRED" };
  }

  const nonce = await provider.getTransactionCount(sender, "pending");
  const rawTransaction = await signer.signTransaction({
    chainId: controls.chainId,
    type: 0,
    nonce,
    to: getAddress(row.token_contract),
    data,
    value: 0n,
    gasLimit,
    gasPrice,
  });
  const txHash = keccak256(rawTransaction);
  await query(
    `UPDATE wallet_sweeps
     SET status='TOKEN_SIGNING', nonce=$1, sweep_raw_transaction=$2,
         sweep_tx_hash=$3, amount_raw=$4, amount=$5,
         attempts=attempts+1, last_error=NULL, updated_at=now()
     WHERE id=$6`,
    [nonce, rawTransaction, txHash, tokenBalance.toString(), formatUnits(tokenBalance, controls.tokenDecimals), sweepId],
  );
  await rebroadcast(rawTransaction);
  await query(
    `UPDATE wallet_sweeps SET status='BROADCASTED',
     sweep_broadcast_at=COALESCE(sweep_broadcast_at,now()), updated_at=now()
     WHERE id=$1`,
    [sweepId],
  );
  throw new RetryableSweepError("Token sweep transaction was broadcast", 15);
}

async function processSweepJob(
  job: BlockchainJobRow,
  workerId: string,
): Promise<{ completed: boolean; failed: boolean }> {
  const sweepId = String(job.payload.sweepId || "");
  if (!sweepId) {
    await failBlockchainJob({
      jobId: job.id,
      workerId,
      error: "Sweep job payload is missing sweepId",
      retryDelaySeconds: 300,
    });
    return { completed: false, failed: true };
  }
  try {
    const result = job.job_type === "FUND_GAS"
      ? await fundGas(sweepId)
      : await sweepToken(sweepId);
    await completeBlockchainJob(job.id, workerId, result);
    return { completed: result.status === "COMPLETED", failed: false };
  } catch (error) {
    const delay = error instanceof RetryableSweepError ? error.delaySeconds : 60;
    await query(
      `UPDATE wallet_sweeps
       SET last_error=$1,
           status=CASE
             WHEN $4 AND status NOT IN ('COMPLETED','CANCELLED','REVIEW_REQUIRED') THEN 'FAILED'
             ELSE status
           END,
           failure_reason=CASE WHEN $4 THEN COALESCE(failure_reason,$1) ELSE failure_reason END,
           next_attempt_at=now()+($2 || ' seconds')::interval,
           updated_at=now()
       WHERE id=$3`,
      [safeError(error), delay, sweepId, job.attempts >= job.max_attempts],
    );
    await failBlockchainJob({
      jobId: job.id,
      workerId,
      error: safeError(error),
      retryDelaySeconds: delay,
    });
    return { completed: false, failed: !(error instanceof RetryableSweepError) };
  }
}

export async function runSweepWorkerCycle(instanceId: string) {
  const controls = await getBlockchainControls();
  if (
    !blockchainConfig.sweepWorkerEnabled ||
    !controls.sweepsEnabled ||
    !controls.sweepWorkerEnabled ||
    controls.emergencyStop
  ) {
    await upsertSweepWorkerStatus({
      instanceId,
      status: "PAUSED",
      cycleStarted: true,
      cycleCompleted: true,
      metadata: {
        environmentEnabled: blockchainConfig.sweepWorkerEnabled,
        databaseEnabled: controls.sweepsEnabled && controls.sweepWorkerEnabled,
        emergencyStop: controls.emergencyStop,
      },
    });
    return { discovered: 0, processed: 0, completed: 0, failed: 0 };
  }

  assertSweeperAllowed(controls);
  await ensureInfrastructureWalletRecords();
  await recoverExpiredBlockchainJobs();
  await upsertSweepWorkerStatus({
    instanceId,
    status: "STARTING",
    cycleStarted: true,
  });

  const discovered = await discoverSweeps(controls);
  const jobs = await claimBlockchainJobs({
    workerId: instanceId,
    types: ["FUND_GAS", "SWEEP_TOKEN"],
    limit: controls.sweepJobBatchSize,
    leaseSeconds: blockchainConfig.sweepJobLeaseSeconds,
  });
  let completed = 0;
  let failed = 0;
  for (const job of jobs) {
    const result = await processSweepJob(job, instanceId);
    if (result.completed) completed += 1;
    if (result.failed) failed += 1;
  }
  await upsertSweepWorkerStatus({
    instanceId,
    status: jobs.length || discovered ? "HEALTHY" : "IDLE",
    cycleCompleted: true,
    discovered,
    completed,
    failed,
    error: null,
    metadata: { processedJobs: jobs.length },
  });
  return { discovered, processed: jobs.length, completed, failed };
}

export async function recordSweepWorkerError(
  instanceId: string,
  error: unknown,
): Promise<void> {
  await upsertSweepWorkerStatus({
    instanceId,
    status: "ERROR",
    cycleCompleted: true,
    error: safeError(error),
  });
}

export async function getSweeperSettings() {
  const controls = await getBlockchainControls();
  const [statusResult, countsResult, recentResult] = await Promise.all([
    query(
      `SELECT worker_name, instance_id, status, heartbeat_at,
              last_cycle_started_at, last_cycle_completed_at,
              last_error, metadata, updated_at
       FROM blockchain_worker_status WHERE worker_name=$1`,
      [SWEEP_WORKER_NAME],
    ),
    query(
      `SELECT
         count(*) FILTER (WHERE status = ANY($1::text[]))::int AS active,
         count(*) FILTER (WHERE status='COMPLETED')::int AS completed,
         count(*) FILTER (WHERE status='REVIEW_REQUIRED')::int AS review_required,
         count(*) FILTER (WHERE status='FAILED')::int AS failed,
         COALESCE(sum(amount) FILTER (WHERE status='COMPLETED'),0) AS total_swept
       FROM wallet_sweeps`,
      [ACTIVE_SWEEP_STATUSES],
    ),
    query(
      `SELECT s.id, s.user_id, u.email, s.from_address, s.treasury_address,
              s.amount, s.status, s.gas_funding_tx_hash, s.sweep_tx_hash,
              s.gas_funding_confirmations, s.sweep_confirmations,
              s.failure_reason, s.last_error, s.created_at, s.completed_at
       FROM wallet_sweeps s JOIN users u ON u.id=s.user_id
       ORDER BY s.created_at DESC LIMIT 30`,
    ),
  ]);

  let balances: Record<string, unknown> | null = null;
  let balanceError: string | null = null;
  if (
    blockchainConfig.enabled &&
    blockchainConfig.configured &&
    blockchainConfig.gasWalletAddress &&
    blockchainConfig.treasuryWalletAddress &&
    controls.tokenContract
  ) {
    try {
      const provider = getBlockchainProvider();
      const token = new Contract(controls.tokenContract, ERC20_ABI, provider) as Erc20BalanceContract;
      const [gasBnb, gasToken, treasuryToken] = await Promise.all([
        provider.getBalance(blockchainConfig.gasWalletAddress),
        token.balanceOf(blockchainConfig.gasWalletAddress) as Promise<bigint>,
        token.balanceOf(blockchainConfig.treasuryWalletAddress) as Promise<bigint>,
      ]);
      balances = {
        gasWalletAddress: blockchainConfig.gasWalletAddress,
        gasWalletBnb: formatEther(gasBnb),
        gasWalletToken: formatUnits(gasToken, controls.tokenDecimals),
        treasuryAddress: blockchainConfig.treasuryWalletAddress,
        treasuryToken: formatUnits(treasuryToken, controls.tokenDecimals),
        tokenSymbol: controls.tokenSymbol,
      };
    } catch (error) {
      balanceError = safeError(error);
    }
  }

  return {
    enabled: controls.sweepsEnabled && controls.sweepWorkerEnabled,
    environmentEnabled: blockchainConfig.sweepWorkerEnabled,
    network: controls.network,
    chainId: controls.chainId,
    minAmount: controls.sweepMinAmount,
    discoveryBatchSize: controls.sweepDiscoveryBatchSize,
    jobBatchSize: controls.sweepJobBatchSize,
    maxConcurrent: controls.sweepMaxConcurrent,
    targetGasBnb: controls.sweepTargetGasBnb,
    gasWalletMinBnbReserve: controls.sweepGasWalletMinBnbReserve,
    pauseReason: controls.sweepPauseReason,
    pausedAt: controls.sweepPausedAt,
    worker: statusResult.rows[0] ?? null,
    counts: countsResult.rows[0] ?? null,
    balances,
    balanceError,
    recent: recentResult.rows.map((row) => ({
      id: row.id,
      userId: row.user_id,
      email: row.email,
      fromAddress: row.from_address,
      treasuryAddress: row.treasury_address,
      amount: Number(row.amount),
      status: row.status,
      gasFundingTxHash: row.gas_funding_tx_hash,
      sweepTxHash: row.sweep_tx_hash,
      gasFundingConfirmations: Number(row.gas_funding_confirmations),
      sweepConfirmations: Number(row.sweep_confirmations),
      failureReason: row.failure_reason,
      lastError: row.last_error,
      createdAt: row.created_at,
      completedAt: row.completed_at,
      gasExplorerUrl: row.gas_funding_tx_hash
        ? `${blockchainConfig.network.explorerBaseUrl}/tx/${row.gas_funding_tx_hash}`
        : null,
      sweepExplorerUrl: row.sweep_tx_hash
        ? `${blockchainConfig.network.explorerBaseUrl}/tx/${row.sweep_tx_hash}`
        : null,
    })),
  };
}

export async function updateSweeperSettings(
  adminId: string,
  input: {
    enabled: boolean;
    minAmount: number;
    discoveryBatchSize: number;
    jobBatchSize: number;
    maxConcurrent: number;
    targetGasBnb: number;
    gasWalletMinBnbReserve: number;
  },
) {
  return withTransaction(async (client) => {
    const result = await client.query(
      `UPDATE blockchain_settings SET
         sweeps_enabled=$1, sweep_worker_enabled=$1,
         sweep_min_amount=$2, sweep_discovery_batch_size=$3,
         sweep_job_batch_size=$4, sweep_max_concurrent=$5,
         sweep_target_gas_bnb=$6, sweep_gas_wallet_min_bnb_reserve=$7,
         sweep_pause_reason=CASE WHEN $1 THEN NULL ELSE sweep_pause_reason END,
         sweep_paused_at=CASE WHEN $1 THEN NULL ELSE sweep_paused_at END,
         updated_by=$8, updated_at=now()
       WHERE id='default' RETURNING *`,
      [
        input.enabled,
        input.minAmount,
        input.discoveryBatchSize,
        input.jobBatchSize,
        input.maxConcurrent,
        input.targetGasBnb,
        input.gasWalletMinBnbReserve,
        adminId,
      ],
    );
    await client.query(
      `INSERT INTO admin_action_logs(
         id, action, target_type, target_id, metadata, actor_id
       ) VALUES($1,'UPDATE_SWEEP_POLICY','BlockchainSettings','default',$2::jsonb,$3)`,
      [randomId(), JSON.stringify(input), adminId],
    );
    return result.rows[0];
  });
}

export async function pauseSweeper(reason: string, adminId?: string | null) {
  const normalized = reason.trim().slice(0, 1000);
  if (normalized.length < 3) throw new Error("Pause reason is required");
  const result = await query(
    `UPDATE blockchain_settings SET sweeps_enabled=FALSE,
       sweep_worker_enabled=FALSE, sweep_pause_reason=$1,
       sweep_paused_at=now(), updated_by=COALESCE($2,updated_by), updated_at=now()
     WHERE id='default' RETURNING *`,
    [normalized, adminId ?? null],
  );
  return result.rows[0];
}

export const walletSweeperInternals = {
  shouldCreateSweep,
  calculateGasTopUp,
  fundGasJobKey,
  sweepTokenJobKey,
  knownTransactionError,
};

export function clearWalletSweeperSecrets(): void {
  clearSweepSignerCache();
}
