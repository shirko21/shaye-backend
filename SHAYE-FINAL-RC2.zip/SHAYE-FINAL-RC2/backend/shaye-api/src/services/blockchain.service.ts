import { Contract, JsonRpcProvider } from "ethers";
import { blockchainConfig } from "../config/blockchain";
import { BlockchainStatus } from "../types/blockchain.types";

const ERC20_METADATA_ABI = [
  "function name() view returns (string)",
  "function symbol() view returns (string)",
  "function decimals() view returns (uint8)",
] as const;

let provider: JsonRpcProvider | null = null;
let statusCache:
  | {
      expiresAt: number;
      value: BlockchainStatus;
    }
  | undefined;

export function getBlockchainProvider(): JsonRpcProvider {
  if (!blockchainConfig.rpcUrl) {
    throw new Error("BSC_RPC_URL is not configured");
  }

  if (!provider) {
    provider = new JsonRpcProvider(blockchainConfig.rpcUrl);
  }

  return provider;
}

function safeErrorMessage(error: unknown): string {
  if (error instanceof Error) {
    const message = error.message.replace(blockchainConfig.rpcUrl || "", "[RPC]");
    return message.length > 240 ? `${message.slice(0, 237)}...` : message;
  }
  return "Unknown blockchain error";
}

async function withTimeout<T>(promise: Promise<T>, timeoutMs: number): Promise<T> {
  let timer: NodeJS.Timeout | undefined;

  try {
    return await Promise.race([
      promise,
      new Promise<T>((_resolve, reject) => {
        timer = setTimeout(
          () => reject(new Error(`Blockchain request timed out after ${timeoutMs}ms`)),
          timeoutMs,
        );
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

function baseStatus(): BlockchainStatus {
  return {
    enabled: blockchainConfig.enabled,
    configured: blockchainConfig.configured,
    healthy: false,
    status: blockchainConfig.enabled ? "not_configured" : "disabled",
    network: blockchainConfig.network.name,
    expectedChainId: blockchainConfig.network.chainId,
    actualChainId: null,
    chainIdMatch: null,
    latestBlock: null,
    rpcLatencyMs: null,
    token: {
      configured: Boolean(blockchainConfig.tokenAddress),
      address: blockchainConfig.tokenAddress || null,
      contractCodePresent: null,
      name: null,
      symbol: null,
      decimals: null,
      expectedDecimals: blockchainConfig.expectedTokenDecimals ?? null,
      decimalsMatch: null,
    },
    checkedAt: new Date().toISOString(),
    error: null,
  };
}

export async function getBlockchainStatus(options?: {
  forceRefresh?: boolean;
}): Promise<BlockchainStatus> {
  const forceRefresh = Boolean(options?.forceRefresh);
  const now = Date.now();

  if (!forceRefresh && statusCache && statusCache.expiresAt > now) {
    return statusCache.value;
  }

  const status = baseStatus();

  if (!blockchainConfig.enabled) {
    statusCache = {
      value: status,
      expiresAt: now + blockchainConfig.statusCacheMs,
    };
    return status;
  }

  if (!blockchainConfig.configured || !blockchainConfig.tokenAddress) {
    status.error = "Blockchain is enabled but RPC or token contract is missing";
    statusCache = {
      value: status,
      expiresAt: now + blockchainConfig.statusCacheMs,
    };
    return status;
  }

  const startedAt = Date.now();

  try {
    const rpc = getBlockchainProvider();

    const [network, latestBlock, contractCode] = await withTimeout(
      Promise.all([
        rpc.getNetwork(),
        rpc.getBlockNumber(),
        rpc.getCode(blockchainConfig.tokenAddress),
      ]),
      blockchainConfig.requestTimeoutMs,
    );

    const actualChainId = Number(network.chainId);
    const chainIdMatch = actualChainId === blockchainConfig.network.chainId;
    const contractCodePresent = contractCode !== "0x";

    status.actualChainId = actualChainId;
    status.chainIdMatch = chainIdMatch;
    status.latestBlock = latestBlock;
    status.rpcLatencyMs = Date.now() - startedAt;
    status.token.contractCodePresent = contractCodePresent;

    if (!chainIdMatch) {
      throw new Error(
        `Unexpected BSC chain id: expected ${blockchainConfig.network.chainId}, received ${actualChainId}`,
      );
    }

    if (!contractCodePresent) {
      throw new Error("Configured token address does not contain contract code");
    }

    const token = new Contract(
      blockchainConfig.tokenAddress,
      ERC20_METADATA_ABI,
      rpc,
    );

    const metadata = await withTimeout(
      Promise.allSettled([
        token.getFunction("name").staticCall(),
        token.getFunction("symbol").staticCall(),
        token.getFunction("decimals").staticCall(),
      ]),
      blockchainConfig.requestTimeoutMs,
    );

    const [nameResult, symbolResult, decimalsResult] = metadata;

    if (nameResult.status === "fulfilled") {
      status.token.name = String(nameResult.value);
    }

    if (symbolResult.status === "fulfilled") {
      status.token.symbol = String(symbolResult.value);
    }

    if (decimalsResult.status !== "fulfilled") {
      throw new Error("Token decimals() call failed");
    }

    const decimals = Number(decimalsResult.value);
    status.token.decimals = decimals;
    status.token.decimalsMatch =
      blockchainConfig.expectedTokenDecimals === undefined
        ? true
        : decimals === blockchainConfig.expectedTokenDecimals;

    if (!status.token.decimalsMatch) {
      throw new Error(
        `Unexpected token decimals: expected ${blockchainConfig.expectedTokenDecimals}, received ${decimals}`,
      );
    }

    status.healthy = true;
    status.status = "healthy";
  } catch (error) {
    status.healthy = false;
    status.status = "unhealthy";
    status.rpcLatencyMs = Date.now() - startedAt;
    status.error = safeErrorMessage(error);
  }

  status.checkedAt = new Date().toISOString();
  statusCache = {
    value: status,
    expiresAt: Date.now() + blockchainConfig.statusCacheMs,
  };

  return status;
}

export function clearBlockchainStatusCache(): void {
  statusCache = undefined;
}

export async function destroyBlockchainProvider(): Promise<void> {
  if (provider) {
    provider.destroy();
    provider = null;
  }
  clearBlockchainStatusCache();
}
