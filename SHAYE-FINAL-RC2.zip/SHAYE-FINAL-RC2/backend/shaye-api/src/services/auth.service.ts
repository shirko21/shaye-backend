import { query, withTransaction } from "../config/database";
import { PoolClient } from "pg";
import { AppError } from "../utils/response";
import { hashPassword, verifyPassword } from "../utils/bcrypt";
import {
  mapUser,
  normalizeEmail,
  normalizeInviteCode,
  randomCode,
  randomId,
} from "../utils/helpers";
import { signAuthToken } from "../utils/jwt";
import { UserRow } from "../db/types";
import { depositWalletConfig } from "../config/deposit-wallet";
import { ensureUserDepositWallet } from "./deposit-wallet.service";

async function createUniqueInviteCode(client?: PoolClient): Promise<string> {
  for (let attempt = 0; attempt < 30; attempt += 1) {
    const code = randomCode("SH", 5).replace("-", "");
    const existing = client
      ? await client.query("SELECT 1 FROM users WHERE invite_code = $1", [code])
      : await query("SELECT 1 FROM users WHERE invite_code = $1", [code]);
    if (!existing.rowCount) return code;
  }

  throw new AppError(
    500,
    "ساخت کد دعوت انجام نشد.",
    "INVITE_CODE_FAILED",
  );
}

export async function register(input: {
  email: string;
  password: string;
  inviteCode?: string | null;
}) {
  const email = normalizeEmail(input.email);
  const suppliedInviteCode = normalizeInviteCode(input.inviteCode);
  const passwordHash = await hashPassword(input.password);

  try {
    const result = await withTransaction(async (client) => {
      let referrerId: string | null = null;

      if (suppliedInviteCode) {
        const referrerResult = await client.query<{
          id: string;
          is_active: boolean;
        }>(
          "SELECT id, is_active FROM users WHERE invite_code = $1",
          [suppliedInviteCode],
        );
        const referrer = referrerResult.rows[0];

        if (!referrer?.is_active) {
          throw new AppError(
            400,
            "کد دعوت معتبر نیست.",
            "INVALID_INVITE_CODE",
          );
        }
        referrerId = referrer.id;
      }

      const id = randomId();
      const inviteCode = await createUniqueInviteCode(client);

      const wheelResult = await client.query<{ registration_spins: number }>(
        "SELECT registration_spins FROM wheel_settings WHERE id = 'default'",
      );
      const registrationSpins = Number(wheelResult.rows[0]?.registration_spins || 0);
      await client.query(
        `INSERT INTO users(
          id, email, password_hash, invite_code, referred_by_id, wheel_spins
        ) VALUES($1, $2, $3, $4, $5, $6)`,
        [id, email, passwordHash, inviteCode, referrerId, registrationSpins],
      );

      const userResult = await client.query<UserRow>(
        "SELECT * FROM users WHERE id = $1",
        [id],
      );
      const user = mapUser(userResult.rows[0]);

      return {
        user,
        token: signAuthToken({
          userId: user.id,
          email: user.email,
          role: user.role,
        }),
      };
    });

    if (depositWalletConfig.enabled && result.user.role === "USER") {
      try {
        await ensureUserDepositWallet(result.user.id);
      } catch (error) {
        console.error(
          new Date().toISOString(),
          "Deposit wallet assignment after registration failed",
          error instanceof Error ? error.message : error,
        );
      }
    }

    return result;
  } catch (error: any) {
    if (error?.code === "23505") {
      const constraint = String(error.constraint || "");
      if (constraint.includes("email")) {
        throw new AppError(
          409,
          "این ایمیل قبلاً ثبت شده است.",
          "EMAIL_EXISTS",
        );
      }
      throw new AppError(
        409,
        "ثبت‌نام انجام نشد؛ دوباره تلاش کنید.",
        "REGISTER_CONFLICT",
      );
    }
    throw error;
  }
}

export async function login(input: { email: string; password: string }) {
  const result = await query<UserRow>(
    "SELECT * FROM users WHERE email = $1",
    [normalizeEmail(input.email)],
  );
  const storedUser = result.rows[0];

  if (
    !storedUser ||
    !(await verifyPassword(input.password, storedUser.password_hash))
  ) {
    throw new AppError(
      401,
      "ایمیل یا رمز عبور اشتباه است.",
      "INVALID_CREDENTIALS",
    );
  }

  if (!storedUser.is_active) {
    throw new AppError(
      403,
      "حساب شما غیرفعال است.",
      "ACCOUNT_DISABLED",
    );
  }

  await query("UPDATE users SET last_seen_at = now() WHERE id = $1", [storedUser.id]);
  const user = mapUser({ ...storedUser, last_seen_at: new Date() });
  return {
    user,
    token: signAuthToken({
      userId: user.id,
      email: user.email,
      role: user.role,
    }),
  };
}

export async function getCurrentUser(id: string) {
  const result = await query<UserRow>(
    "SELECT * FROM users WHERE id = $1",
    [id],
  );
  const storedUser = result.rows[0];

  if (!storedUser) {
    throw new AppError(404, "کاربر پیدا نشد.", "USER_NOT_FOUND");
  }
  if (!storedUser.is_active) {
    throw new AppError(403, "حساب شما غیرفعال است.", "ACCOUNT_DISABLED");
  }

  return mapUser(storedUser);
}

export async function changePassword(
  id: string,
  currentPassword: string,
  newPassword: string,
) {
  const result = await query<{ password_hash: string }>(
    "SELECT password_hash FROM users WHERE id = $1",
    [id],
  );
  const user = result.rows[0];

  if (
    !user ||
    !(await verifyPassword(currentPassword, user.password_hash))
  ) {
    throw new AppError(
      400,
      "رمز فعلی نادرست است.",
      "INVALID_PASSWORD",
    );
  }

  if (await verifyPassword(newPassword, user.password_hash)) {
    throw new AppError(
      400,
      "رمز جدید نباید با رمز فعلی یکسان باشد.",
      "PASSWORD_UNCHANGED",
    );
  }

  await query(
    "UPDATE users SET password_hash = $1, updated_at = now() WHERE id = $2",
    [await hashPassword(newPassword), id],
  );
}

export async function ensureAdmin(email: string, password: string) {
  const normalizedEmail = normalizeEmail(email);
  const result = await query<UserRow>(
    "SELECT * FROM users WHERE email = $1",
    [normalizedEmail],
  );
  const existing = result.rows[0];

  if (existing) {
    if (existing.role !== "ADMIN" || !existing.is_active) {
      await query(
        `UPDATE users
         SET role = 'ADMIN', is_active = TRUE, updated_at = now()
         WHERE id = $1`,
        [existing.id],
      );
    }
    return;
  }

  try {
    await query(
      `INSERT INTO users(
        id, email, password_hash, invite_code, role
      ) VALUES($1, $2, $3, $4, 'ADMIN')`,
      [
        randomId(),
        normalizedEmail,
        await hashPassword(password),
        await createUniqueInviteCode(),
      ],
    );
  } catch (error: any) {
    if (error?.code !== "23505") throw error;
  }
}
