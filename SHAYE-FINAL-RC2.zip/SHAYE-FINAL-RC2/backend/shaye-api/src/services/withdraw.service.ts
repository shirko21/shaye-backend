import { getAddress, parseUnits, ZeroAddress } from "ethers";
import { query, withTransaction } from "../config/database";
import { blockchainConfig } from "../config/blockchain";
import { AppError } from "../utils/response";
import { getSettings } from "./settings.service";
import { dateKey } from "../utils/date";
import { money, randomId } from "../utils/helpers";
import { verifyPassword } from "../utils/bcrypt";
import { releaseMaturedPositions } from "./wallet.service";
import {
  ensureUserLedgerAccounts,
  getBlockchainControls,
  postLedgerJournal,
} from "./blockchain-database.service";
import {
  enqueueWithdrawalForExecution,
} from "./withdrawal-execution.service";
import { createNotification } from "./notification.service";
import {
  getAutomaticWithdrawalSettings,
  reserveAutomaticWithdrawalBudget,
} from "./automatic-withdrawal.service";

function normalizeDestination(address: string): string {
  let normalized: string;
  try {
    normalized = getAddress(address);
  } catch {
    throw new AppError(
      400,
      "آدرس کیف پول BEP20 معتبر نیست.",
      "INVALID_WALLET_ADDRESS",
    );
  }

  if (normalized === ZeroAddress) {
    throw new AppError(
      400,
      "آدرس صفر برای برداشت مجاز نیست.",
      "ZERO_WALLET_ADDRESS",
    );
  }
  if (
    blockchainConfig.hotWalletAddress &&
    normalized === getAddress(blockchainConfig.hotWalletAddress)
  ) {
    throw new AppError(
      400,
      "آدرس مقصد نمی‌تواند کیف پول برداشت سایت باشد.",
      "HOT_WALLET_DESTINATION",
    );
  }
  if (
    blockchainConfig.tokenAddress &&
    normalized === getAddress(blockchainConfig.tokenAddress)
  ) {
    throw new AppError(
      400,
      "آدرس قرارداد توکن مقصد برداشت نیست.",
      "TOKEN_CONTRACT_DESTINATION",
    );
  }
  return normalized;
}

function amountToRaw(amount: number, decimals: number): string {
  const exact = amount.toFixed(6).replace(/\.?0+$/, "");
  return parseUnits(exact || "0", decimals).toString();
}

export async function createWithdrawal(
  userId: string,
  value: number,
  walletAddress: string,
  password: string,
) {
  await releaseMaturedPositions(userId);
  const [settings, controls] = await Promise.all([
    getSettings(),
    getBlockchainControls(),
  ]);
  const amount = money(value);
  const destinationAddress = normalizeDestination(walletAddress);
  const requestDateKey = dateKey(new Date(), settings.timezone);
  const withdrawalId = randomId();
  const blockchainWithdrawalId = randomId();

  if (
    settings.fundingMode !== "BLOCKCHAIN" ||
    !blockchainConfig.enabled ||
    !blockchainConfig.configured
  ) {
    throw new AppError(
      503,
      "برداشت بلاک‌چینی هنوز روی سرور فعال نشده است.",
      "BLOCKCHAIN_WITHDRAWAL_NOT_CONFIGURED",
    );
  }
  if (
    !blockchainConfig.withdrawalWorkerEnabled ||
    !controls.withdrawalsEnabled ||
    !controls.withdrawalWorkerEnabled ||
    controls.emergencyStop
  ) {
    throw new AppError(
      503,
      controls.emergencyStop
        ? "برداشت بلاک‌چینی موقتاً به‌دلیل توقف اضطراری غیرفعال است."
        : "برداشت بلاک‌چینی موقتاً غیرفعال است.",
      "BLOCKCHAIN_WITHDRAWAL_DISABLED",
    );
  }
  if (!controls.tokenContract) {
    throw new AppError(
      503,
      "قرارداد توکن برداشت روی سرور تنظیم نشده است.",
      "TOKEN_NOT_CONFIGURED",
    );
  }
  if (controls.network !== "testnet") {
    throw new AppError(
      503,
      "نسخه مرحله ۷ فقط برای Testnet فعال است.",
      "MAINNET_WITHDRAWAL_BLOCKED",
    );
  }

  try {
    return await withTransaction(async (client) => {
      const userResult = await client.query(
        `SELECT u.password_hash, u.profit_balance, u.vip_level, u.is_active,
                COALESCE(v.min_withdrawal, $2) AS min_withdrawal
         FROM users u
         LEFT JOIN vip_tiers v ON v.level = u.vip_level AND v.is_active = TRUE
         WHERE u.id = $1
         FOR UPDATE OF u`,
        [userId, settings.minWithdrawal],
      );
      const user = userResult.rows[0];

      if (!user || !user.is_active) {
        throw new AppError(403, "حساب شما فعال نیست.", "ACCOUNT_DISABLED");
      }
      if (!(await verifyPassword(password, user.password_hash))) {
        throw new AppError(
          400,
          "رمز عبور نادرست است.",
          "INVALID_PASSWORD",
        );
      }

      const minimum = Number(user.min_withdrawal);
      if (Number(user.vip_level) === 0) {
        throw new AppError(
          400,
          "برای برداشت باید VIP فعال داشته باشید.",
          "VIP_REQUIRED",
        );
      }
      if (amount < minimum) {
        throw new AppError(
          400,
          `حداقل برداشت سطح شما ${minimum} USDT است.`,
          "MIN_WITHDRAWAL",
        );
      }
      if (Number(user.profit_balance) < amount) {
        throw new AppError(
          400,
          "موجودی قابل برداشت کافی نیست.",
          "INSUFFICIENT_BALANCE",
        );
      }

      const runtimeReadyForAutomatic = Boolean(
        blockchainConfig.withdrawalWorkerEnabled &&
        blockchainConfig.hotWalletAddress &&
        controls.network === "testnet",
      );
      const autoDecision = runtimeReadyForAutomatic
        ? await reserveAutomaticWithdrawalBudget(client, {
            amount,
            dateKey: requestDateKey,
          })
        : {
            automatic: false,
            reason: "WORKER_OR_HOT_WALLET_NOT_READY",
            policy: {
              enabled: false,
              maxAmount: controls.autoWithdrawalMaxAmount,
              dailyLimit: controls.autoWithdrawalDailyLimit,
              dailyCountLimit: controls.autoWithdrawalDailyCountLimit,
              maxConcurrent: controls.autoWithdrawalMaxConcurrent,
            },
          };
      const approvalMode = autoDecision.automatic ? "AUTOMATIC" : "MANUAL";
      const businessStatus = autoDecision.automatic ? "RESERVED" : "PENDING";
      const chainStatus = autoDecision.automatic ? "RESERVED" : "AWAITING_APPROVAL";

      const accounts = await ensureUserLedgerAccounts(client, userId);
      const reservationJournalId = await postLedgerJournal(client, {
        idempotencyKey: `ledger:withdrawal-reserve:${withdrawalId}`,
        referenceType: "Withdrawal",
        referenceId: withdrawalId,
        description: "Reserve user balance for blockchain withdrawal",
        metadata: {
          blockchainWithdrawalId,
          destinationAddress,
          chainId: controls.chainId,
        },
        entries: [
          {
            accountId: accounts.profitAccountId,
            direction: "DEBIT",
            amount: String(amount),
            userId,
            memo: "Reduce user withdrawable liability",
          },
          {
            accountId: "sys-usdt-withdrawal-payable",
            direction: "CREDIT",
            amount: String(amount),
            memo: "Create approved-withdrawal payable",
          },
        ],
      });

      await client.query(
        `INSERT INTO withdrawals(
           id, amount, wallet_address, network, request_date_key, status,
           user_id, source, chain_id, token_contract, reserved_at,
           reserved_journal_id, approval_mode, auto_approved_at,
           auto_approval_reason, auto_budget_date_key
         ) VALUES(
           $1,$2,$3,$4,$5,$6,$7,'BLOCKCHAIN',$8,$9,now(),$10,$11,
           CASE WHEN $11='AUTOMATIC' THEN now() ELSE NULL END,$12,
           CASE WHEN $11='AUTOMATIC' THEN $5 ELSE NULL END
         )`,
        [
          withdrawalId,
          amount,
          destinationAddress,
          `BSC-${controls.network.toUpperCase()}`,
          requestDateKey,
          businessStatus,
          userId,
          controls.chainId,
          controls.tokenContract,
          reservationJournalId,
          approvalMode,
          autoDecision.reason,
        ],
      );

      await client.query(
        `INSERT INTO blockchain_withdrawals(
           id, withdrawal_id, user_id, chain_id, token_contract,
           destination_address, amount_raw, amount, status,
           idempotency_key, reservation_journal_id, approval_mode,
           auto_approved_at, sender_address, reserved_at, metadata
         ) VALUES(
           $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,
           CASE WHEN $12='AUTOMATIC' THEN now() ELSE NULL END,
           CASE WHEN $12='AUTOMATIC' THEN $13 ELSE NULL END,
           CASE WHEN $12='AUTOMATIC' THEN now() ELSE NULL END,$14::jsonb
         )`,
        [
          blockchainWithdrawalId,
          withdrawalId,
          userId,
          controls.chainId,
          controls.tokenContract,
          destinationAddress,
          amountToRaw(amount, controls.tokenDecimals),
          amount,
          chainStatus,
          `withdrawal:${withdrawalId}`,
          reservationJournalId,
          approvalMode,
          blockchainConfig.hotWalletAddress ?? null,
          JSON.stringify({
            approvalRequired: !autoDecision.automatic,
            approvalMode,
            autoDecisionReason: autoDecision.reason,
            requestedVipLevel: Number(user.vip_level),
            minimumWithdrawal: minimum,
            automaticLimits: autoDecision.policy,
          }),
        ],
      );

      await client.query(
        `UPDATE withdrawals
         SET blockchain_withdrawal_id = $1, updated_at = now()
         WHERE id = $2`,
        [blockchainWithdrawalId, withdrawalId],
      );

      if (autoDecision.automatic) {
        await enqueueWithdrawalForExecution(client, blockchainWithdrawalId);
      }

      await client.query(
        `UPDATE users
         SET profit_balance = profit_balance - $1, updated_at = now()
         WHERE id = $2`,
        [amount, userId],
      );

      await client.query(
        `INSERT INTO transactions(
           id, type, amount, description, metadata, user_id
         ) VALUES($1,'WITHDRAWAL_REQUEST',$2,$3,$4::jsonb,$5)`,
        [
          randomId(),
          -amount,
          "ثبت درخواست برداشت و رزرو موجودی",
          JSON.stringify({
            withdrawalId,
            blockchainWithdrawalId,
            destinationAddress,
          }),
          userId,
        ],
      );

      await createNotification(client, {
        userId,
        type: autoDecision.automatic
          ? "WITHDRAWAL_AUTOMATICALLY_QUEUED"
          : "WITHDRAWAL_PENDING_APPROVAL",
        title: autoDecision.automatic
          ? "برداشت خودکار در صف ارسال قرار گرفت"
          : "درخواست برداشت ثبت شد",
        body: autoDecision.automatic
          ? `برداشت ${amount} USDT در محدوده خودکار بود و مستقیماً در صف ارسال Testnet قرار گرفت.`
          : `درخواست برداشت ${amount} USDT ثبت شد و پس از تأیید مدیر به شبکه ارسال می‌شود.`,
        metadata: {
          withdrawalId,
          blockchainWithdrawalId,
          destinationAddress,
          approvalMode,
          decisionReason: autoDecision.reason,
        },
      });

      return {
        id: withdrawalId,
        blockchainWithdrawalId,
        amount,
        walletAddress: destinationAddress,
        network: `BSC-${controls.network.toUpperCase()}`,
        status: businessStatus,
        approvalMode,
        automatic: autoDecision.automatic,
        decisionReason: autoDecision.reason,
        requestDateKey,
      };
    });
  } catch (error: any) {
    if (error?.code === "23505") {
      throw new AppError(
        409,
        "امروز قبلاً درخواست برداشت ثبت کرده‌اید.",
        "DAILY_WITHDRAWAL_LIMIT",
      );
    }
    throw error;
  }
}

export async function listUserWithdrawals(userId: string) {
  const result = await query(
    `SELECT w.*, bw.status AS blockchain_status, bw.tx_hash AS chain_tx_hash,
            bw.confirmations AS chain_confirmations, bw.failure_reason AS chain_failure
     FROM withdrawals w
     LEFT JOIN blockchain_withdrawals bw ON bw.id = w.blockchain_withdrawal_id
     WHERE w.user_id = $1
     ORDER BY w.created_at DESC`,
    [userId],
  );

  return result.rows.map((withdrawal) => {
    const txHash = withdrawal.chain_tx_hash || withdrawal.tx_hash || null;
    return {
      id: withdrawal.id,
      blockchainWithdrawalId: withdrawal.blockchain_withdrawal_id,
      amount: Number(withdrawal.amount),
      walletAddress: withdrawal.wallet_address,
      network: withdrawal.network,
      status: withdrawal.status,
      approvalMode: withdrawal.approval_mode || "MANUAL",
      automatic: withdrawal.approval_mode === "AUTOMATIC",
      autoApprovalReason: withdrawal.auto_approval_reason || null,
      blockchainStatus: withdrawal.blockchain_status,
      txHash,
      explorerUrl: txHash
        ? `${blockchainConfig.network.explorerBaseUrl}/tx/${txHash}`
        : null,
      confirmations: Number(
        withdrawal.chain_confirmations ?? withdrawal.confirmations ?? 0,
      ),
      note: withdrawal.note,
      failureReason:
        withdrawal.chain_failure || withdrawal.failure_reason || null,
      createdAt: withdrawal.created_at,
      updatedAt: withdrawal.updated_at,
      completedAt: withdrawal.completed_at,
    };
  });
}

export async function approveWithdrawal(
  adminId: string,
  id: string,
  note?: string,
) {
  const controls = await getBlockchainControls();
  if (
    !blockchainConfig.hotWalletAddress ||
    !blockchainConfig.withdrawalWorkerEnabled ||
    !controls.withdrawalsEnabled ||
    !controls.withdrawalWorkerEnabled ||
    controls.emergencyStop
  ) {
    throw new AppError(
      503,
      "Worker برداشت یا کیف پول Hot آماده نیست؛ درخواست ارسال نشد.",
      "WITHDRAWAL_WORKER_NOT_READY",
    );
  }

  return withTransaction(async (client) => {
    const result = await client.query(
      `SELECT w.*, bw.id AS bw_id, bw.status AS bw_status
       FROM withdrawals w
       JOIN blockchain_withdrawals bw ON bw.id = w.blockchain_withdrawal_id
       WHERE w.id = $1
       FOR UPDATE OF w, bw`,
      [id],
    );
    const withdrawal = result.rows[0];

    if (!withdrawal) {
      throw new AppError(
        404,
        "درخواست برداشت پیدا نشد.",
        "WITHDRAWAL_NOT_FOUND",
      );
    }
    if (withdrawal.status !== "PENDING") {
      throw new AppError(
        409,
        "این درخواست قبلاً بررسی شده است.",
        "ALREADY_REVIEWED",
      );
    }

    await client.query(
      `UPDATE withdrawals
       SET status = 'RESERVED', note = $1, reviewed_by = $2,
           reviewed_at = now(), updated_at = now()
       WHERE id = $3`,
      [note || null, adminId, id],
    );
    await client.query(
      `UPDATE blockchain_withdrawals
       SET status = 'RESERVED', sender_address = $1,
           approved_by = $2, approved_at = now(), reserved_at = now(),
           updated_at = now()
       WHERE id = $3`,
      [blockchainConfig.hotWalletAddress, adminId, withdrawal.bw_id],
    );
    await enqueueWithdrawalForExecution(client, withdrawal.bw_id);

    await client.query(
      `INSERT INTO admin_action_logs(
         id, action, target_type, target_id, metadata, actor_id
       ) VALUES($1,'APPROVE_BLOCKCHAIN_WITHDRAWAL','Withdrawal',$2,$3::jsonb,$4)`,
      [
        randomId(),
        id,
        JSON.stringify({
          blockchainWithdrawalId: withdrawal.bw_id,
          note: note || null,
        }),
        adminId,
      ],
    );
    await createNotification(client, {
      userId: withdrawal.user_id,
      type: "WITHDRAWAL_APPROVED_FOR_BROADCAST",
      title: "برداشت توسط مدیر تأیید شد",
      body: `برداشت ${Number(withdrawal.amount)} USDT در صف ارسال Testnet قرار گرفت.`,
      metadata: {
        withdrawalId: id,
        blockchainWithdrawalId: withdrawal.bw_id,
      },
    });

    return {
      id,
      blockchainWithdrawalId: withdrawal.bw_id,
      status: "RESERVED",
    };
  });
}

export async function rejectWithdrawal(
  adminId: string,
  id: string,
  note?: string,
) {
  return withTransaction(async (client) => {
    const result = await client.query(
      `SELECT w.*, bw.id AS bw_id, bw.status AS bw_status,
              bw.refund_journal_id AS bw_refund_journal_id,
              bw.approval_mode AS bw_approval_mode
       FROM withdrawals w
       JOIN blockchain_withdrawals bw ON bw.id = w.blockchain_withdrawal_id
       WHERE w.id = $1
       FOR UPDATE OF w, bw`,
      [id],
    );
    const withdrawal = result.rows[0];

    if (!withdrawal) {
      throw new AppError(
        404,
        "درخواست برداشت پیدا نشد.",
        "WITHDRAWAL_NOT_FOUND",
      );
    }
    const safeReviewCancellation =
      withdrawal.status === "REVIEW_REQUIRED" && !withdrawal.tx_hash;
    const safeAutomaticCancellation =
      withdrawal.approval_mode === "AUTOMATIC" &&
      withdrawal.status === "RESERVED" &&
      !withdrawal.tx_hash &&
      ["QUEUED", "RESERVED"].includes(withdrawal.bw_status);
    if (
      withdrawal.status !== "PENDING" &&
      !safeReviewCancellation &&
      !safeAutomaticCancellation
    ) {
      throw new AppError(
        409,
        withdrawal.tx_hash
          ? "این برداشت هش تراکنش دارد و تا تعیین وضعیت زنجیره نباید بازپرداخت شود."
          : "این درخواست در وضعیت قابل ردکردن نیست.",
        "WITHDRAWAL_CANNOT_BE_REJECTED",
      );
    }

    if (safeAutomaticCancellation && withdrawal.bw_id) {
      await client.query(
        `UPDATE blockchain_jobs
         SET status = 'CANCELLED',
             locked_by = NULL, locked_at = NULL, lock_expires_at = NULL,
             last_error = 'Cancelled safely by manager before signing',
             updated_at = now()
         WHERE payload->>'blockchainWithdrawalId' = $1
           AND status IN ('PENDING','RETRY','RUNNING')`,
        [withdrawal.bw_id],
      );
    }

    const accounts = await ensureUserLedgerAccounts(client, withdrawal.user_id);
    const refundJournalId = await postLedgerJournal(client, {
      idempotencyKey: `ledger:withdrawal-reject:${id}`,
      referenceType: "Withdrawal",
      referenceId: id,
      description: "Refund manager-rejected blockchain withdrawal",
      metadata: { note: note || null },
      entries: [
        {
          accountId: "sys-usdt-withdrawal-payable",
          direction: "DEBIT",
          amount: String(withdrawal.amount),
          memo: "Remove rejected withdrawal payable",
        },
        {
          accountId: accounts.profitAccountId,
          direction: "CREDIT",
          amount: String(withdrawal.amount),
          userId: withdrawal.user_id,
          memo: "Restore user withdrawable balance",
        },
      ],
    });

    await client.query(
      `UPDATE withdrawals
       SET status = 'REJECTED', note = $1, reviewed_by = $2,
           reviewed_at = now(), refund_journal_id = $3, updated_at = now()
       WHERE id = $4`,
      [note || null, adminId, refundJournalId, id],
    );
    if (withdrawal.bw_id) {
      await client.query(
        `UPDATE blockchain_withdrawals
         SET status = 'CANCELLED', failed_at = now(),
             failure_reason = $1, refund_journal_id = $2, updated_at = now()
         WHERE id = $3`,
        [note || "Rejected by manager", refundJournalId, withdrawal.bw_id],
      );
    }

    await client.query(
      `UPDATE users
       SET profit_balance = profit_balance + $1, updated_at = now()
       WHERE id = $2`,
      [withdrawal.amount, withdrawal.user_id],
    );

    await client.query(
      `INSERT INTO transactions(
         id, type, amount, description, metadata, user_id
       ) VALUES($1,'WITHDRAWAL_REJECTED',$2,$3,$4::jsonb,$5)`,
      [
        randomId(),
        Number(withdrawal.amount),
        "رد برداشت و بازگشت موجودی",
        JSON.stringify({ withdrawalId: id, note: note || null }),
        withdrawal.user_id,
      ],
    );
    await client.query(
      `INSERT INTO admin_action_logs(
         id, action, target_type, target_id, metadata, actor_id
       ) VALUES($1,'REJECT_WITHDRAWAL','Withdrawal',$2,$3::jsonb,$4)`,
      [
        randomId(),
        id,
        JSON.stringify({ note: note || null }),
        adminId,
      ],
    );
    await createNotification(client, {
      userId: withdrawal.user_id,
      type: "WITHDRAWAL_REJECTED",
      title: "درخواست برداشت رد شد",
      body: `درخواست برداشت ${Number(withdrawal.amount)} USDT رد شد و مبلغ به موجودی قابل برداشت بازگشت.`,
      metadata: { withdrawalId: id, note: note || null },
    });

    return { id, status: "REJECTED" };
  });
}


export async function getUserWithdrawalPolicy(userId: string) {
  const [settings, automation, userResult] = await Promise.all([
    getSettings(),
    getAutomaticWithdrawalSettings(),
    query(
      `SELECT u.vip_level,
              COALESCE(v.min_withdrawal, $2) AS min_withdrawal
       FROM users u
       LEFT JOIN vip_tiers v ON v.level = u.vip_level AND v.is_active = TRUE
       WHERE u.id = $1`,
      [userId, 0],
    ),
  ]);
  const user = userResult.rows[0];
  const dailyAmountRemaining = Math.max(
    0,
    Number(automation.dailyLimit) - Number(automation.usage.amount),
  );
  const dailyCountRemaining = Math.max(
    0,
    Number(automation.dailyCountLimit) - Number(automation.usage.count),
  );
  return {
    minimumWithdrawal: Number(user?.min_withdrawal ?? settings.minWithdrawal),
    vipLevel: Number(user?.vip_level ?? 0),
    automatic: {
      enabled: Boolean(automation.enabled),
      maxAmount: Number(automation.maxAmount),
      dailyAmountRemaining,
      dailyCountRemaining,
      pauseReason: automation.pauseReason || null,
    },
  };
}
