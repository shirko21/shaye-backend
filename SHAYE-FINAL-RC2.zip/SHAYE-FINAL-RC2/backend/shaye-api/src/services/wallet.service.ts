import { query, withTransaction } from "../config/database";
import { AppError } from "../utils/response";
import { getSettings, syncVipLevel } from "./settings.service";
import { mapUser, money, randomId } from "../utils/helpers";
import { UserRow } from "../db/types";

export async function releaseMaturedPositions(userId: string): Promise<number> {
  return withTransaction(async (client) => {
    const matured = await client.query<{ id: string; amount: string }>(
      `SELECT id, amount
       FROM lock_positions
       WHERE user_id = $1 AND status = 'ACTIVE' AND unlock_at <= now()
       FOR UPDATE`,
      [userId],
    );

    if (matured.rows.length === 0) return 0;

    const total = money(
      matured.rows.reduce((sum, position) => sum + Number(position.amount), 0),
    );
    const ids = matured.rows.map((position) => position.id);

    await client.query(
      `UPDATE lock_positions
       SET status = 'RELEASED', released_at = now(), updated_at = now()
       WHERE id = ANY($1::text[])`,
      [ids],
    );

    await client.query(
      `UPDATE users
       SET locked_balance = GREATEST(locked_balance - $1, 0),
           deposit_balance = deposit_balance + $1,
           updated_at = now()
       WHERE id = $2`,
      [total, userId],
    );

    await client.query(
      `INSERT INTO transactions(id, type, amount, description, metadata, user_id)
       VALUES($1, 'PRINCIPAL_RELEASED', $2, $3, $4, $5)`,
      [
        randomId(),
        total,
        "آزادسازی اصل سرمایه پس از پایان دوره",
        JSON.stringify({ lockPositionIds: ids }),
        userId,
      ],
    );

    await syncVipLevel(userId, client);
    return total;
  });
}

export async function summary(userId: string) {
  await releaseMaturedPositions(userId);

  const [userResult, settings, locksResult] = await Promise.all([
    query<UserRow>("SELECT * FROM users WHERE id = $1", [userId]),
    getSettings(),
    query(
      `SELECT id, amount, started_at, unlock_at
       FROM lock_positions
       WHERE user_id = $1 AND status = 'ACTIVE'
       ORDER BY unlock_at`,
      [userId],
    ),
  ]);

  const user = userResult.rows[0];
  if (!user) throw new AppError(404, "کاربر پیدا نشد.", "USER_NOT_FOUND");

  return {
    ...mapUser(user),
    settings,
    activeLocks: locksResult.rows.map((lock) => ({
      id: lock.id,
      amount: Number(lock.amount),
      startedAt: lock.started_at,
      unlockAt: lock.unlock_at,
    })),
  };
}

export async function transactions(userId: string, limit = 50) {
  const safeLimit = Math.min(Math.max(Math.trunc(limit), 1), 200);
  const result = await query(
    `SELECT id, type, amount, description, metadata, created_at
     FROM transactions
     WHERE user_id = $1
     ORDER BY created_at DESC
     LIMIT $2`,
    [userId, safeLimit],
  );

  return result.rows.map((transaction) => ({
    id: transaction.id,
    type: transaction.type,
    amount: Number(transaction.amount),
    description: transaction.description,
    metadata: transaction.metadata,
    createdAt: transaction.created_at,
  }));
}

export async function movePrincipalToProfit(userId: string, value: number) {
  await releaseMaturedPositions(userId);
  const amount = money(value);

  await withTransaction(async (client) => {
    const userResult = await client.query<{ deposit_balance: string }>(
      "SELECT deposit_balance FROM users WHERE id = $1 FOR UPDATE",
      [userId],
    );
    const user = userResult.rows[0];

    if (!user || Number(user.deposit_balance) < amount) {
      throw new AppError(
        400,
        "موجودی اصل سرمایه کافی نیست.",
        "INSUFFICIENT_PRINCIPAL",
      );
    }

    await client.query(
      `UPDATE users
       SET deposit_balance = deposit_balance - $1,
           profit_balance = profit_balance + $1,
           updated_at = now()
       WHERE id = $2`,
      [amount, userId],
    );

    await client.query(
      `INSERT INTO transactions(id, type, amount, description, user_id)
       VALUES($1, 'PRINCIPAL_TO_PROFIT', $2, $3, $4)`,
      [
        randomId(),
        amount,
        "انتقال اصل سرمایه آزادشده به موجودی قابل برداشت",
        userId,
      ],
    );
  });
}

export async function reinvest(userId: string, value: number) {
  await releaseMaturedPositions(userId);
  const amount = money(value);
  const settings = await getSettings();

  await withTransaction(async (client) => {
    const userResult = await client.query<{ deposit_balance: string }>(
      "SELECT deposit_balance FROM users WHERE id = $1 FOR UPDATE",
      [userId],
    );
    const user = userResult.rows[0];

    if (!user || Number(user.deposit_balance) < amount) {
      throw new AppError(
        400,
        "موجودی اصل سرمایه کافی نیست.",
        "INSUFFICIENT_PRINCIPAL",
      );
    }

    await client.query(
      `UPDATE users
       SET deposit_balance = deposit_balance - $1,
           locked_balance = locked_balance + $1,
           updated_at = now()
       WHERE id = $2`,
      [amount, userId],
    );

    await client.query(
      `INSERT INTO lock_positions(id, amount, unlock_at, user_id, lock_days_snapshot)
       VALUES($1, $2, now() + ($3 || ' days')::interval, $4, $3)`,
      [randomId(), amount, settings.lockDays, userId],
    );

    await client.query(
      `INSERT INTO transactions(id, type, amount, description, user_id)
       VALUES($1, 'REINVESTMENT', $2, $3, $4)`,
      [randomId(), amount, "سرمایه‌گذاری مجدد", userId],
    );

    await syncVipLevel(userId, client);
  });
}
