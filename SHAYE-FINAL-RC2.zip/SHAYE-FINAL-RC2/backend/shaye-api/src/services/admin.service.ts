import { query, withTransaction } from "../config/database";
import { blockchainConfig } from "../config/blockchain";
import { AppError } from "../utils/response";
import {
  getSettings,
  getVipTiers,
  syncAllVipLevels,
} from "./settings.service";
import { mapSetting, randomId } from "../utils/helpers";

const REVIEW_STATUSES = new Set(["PENDING","RESERVED","PROCESSING","BROADCASTED","CONFIRMING","APPROVED","COMPLETED","FAILED","REVIEW_REQUIRED","REJECTED","CANCELLED"]);

function normalizeStatus(status?: string) {
  if (!status) return "";
  const normalized = status.trim().toUpperCase();
  if (!REVIEW_STATUSES.has(normalized)) {
    throw new AppError(400, "وضعیت نامعتبر است.", "INVALID_STATUS");
  }
  return normalized;
}

export async function overview() {
  const result = await query(
    `SELECT
      (SELECT count(*) FROM users)::int AS users,
      (SELECT count(*) FROM users WHERE is_active)::int AS active_users,
      (SELECT count(*) FROM deposits WHERE status = 'PENDING')::int AS pending_deposits,
      (SELECT count(*) FROM withdrawals WHERE status = 'PENDING')::int AS pending_withdrawals,
      (SELECT count(*) FROM support_messages WHERE sender_role='USER' AND read_by_admin=FALSE)::int AS unread_support,
      COALESCE((SELECT sum(reward_amount) FROM wheel_history),0) AS wheel_rewards,
      COALESCE(sum(total_deposit), 0) AS total_deposit,
      COALESCE(sum(total_withdraw), 0) AS total_withdraw,
      COALESCE(sum(total_profit), 0) AS total_profit,
      COALESCE(sum(locked_balance), 0) AS locked_balance
     FROM users`,
  );
  const row = result.rows[0];

  return {
    users: row.users,
    activeUsers: row.active_users,
    pendingDeposits: row.pending_deposits,
    pendingWithdrawals: row.pending_withdrawals,
    unreadSupport: row.unread_support,
    wheelRewards: Number(row.wheel_rewards),
    sums: {
      totalDeposit: Number(row.total_deposit),
      totalWithdraw: Number(row.total_withdraw),
      totalProfit: Number(row.total_profit),
      lockedBalance: Number(row.locked_balance),
    },
  };
}

export async function listUsers(search = "") {
  const result = await query(
    `SELECT id, email, role, vip_level, is_active, deposit_balance,
            profit_balance, locked_balance, total_deposit,
            total_withdraw, wheel_spins, wheel_spins_used, wallet_address, created_at
     FROM users
     WHERE ($1 = '' OR email ILIKE '%' || $1 || '%')
     ORDER BY created_at DESC
     LIMIT 200`,
    [search.trim()],
  );

  return result.rows.map((user) => ({
    id: user.id,
    email: user.email,
    role: user.role,
    vipLevel: user.vip_level,
    isActive: user.is_active,
    depositBalance: Number(user.deposit_balance),
    profitBalance: Number(user.profit_balance),
    lockedBalance: Number(user.locked_balance),
    totalDeposit: Number(user.total_deposit),
    totalWithdraw: Number(user.total_withdraw),
    wheelSpins: Number(user.wheel_spins || 0),
    wheelSpinsUsed: Number(user.wheel_spins_used || 0),
    walletAddress: user.wallet_address || "",
    createdAt: user.created_at,
  }));
}

export async function setUserActive(
  adminId: string,
  userId: string,
  isActive: boolean,
) {
  if (adminId === userId && !isActive) {
    throw new AppError(
      400,
      "نمی‌توانید حساب مدیر فعلی را غیرفعال کنید.",
      "SELF_DISABLE",
    );
  }

  await withTransaction(async (client) => {
    const updated = await client.query(
      `UPDATE users
       SET is_active = $1, updated_at = now()
       WHERE id = $2
       RETURNING id`,
      [isActive, userId],
    );

    if (!updated.rows[0]) {
      throw new AppError(404, "کاربر پیدا نشد.", "USER_NOT_FOUND");
    }

    await client.query(
      `INSERT INTO admin_action_logs(
        id, action, target_type, target_id, actor_id
      ) VALUES($1, $2, 'User', $3, $4)`,
      [
        randomId(),
        isActive ? "ACTIVATE_USER" : "DEACTIVATE_USER",
        userId,
        adminId,
      ],
    );
  });
}

export async function listDeposits(status?: string) {
  const normalizedStatus = normalizeStatus(status);
  const result = await query(
    `SELECT d.*, u.email
     FROM deposits d
     JOIN users u ON u.id = d.user_id
     WHERE ($1 = '' OR d.status = $1)
     ORDER BY d.created_at DESC
     LIMIT 300`,
    [normalizedStatus],
  );

  return result.rows.map((deposit) => ({
    id: deposit.id,
    amount: Number(deposit.amount),
    referenceCode: deposit.reference_code,
    txHash: deposit.tx_hash,
    status: deposit.status,
    note: deposit.note,
    reviewedAt: deposit.reviewed_at,
    createdAt: deposit.created_at,
    user: { email: deposit.email },
  }));
}

export async function listWithdrawals(status?: string) {
  const normalizedStatus = normalizeStatus(status);
  const result = await query(
    `SELECT w.*, u.email,
            bw.status AS blockchain_status,
            bw.tx_hash AS chain_tx_hash,
            bw.confirmations AS chain_confirmations,
            bw.failure_reason AS chain_failure,
            bw.sender_address
     FROM withdrawals w
     JOIN users u ON u.id = w.user_id
     LEFT JOIN blockchain_withdrawals bw ON bw.id = w.blockchain_withdrawal_id
     WHERE ($1 = '' OR w.status = $1)
     ORDER BY w.created_at DESC
     LIMIT 300`,
    [normalizedStatus],
  );

  return result.rows.map((withdrawal) => ({
    id: withdrawal.id,
    amount: Number(withdrawal.amount),
    walletAddress: withdrawal.wallet_address,
    network: withdrawal.network,
    status: withdrawal.status,
    approvalMode: withdrawal.approval_mode || "MANUAL",
    automatic: withdrawal.approval_mode === "AUTOMATIC",
    autoApprovalReason: withdrawal.auto_approval_reason || null,
    blockchainStatus: withdrawal.blockchain_status,
    txHash: withdrawal.chain_tx_hash || withdrawal.tx_hash || null,
    explorerUrl: (withdrawal.chain_tx_hash || withdrawal.tx_hash)
      ? `${blockchainConfig.network.explorerBaseUrl}/tx/${withdrawal.chain_tx_hash || withdrawal.tx_hash}`
      : null,
    confirmations: Number(withdrawal.chain_confirmations ?? withdrawal.confirmations ?? 0),
    failureReason: withdrawal.chain_failure || withdrawal.failure_reason || null,
    senderAddress: withdrawal.sender_address || null,
    note: withdrawal.note,
    reviewedAt: withdrawal.reviewed_at,
    completedAt: withdrawal.completed_at,
    createdAt: withdrawal.created_at,
    user: { email: withdrawal.email },
  }));
}

export async function updateSettings(adminId: string, input: any) {
  const result = await withTransaction(async (client) => {
    const updated = await client.query(
      `UPDATE app_settings SET platform_name=$1,sandbox_mode=$2,funding_mode=$3,
       deposit_wallet_address=$4,deposit_network=$5,min_deposit=$6,min_withdrawal=$7,
       lock_days=$8,level1_referral_rate=$9,level2_referral_rate=$10,task_hour=$11,
       timezone=$12,maintenance_mode=$13,support_url=$14,updated_at=now()
       WHERE id='default' RETURNING *`,
      [input.platformName,Boolean(input.sandboxMode),input.fundingMode,input.depositWalletAddress,
       input.depositNetwork,input.minDeposit,input.minWithdrawal,input.lockDays,
       input.level1ReferralRate,input.level2ReferralRate,input.taskHour,input.timezone,
       input.maintenanceMode,input.supportUrl||null]);
    await client.query(`INSERT INTO admin_action_logs(id,action,target_type,target_id,metadata,actor_id)
      VALUES($1,'UPDATE_SETTINGS','AppSetting','default',$2,$3)`,[randomId(),JSON.stringify(input),adminId]);
    return updated.rows[0];
  });
  return mapSetting(result);
}

export async function updateVipTiers(adminId: string, tiers: any[]) {
  return withTransaction(async (client) => {
    const submittedLevels = tiers.map((tier) => tier.level);

    for (const tier of tiers) {
      await client.query(
        `INSERT INTO vip_tiers(
          id, level, label, min_locked, daily_rate,
          min_withdrawal, is_active
        ) VALUES($1, $2, $3, $4, $5, $6, $7)
        ON CONFLICT(level) DO UPDATE SET
          label = EXCLUDED.label,
          min_locked = EXCLUDED.min_locked,
          daily_rate = EXCLUDED.daily_rate,
          min_withdrawal = EXCLUDED.min_withdrawal,
          is_active = EXCLUDED.is_active,
          updated_at = now()`,
        [
          randomId(),
          tier.level,
          tier.label,
          tier.minLocked,
          tier.dailyRate,
          tier.minWithdrawal,
          tier.isActive,
        ],
      );
    }

    await client.query(
      `UPDATE vip_tiers
       SET is_active = FALSE, updated_at = now()
       WHERE NOT (level = ANY($1::int[]))`,
      [submittedLevels],
    );

    await syncAllVipLevels(client);

    await client.query(
      `INSERT INTO admin_action_logs(
        id, action, target_type, metadata, actor_id
      ) VALUES($1, 'UPDATE_VIP_TIERS', 'VipTier', $2, $3)`,
      [randomId(), JSON.stringify({ tiers }), adminId],
    );

    const result = await client.query(
      "SELECT * FROM vip_tiers ORDER BY level",
    );
    return result.rows.map((tier) => ({
      id: tier.id,
      level: tier.level,
      label: tier.label,
      minLocked: Number(tier.min_locked),
      dailyRate: Number(tier.daily_rate),
      minWithdrawal: Number(tier.min_withdrawal),
      isActive: tier.is_active,
      createdAt: tier.created_at,
      updatedAt: tier.updated_at,
    }));
  });
}

export async function listAnnouncements(admin = false) {
  const sql = admin
    ? `SELECT * FROM announcements
       ORDER BY priority DESC, created_at DESC`
    : `SELECT * FROM announcements
       WHERE is_active = TRUE
         AND (starts_at IS NULL OR starts_at <= now())
         AND (ends_at IS NULL OR ends_at >= now())
       ORDER BY priority DESC, created_at DESC`;

  const result = await query(sql);
  return result.rows.map((announcement) => ({
    id: announcement.id,
    title: announcement.title,
    body: announcement.body,
    imageUrl: announcement.image_url,
    actionText: announcement.action_text,
    actionUrl: announcement.action_url,
    priority: announcement.priority,
    isActive: announcement.is_active,
    startsAt: announcement.starts_at,
    endsAt: announcement.ends_at,
    createdAt: announcement.created_at,
    updatedAt: announcement.updated_at,
  }));
}

export async function saveAnnouncement(
  adminId: string,
  input: any,
  id?: string,
) {
  const announcementId = id || randomId();

  return withTransaction(async (client) => {
    const result = id
      ? await client.query(
          `UPDATE announcements
           SET title = $1, body = $2, image_url = $3,
               action_text = $4, action_url = $5, priority = $6,
               is_active = $7, starts_at = $8, ends_at = $9,
               updated_at = now()
           WHERE id = $10
           RETURNING *`,
          [
            input.title,
            input.body,
            input.imageUrl || null,
            input.actionText || null,
            input.actionUrl || null,
            input.priority,
            input.isActive,
            input.startsAt || null,
            input.endsAt || null,
            id,
          ],
        )
      : await client.query(
          `INSERT INTO announcements(
            id, title, body, image_url, action_text, action_url,
            priority, is_active, starts_at, ends_at
          ) VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
          RETURNING *`,
          [
            announcementId,
            input.title,
            input.body,
            input.imageUrl || null,
            input.actionText || null,
            input.actionUrl || null,
            input.priority,
            input.isActive,
            input.startsAt || null,
            input.endsAt || null,
          ],
        );

    const announcement = result.rows[0];
    if (!announcement) {
      throw new AppError(
        404,
        "اطلاعیه پیدا نشد.",
        "ANNOUNCEMENT_NOT_FOUND",
      );
    }

    await client.query(
      `INSERT INTO admin_action_logs(
        id, action, target_type, target_id, actor_id
      ) VALUES($1, $2, 'Announcement', $3, $4)`,
      [
        randomId(),
        id ? "UPDATE_ANNOUNCEMENT" : "CREATE_ANNOUNCEMENT",
        announcementId,
        adminId,
      ],
    );

    return {
      id: announcement.id,
      title: announcement.title,
      body: announcement.body,
      imageUrl: announcement.image_url,
      actionText: announcement.action_text,
      actionUrl: announcement.action_url,
      priority: announcement.priority,
      isActive: announcement.is_active,
      startsAt: announcement.starts_at,
      endsAt: announcement.ends_at,
      createdAt: announcement.created_at,
      updatedAt: announcement.updated_at,
    };
  });
}

export async function deleteAnnouncement(adminId: string, id: string) {
  await withTransaction(async (client) => {
    const deleted = await client.query(
      "DELETE FROM announcements WHERE id = $1 RETURNING id",
      [id],
    );

    if (!deleted.rows[0]) {
      throw new AppError(
        404,
        "اطلاعیه پیدا نشد.",
        "ANNOUNCEMENT_NOT_FOUND",
      );
    }

    await client.query(
      `INSERT INTO admin_action_logs(
        id, action, target_type, target_id, actor_id
      ) VALUES($1, 'DELETE_ANNOUNCEMENT', 'Announcement', $2, $3)`,
      [randomId(), id, adminId],
    );
  });
}

export async function publicConfig() {
  return {
    settings: await getSettings(),
    tiers: await getVipTiers(false),
  };
}

export async function adminConfig() {
  return {
    settings: await getSettings(),
    tiers: await getVipTiers(true),
  };
}
