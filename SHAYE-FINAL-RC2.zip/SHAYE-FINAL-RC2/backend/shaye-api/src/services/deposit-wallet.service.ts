import crypto from "node:crypto";
import fs from "node:fs";
import { HDNodeWallet, getAddress } from "ethers";
import QRCode from "qrcode";
import { PoolClient } from "pg";
import { blockchainConfig } from "../config/blockchain";
import { depositWalletConfig } from "../config/deposit-wallet";
import { query, withTransaction } from "../config/database";
import { AppError } from "../utils/response";
import { randomId } from "../utils/helpers";
import { getSettings } from "./settings.service";
import { getBlockchainControls } from "./blockchain-database.service";

interface DepositWalletRow {
  id: string;
  user_id: string;
  chain_id: string | number;
  address: string;
  derivation_index: string | number;
  derivation_path: string;
  key_fingerprint: string;
  status: "ACTIVE" | "DISABLED" | "ARCHIVED";
  assigned_at: Date;
  created_at: Date;
  updated_at: Date;
}

interface LoadedXpub {
  value: string;
  fingerprint: string;
  depth: number;
}

let xpubCache: { mtimeMs: number; loaded: LoadedXpub } | null = null;

function publicFailure(message: string, code: string): never {
  throw new AppError(503, message, code);
}

function loadAccountXpub(): LoadedXpub {
  if (!depositWalletConfig.enabled) {
    publicFailure(
      "سامانه آدرس اختصاصی واریز هنوز فعال نشده است.",
      "DEPOSIT_WALLET_DISABLED",
    );
  }

  let stats: fs.Stats;
  let xpub: string;

  try {
    stats = fs.statSync(depositWalletConfig.xpubFile);
    if (xpubCache && xpubCache.mtimeMs === stats.mtimeMs) {
      return xpubCache.loaded;
    }
    xpub = fs.readFileSync(depositWalletConfig.xpubFile, "utf8").trim();
  } catch {
    publicFailure(
      "کلید عمومی کیف پول واریز روی سرور تنظیم نشده است.",
      "DEPOSIT_XPUB_MISSING",
    );
  }

  if (!xpub || !/^[xt]pub/i.test(xpub)) {
    publicFailure(
      "کلید عمومی کیف پول واریز معتبر نیست.",
      "DEPOSIT_XPUB_INVALID",
    );
  }

  try {
    const node = HDNodeWallet.fromExtendedKey(xpub);
    if (node.depth !== 3) {
      publicFailure(
        "عمق کلید عمومی کیف پول واریز با مسیر حساب سازگار نیست.",
        "DEPOSIT_XPUB_DEPTH_INVALID",
      );
    }

    const loaded = {
      value: xpub,
      fingerprint: crypto.createHash("sha256").update(xpub).digest("hex").slice(0, 32),
      depth: node.depth,
    };
    xpubCache = { mtimeMs: stats.mtimeMs, loaded };
    return loaded;
  } catch (error) {
    if (error instanceof AppError) throw error;
    publicFailure(
      "کلید عمومی کیف پول واریز قابل خواندن نیست.",
      "DEPOSIT_XPUB_INVALID",
    );
  }
}

function deriveDepositAddress(xpub: string, index: number): string {
  if (!Number.isSafeInteger(index) || index < 0) {
    throw new Error("Invalid derivation index");
  }

  const accountNode = HDNodeWallet.fromExtendedKey(xpub);
  const child = accountNode.derivePath(`${depositWalletConfig.changeIndex}/${index}`);
  return getAddress(child.address);
}

function fullDerivationPath(index: number): string {
  return `${depositWalletConfig.accountPath}/${depositWalletConfig.changeIndex}/${index}`;
}

function mapWallet(row: DepositWalletRow) {
  const address = getAddress(row.address);
  return {
    id: row.id,
    address,
    chainId: Number(row.chain_id),
    network: blockchainConfig.network.name,
    purpose: "DEPOSIT" as const,
    status: row.status,
    derivationIndex: Number(row.derivation_index),
    assignedAt: row.assigned_at,
    explorerUrl: `${blockchainConfig.network.explorerBaseUrl}/address/${address}`,
  };
}

async function findWallet(
  client: PoolClient,
  userId: string,
): Promise<DepositWalletRow | undefined> {
  const result = await client.query<DepositWalletRow>(
    `SELECT id, user_id, chain_id, address, derivation_index,
            derivation_path, key_fingerprint, status, assigned_at,
            created_at, updated_at
     FROM blockchain_wallets
     WHERE user_id = $1
       AND chain_id = $2
       AND purpose = 'DEPOSIT'
       AND status <> 'ARCHIVED'
     ORDER BY created_at DESC
     LIMIT 1`,
    [userId, blockchainConfig.network.chainId],
  );
  return result.rows[0];
}

export async function ensureUserDepositWallet(userId: string) {
  const loaded = loadAccountXpub();

  const row = await withTransaction(async (client) => {
    await client.query(
      "SELECT pg_advisory_xact_lock(hashtext($1))",
      [`shaye-deposit-wallet:${blockchainConfig.network.chainId}:${userId}`],
    );

    const existing = await findWallet(client, userId);
    if (existing) {
      if (existing.key_fingerprint !== loaded.fingerprint) {
        throw new AppError(
          503,
          "کلید عمومی سرور با آدرس واریز قبلی این حساب سازگار نیست. واریز را متوقف و با مدیر تماس بگیرید.",
          "DEPOSIT_KEY_VERSION_MISMATCH",
        );
      }
      return existing;
    }

    const userResult = await client.query<{ id: string; is_active: boolean }>(
      "SELECT id, is_active FROM users WHERE id = $1 FOR SHARE",
      [userId],
    );
    const user = userResult.rows[0];
    if (!user) {
      throw new AppError(404, "کاربر پیدا نشد.", "USER_NOT_FOUND");
    }
    if (!user.is_active) {
      throw new AppError(403, "حساب کاربری غیرفعال است.", "ACCOUNT_DISABLED");
    }

    const indexResult = await client.query<{ derivation_index: string }>(
      `SELECT nextval('blockchain_deposit_derivation_index_seq')::text
       AS derivation_index`,
    );
    const index = Number(indexResult.rows[0]?.derivation_index);
    const address = deriveDepositAddress(loaded.value, index);
    const walletId = randomId();

    const inserted = await client.query<DepositWalletRow>(
      `INSERT INTO blockchain_wallets(
         id, user_id, purpose, chain_id, address,
         derivation_index, derivation_path, key_fingerprint,
         status, metadata
       ) VALUES($1,$2,'DEPOSIT',$3,$4,$5,$6,$7,'ACTIVE',$8::jsonb)
       RETURNING id, user_id, chain_id, address, derivation_index,
                 derivation_path, key_fingerprint, status, assigned_at,
                 created_at, updated_at`,
      [
        walletId,
        userId,
        blockchainConfig.network.chainId,
        address,
        index,
        fullDerivationPath(index),
        loaded.fingerprint,
        JSON.stringify({ accountPath: depositWalletConfig.accountPath }),
      ],
    );

    return inserted.rows[0]!;
  });

  const [settings, controls] = await Promise.all([
    getSettings(),
    getBlockchainControls(),
  ]);
  const wallet = mapWallet(row);
  const qrCodeDataUrl = await QRCode.toDataURL(wallet.address, {
    errorCorrectionLevel: "M",
    margin: 1,
    width: 320,
  });

  return {
    wallet,
    qrCodeDataUrl,
    token: {
      symbol: controls.tokenSymbol || "USDT",
      contract: controls.tokenContract || blockchainConfig.tokenAddress || null,
      decimals: controls.tokenDecimals,
    },
    deposit: {
      minimumAmount: settings.minDeposit,
      requiredConfirmations: controls.requiredConfirmations,
      automaticDetectionActive:
        blockchainConfig.enabled &&
        blockchainConfig.depositScannerEnabled &&
        controls.depositsEnabled &&
        !controls.emergencyStop,
      automaticCreditActive:
        blockchainConfig.enabled &&
        blockchainConfig.autoCreditEnabled &&
        controls.depositsEnabled &&
        controls.autoCreditEnabled &&
        settings.fundingMode === "BLOCKCHAIN" &&
        !controls.emergencyStop,
      scanIntervalSeconds: Math.round(blockchainConfig.watcherIntervalMs / 1000),
    },
    warning:
      blockchainConfig.network.name === "testnet"
        ? "این آدرس برای BSC Testnet است. دارایی واقعی ارسال نکنید."
        : "فقط توکن تعیین‌شده روی شبکه BEP20 را به این آدرس ارسال کنید.",
  };
}

export async function listUserBlockchainDeposits(userId: string) {
  const result = await query(
    `SELECT d.id, d.amount, d.credited_amount, d.confirmations, d.status,
            d.tx_hash, d.block_number, d.detected_at, d.confirmed_at,
            d.credited_at, d.created_at, s.unlock_at, s.lock_days_snapshot,
            s.vip_level_after
     FROM blockchain_deposits d
     LEFT JOIN deposit_credit_settlements s ON s.blockchain_deposit_id = d.id
     WHERE d.user_id = $1
     ORDER BY created_at DESC
     LIMIT 100`,
    [userId],
  );

  return result.rows.map((row) => ({
    id: row.id,
    amount: Number(row.amount),
    creditedAmount: row.credited_amount == null ? null : Number(row.credited_amount),
    confirmations: Number(row.confirmations),
    status: row.status,
    txHash: row.tx_hash,
    blockNumber: Number(row.block_number),
    detectedAt: row.detected_at,
    confirmedAt: row.confirmed_at,
    creditedAt: row.credited_at,
    unlockAt: row.unlock_at ?? null,
    lockDays: row.lock_days_snapshot == null ? null : Number(row.lock_days_snapshot),
    vipLevelAfter: row.vip_level_after == null ? null : Number(row.vip_level_after),
    createdAt: row.created_at,
    explorerUrl: `${blockchainConfig.network.explorerBaseUrl}/tx/${row.tx_hash}`,
  }));
}

export async function listAdminDepositWallets(search = "", limit = 100) {
  const normalized = search.trim().toLowerCase();
  const safeLimit = Math.max(1, Math.min(Number(limit) || 100, 500));
  const result = await query(
    `SELECT w.id, w.user_id, w.chain_id, w.address, w.derivation_index,
            w.derivation_path, w.key_fingerprint, w.status, w.assigned_at,
            w.created_at, w.updated_at, u.email
     FROM blockchain_wallets w
     JOIN users u ON u.id = w.user_id
     WHERE w.purpose = 'DEPOSIT'
       AND w.chain_id = $1
       AND ($2 = '' OR lower(u.email) LIKE '%' || $2 || '%' OR lower(w.address) LIKE '%' || $2 || '%')
     ORDER BY w.derivation_index ASC
     LIMIT $3`,
    [blockchainConfig.network.chainId, normalized, safeLimit],
  );

  return result.rows.map((row) => ({
    ...mapWallet(row as DepositWalletRow),
    userId: row.user_id,
    email: row.email,
    derivationPath: row.derivation_path,
    keyFingerprint: row.key_fingerprint,
  }));
}


export function deriveConfiguredDepositAddress(index: number): string {
  const loaded = loadAccountXpub();
  return deriveDepositAddress(loaded.value, index);
}

export function getConfiguredDepositWalletFingerprint(): string {
  return loadAccountXpub().fingerprint;
}

export function inspectDepositWalletConfiguration() {
  const loaded = loadAccountXpub();
  const firstAddress = deriveDepositAddress(loaded.value, 0);
  return {
    enabled: depositWalletConfig.enabled,
    network: blockchainConfig.network.name,
    chainId: blockchainConfig.network.chainId,
    accountPath: depositWalletConfig.accountPath,
    changeIndex: depositWalletConfig.changeIndex,
    xpubFingerprint: loaded.fingerprint,
    firstAddress,
  };
}
