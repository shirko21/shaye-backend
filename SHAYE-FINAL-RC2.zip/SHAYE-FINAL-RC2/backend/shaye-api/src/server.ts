import http from "http";
import app from "./app";
import { env } from "./env";
import { pool } from "./config/database";
import { runMigrations } from "./db/migrate";
import { ensureDefaults } from "./services/settings.service";
import { ensureAdmin } from "./services/auth.service";
import { logger } from "./utils/logger";
import { destroyBlockchainProvider } from "./services/blockchain.service";
import { syncBlockchainSettingsFromRuntime } from "./services/blockchain-database.service";

async function start() {
  await runMigrations();
  await syncBlockchainSettingsFromRuntime();
  await ensureDefaults();
  await ensureAdmin(env.ADMIN_EMAIL, env.ADMIN_PASSWORD);

  const server = http.createServer(app);
  server.requestTimeout = 20_000;
  server.headersTimeout = 22_000;
  server.keepAliveTimeout = 5_000;

  server.listen(env.PORT, "0.0.0.0", () => {
    logger.info(
      `SHAYE listening on port ${env.PORT} (${env.NODE_ENV})`,
    );
  });

  let shuttingDown = false;
  const shutdown = (signal: string) => {
    if (shuttingDown) return;
    shuttingDown = true;
    logger.info(`${signal} received; shutting down`);

    server.close(async () => {
      await destroyBlockchainProvider();
      await pool.end();
      process.exit(0);
    });

    setTimeout(() => process.exit(1), 10_000).unref();
  };

  process.on("SIGINT", () => shutdown("SIGINT"));
  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("unhandledRejection", (reason) => {
    logger.error("Unhandled rejection", reason);
    shutdown("UNHANDLED_REJECTION");
  });
  process.on("uncaughtException", (error) => {
    logger.error("Uncaught exception", error);
    shutdown("UNCAUGHT_EXCEPTION");
  });
}

start().catch(async (error) => {
  logger.error(error);
  await destroyBlockchainProvider();
  await pool.end();
  process.exit(1);
});
