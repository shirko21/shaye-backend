import os from "node:os";
import { blockchainConfig } from "../config/blockchain";
import { pool } from "../config/database";
import { runMigrations } from "../db/migrate";
import {
  recoverExpiredBlockchainJobs,
  syncBlockchainSettingsFromRuntime,
} from "../services/blockchain-database.service";
import { runDepositCreditCycle } from "../services/deposit-credit.service";
import { logger } from "../utils/logger";

const sleep = (milliseconds: number) =>
  new Promise<void>((resolve) => setTimeout(resolve, milliseconds));

const instanceId = `${os.hostname()}:${process.pid}`;
let stopping = false;

async function run() {
  await runMigrations();
  await syncBlockchainSettingsFromRuntime();
  const recoveredJobs = await recoverExpiredBlockchainJobs();
  if (recoveredJobs > 0) {
    logger.warn(`Recovered ${recoveredJobs} expired blockchain job leases`);
  }

  logger.info(
    `Blockchain deposit credit worker started (chain ${blockchainConfig.network.chainId}, instance ${instanceId})`,
  );

  if (!blockchainConfig.autoCreditEnabled) {
    logger.warn(
      "Automatic deposit credit is paused. Enable it only after Testnet deposit detection has been verified.",
    );
  }

  while (!stopping) {
    try {
      const result = await runDepositCreditCycle(instanceId);
      if (result.status === "paused") {
        logger.warn(`Deposit credit worker paused: ${result.reason}`);
      } else {
        logger.info(
          `Deposit credit cycle: enqueued=${result.enqueued} processed=${result.processed} credited=${result.credited} ignored=${result.ignored} failed=${result.failed}`,
        );
      }
    } catch (error) {
      logger.error("Deposit credit worker cycle failed", error);
    }
    await sleep(blockchainConfig.creditWorkerIntervalMs);
  }
}

async function shutdown(signal: string) {
  if (stopping) return;
  stopping = true;
  logger.info(`${signal} received; stopping deposit credit worker`);
  await pool.end();
  process.exit(0);
}

process.on("SIGINT", () => void shutdown("SIGINT"));
process.on("SIGTERM", () => void shutdown("SIGTERM"));
process.on("unhandledRejection", (reason) => {
  logger.error("Deposit credit worker unhandled rejection", reason);
});
process.on("uncaughtException", (error) => {
  logger.error("Deposit credit worker uncaught exception", error);
  void shutdown("UNCAUGHT_EXCEPTION");
});

run().catch(async (error) => {
  logger.error("Deposit credit worker failed", error);
  await pool.end();
  process.exit(1);
});
