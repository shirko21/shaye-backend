import os from "node:os";
import { blockchainConfig } from "../config/blockchain";
import { pool } from "../config/database";
import { runMigrations } from "../db/migrate";
import {
  recoverExpiredBlockchainJobs,
  syncBlockchainSettingsFromRuntime,
} from "../services/blockchain-database.service";
import { runDepositWatcherCycle } from "../services/deposit-watcher.service";
import { destroyBlockchainProvider } from "../services/blockchain.service";
import { logger } from "../utils/logger";

const sleep = (milliseconds: number) =>
  new Promise<void>((resolve) => setTimeout(resolve, milliseconds));

const instanceId = `${os.hostname()}:${process.pid}`;
let stopping = false;

async function run() {
  await runMigrations();
  await syncBlockchainSettingsFromRuntime();
  const recoveredJobs = await recoverExpiredBlockchainJobs();
  if (recoveredJobs > 0) {
    logger.warn(`Recovered ${recoveredJobs} expired blockchain job leases`);
  }

  logger.info(
    `Blockchain deposit watcher started (${blockchainConfig.network.name}, chain ${blockchainConfig.network.chainId}, instance ${instanceId})`,
  );

  if (!blockchainConfig.enabled || !blockchainConfig.depositScannerEnabled) {
    logger.warn(
      "Automatic deposit detection is paused. It must only be enabled after Testnet RPC, token contract and deposit wallets are configured.",
    );
  }

  while (!stopping) {
    try {
      const result = await runDepositWatcherCycle(instanceId);
      if (result.status === "scanned") {
        logger.info(
          `Deposit scan ${result.fromBlock}-${result.toBlock}: detected=${result.detected} confirmationsUpdated=${result.confirmed} orphaned=${result.orphaned} latest=${result.latestBlock}`,
        );
      } else {
        logger.warn(`Deposit watcher ${result.status}: ${result.message || "idle"}`);
      }
    } catch (error) {
      logger.error("Deposit watcher cycle failed", error);
    }

    await sleep(blockchainConfig.watcherIntervalMs);
  }
}

async function shutdown(signal: string) {
  if (stopping) return;
  stopping = true;
  logger.info(`${signal} received; stopping blockchain deposit watcher`);
  await destroyBlockchainProvider();
  await pool.end();
  process.exit(0);
}

process.on("SIGINT", () => void shutdown("SIGINT"));
process.on("SIGTERM", () => void shutdown("SIGTERM"));
process.on("unhandledRejection", (reason) => {
  logger.error("Blockchain watcher unhandled rejection", reason);
});
process.on("uncaughtException", (error) => {
  logger.error("Blockchain watcher uncaught exception", error);
  void shutdown("UNCAUGHT_EXCEPTION");
});

run().catch(async (error) => {
  logger.error("Blockchain watcher failed", error);
  await destroyBlockchainProvider();
  await pool.end();
  process.exit(1);
});
