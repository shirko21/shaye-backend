import os from "node:os";
import process from "node:process";
import { env } from "../env";
import { pool } from "../config/database";
import { runMigrations } from "../db/migrate";
import { syncBlockchainSettingsFromRuntime } from "../services/blockchain-database.service";
import {
  clearWalletSweeperSecrets,
  recordSweepWorkerError,
  runSweepWorkerCycle,
} from "../services/wallet-sweeper.service";
import { destroyBlockchainProvider } from "../services/blockchain.service";
import { logger } from "../utils/logger";

const instanceId = `sweep-worker:${os.hostname()}:${process.pid}`;
let stopping = false;

async function sleep(ms: number) {
  await new Promise((resolve) => setTimeout(resolve, ms));
}

async function main() {
  await runMigrations();
  await syncBlockchainSettingsFromRuntime();
  logger.info(`${instanceId} started`);
  while (!stopping) {
    try {
      const result = await runSweepWorkerCycle(instanceId);
      if (result.processed > 0 || result.discovered > 0) {
        logger.info(`${instanceId} cycle`, result);
      }
    } catch (error) {
      logger.error(`${instanceId} cycle failed`, error);
      try {
        await recordSweepWorkerError(instanceId, error);
      } catch (statusError) {
        logger.error(`${instanceId} could not persist worker error status`, statusError);
      }
    }
    await sleep(env.BLOCKCHAIN_SWEEP_WORKER_INTERVAL_MS);
  }
}

async function shutdown(signal: string) {
  if (stopping) return;
  stopping = true;
  logger.info(`${instanceId} received ${signal}`);
  clearWalletSweeperSecrets();
  await destroyBlockchainProvider();
  await pool.end();
  process.exit(0);
}

process.on("SIGINT", () => void shutdown("SIGINT"));
process.on("SIGTERM", () => void shutdown("SIGTERM"));

main().catch(async (error) => {
  logger.error(`${instanceId} failed`, error);
  clearWalletSweeperSecrets();
  await destroyBlockchainProvider();
  await pool.end();
  process.exit(1);
});
