import "dotenv/config";
import { z } from "zod";

const booleanString = z
  .string()
  .default("false")
  .transform((value) => value.toLowerCase() === "true");

const optionalUrl = z.preprocess(
  (value) => (typeof value === "string" && value.trim() === "" ? undefined : value),
  z.string().url().optional(),
);

const optionalAddress = z.preprocess(
  (value) => (typeof value === "string" && value.trim() === "" ? undefined : value),
  z.string().regex(/^0x[a-fA-F0-9]{40}$/).optional(),
);

const optionalInteger = (minimum: number, maximum: number) =>
  z.preprocess(
    (value) => (typeof value === "string" && value.trim() === "" ? undefined : value),
    z.coerce.number().int().min(minimum).max(maximum).optional(),
  );

const envSchema = z.object({
  NODE_ENV: z
    .enum(["development", "test", "production"])
    .default("development"),
  PORT: z.coerce.number().int().min(1).max(65535).default(5000),
  DATABASE_URL: z.string().min(1),
  DATABASE_SSL: booleanString,
  JWT_SECRET: z.string().min(32),
  JWT_EXPIRES: z.string().default("7d"),
  COOKIE_NAME: z.string().default("shaye_token"),
  FRONTEND_URL: z.string().default("http://localhost:5000"),
  SERVE_FRONTEND: z
    .string()
    .default("true")
    .transform((value) => value.toLowerCase() === "true"),
  FRONTEND_PATH: z.string().default("../../frontend"),
  TRUST_PROXY: z.coerce.number().int().min(0).max(3).default(0),
  ADMIN_EMAIL: z.string().email(),
  ADMIN_PASSWORD: z.string().min(8),
  TIMEZONE: z.string().default("Asia/Tehran"),
  DEPOSIT_WALLET_ADDRESS: optionalAddress,
  BLOCKCHAIN_ENABLED: booleanString,
  BSC_NETWORK: z.enum(["mainnet", "testnet"]).default("testnet"),
  BSC_RPC_URL: optionalUrl,
  BSC_TOKEN_CONTRACT: optionalAddress,
  BSC_TOKEN_EXPECTED_DECIMALS: optionalInteger(0, 255),
  BLOCKCHAIN_REQUEST_TIMEOUT_MS: z.coerce
    .number()
    .int()
    .min(1_000)
    .max(60_000)
    .default(8_000),
  BLOCKCHAIN_STATUS_CACHE_MS: z.coerce
    .number()
    .int()
    .min(1_000)
    .max(300_000)
    .default(15_000),
  BLOCKCHAIN_WATCHER_INTERVAL_MS: z.coerce
    .number()
    .int()
    .min(5_000)
    .max(300_000)
    .default(15_000),
  BLOCKCHAIN_DEPOSIT_SCANNER_ENABLED: booleanString,
  BLOCKCHAIN_REQUIRED_CONFIRMATIONS: z.coerce
    .number()
    .int()
    .min(1)
    .max(10_000)
    .default(12),
  BLOCKCHAIN_REORG_BUFFER_BLOCKS: z.coerce
    .number()
    .int()
    .min(1)
    .max(10_000)
    .default(24),
  BLOCKCHAIN_SCAN_BATCH_SIZE: z.coerce
    .number()
    .int()
    .min(1)
    .max(5_000)
    .default(500),
  BLOCKCHAIN_ADDRESS_TOPIC_BATCH_SIZE: z.coerce
    .number()
    .int()
    .min(1)
    .max(500)
    .default(100),
  BLOCKCHAIN_INITIAL_LOOKBACK_BLOCKS: z.coerce
    .number()
    .int()
    .min(0)
    .max(2_000_000)
    .default(2_000),
  BLOCKCHAIN_DEPOSIT_SCAN_START_BLOCK: optionalInteger(0, 100_000_000_000),
  BLOCKCHAIN_CURSOR_LEASE_SECONDS: z.coerce
    .number()
    .int()
    .min(15)
    .max(3_600)
    .default(120),
  BLOCKCHAIN_AUTO_CREDIT_ENABLED: booleanString,
  BLOCKCHAIN_CREDIT_WORKER_INTERVAL_MS: z.coerce
    .number()
    .int()
    .min(2_000)
    .max(300_000)
    .default(10_000),
  BLOCKCHAIN_CREDIT_BATCH_SIZE: z.coerce
    .number()
    .int()
    .min(1)
    .max(100)
    .default(20),
  BLOCKCHAIN_CREDIT_JOB_LEASE_SECONDS: z.coerce
    .number()
    .int()
    .min(15)
    .max(3_600)
    .default(120),
  BLOCKCHAIN_WITHDRAWAL_WORKER_ENABLED: booleanString,
  BLOCKCHAIN_WITHDRAWAL_ALLOW_MAINNET: booleanString,
  BLOCKCHAIN_WITHDRAWAL_WORKER_INTERVAL_MS: z.coerce
    .number()
    .int()
    .min(2_000)
    .max(300_000)
    .default(10_000),
  BLOCKCHAIN_WITHDRAWAL_BATCH_SIZE: z.coerce
    .number()
    .int()
    .min(1)
    .max(20)
    .default(5),
  BLOCKCHAIN_WITHDRAWAL_JOB_LEASE_SECONDS: z.coerce
    .number()
    .int()
    .min(15)
    .max(3_600)
    .default(180),
  HOT_WALLET_ADDRESS: optionalAddress,
  HOT_WALLET_PRIVATE_KEY_FILE: z
    .string()
    .default("/run/secrets/hot_wallet_private_key"),
  DEPOSIT_WALLET_ENABLED: booleanString,
  DEPOSIT_WALLET_XPUB_FILE: z.string().default("/run/secrets/deposit_wallet_xpub"),
  DEPOSIT_WALLET_ACCOUNT_PATH: z.string().default("m/44'/60'/0'"),
  DEPOSIT_WALLET_CHANGE_INDEX: z.coerce.number().int().min(0).max(1).default(0),
  BLOCKCHAIN_SWEEP_WORKER_ENABLED: booleanString,
  BLOCKCHAIN_SWEEP_WORKER_INTERVAL_MS: z.coerce
    .number()
    .int()
    .min(5_000)
    .max(300_000)
    .default(20_000),
  BLOCKCHAIN_SWEEP_JOB_LEASE_SECONDS: z.coerce
    .number()
    .int()
    .min(30)
    .max(3_600)
    .default(240),
  DEPOSIT_WALLET_MNEMONIC_FILE: z
    .string()
    .default("/run/secrets/deposit_wallet_mnemonic"),
  GAS_WALLET_ADDRESS: optionalAddress,
  GAS_WALLET_PRIVATE_KEY_FILE: z
    .string()
    .default("/run/secrets/gas_wallet_private_key"),
  TREASURY_WALLET_ADDRESS: optionalAddress,
}).superRefine((value, context) => {
  if (!value.BLOCKCHAIN_ENABLED) return;

  if (!value.BSC_RPC_URL) {
    context.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["BSC_RPC_URL"],
      message: "BSC_RPC_URL is required when blockchain integration is enabled",
    });
  }

  if (!value.BSC_TOKEN_CONTRACT) {
    context.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["BSC_TOKEN_CONTRACT"],
      message: "BSC_TOKEN_CONTRACT is required when blockchain integration is enabled",
    });
  }

  if (value.BLOCKCHAIN_WITHDRAWAL_WORKER_ENABLED && !value.HOT_WALLET_ADDRESS) {
    context.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["HOT_WALLET_ADDRESS"],
      message: "HOT_WALLET_ADDRESS is required when the withdrawal worker is enabled",
    });
  }

  if (
    value.BLOCKCHAIN_WITHDRAWAL_WORKER_ENABLED &&
    value.BSC_NETWORK === "mainnet"
  ) {
    context.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["BSC_NETWORK"],
      message: "Stage 8 withdrawal execution is hard-blocked on Mainnet",
    });
  }

  if (value.BLOCKCHAIN_SWEEP_WORKER_ENABLED) {
    if (!value.GAS_WALLET_ADDRESS) {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["GAS_WALLET_ADDRESS"],
        message: "GAS_WALLET_ADDRESS is required when the sweep worker is enabled",
      });
    }
    if (!value.TREASURY_WALLET_ADDRESS) {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["TREASURY_WALLET_ADDRESS"],
        message: "TREASURY_WALLET_ADDRESS is required when the sweep worker is enabled",
      });
    }
    if (value.BSC_NETWORK === "mainnet") {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["BSC_NETWORK"],
        message: "Stage 8 sweep execution is hard-blocked on Mainnet",
      });
    }
  }
});

const parsed = envSchema.safeParse(process.env);
if (!parsed.success) {
  console.error(
    "Invalid environment variables:",
    parsed.error.flatten().fieldErrors,
  );
  throw new Error("Environment validation failed");
}

export const env = parsed.data;
