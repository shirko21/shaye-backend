import assert from "node:assert/strict";
import { pool, query } from "../config/database";
import {
  deriveConfiguredDepositAddress,
  getConfiguredDepositWalletFingerprint,
  inspectDepositWalletConfiguration,
} from "../services/deposit-wallet.service";

async function main() {
  const configuration = inspectDepositWalletConfiguration();
  const fingerprint = getConfiguredDepositWalletFingerprint();
  assert.equal(configuration.xpubFingerprint, fingerprint);

  const result = await query<{
    id: string;
    address: string;
    derivation_index: string;
    key_fingerprint: string;
  }>(
    `SELECT id, address, derivation_index::text, key_fingerprint
     FROM blockchain_wallets
     WHERE purpose = 'DEPOSIT'
       AND chain_id = $1
       AND status <> 'ARCHIVED'
     ORDER BY derivation_index ASC
     LIMIT 500`,
    [configuration.chainId],
  );

  for (const row of result.rows) {
    const expected = deriveConfiguredDepositAddress(Number(row.derivation_index));
    assert.equal(row.address.toLowerCase(), expected.toLowerCase());
    assert.equal(row.key_fingerprint, fingerprint);
  }

  console.log(
    JSON.stringify(
      {
        success: true,
        configuration,
        checkedWallets: result.rowCount || 0,
        message: "Deposit wallet configuration and database addresses are consistent.",
      },
      null,
      2,
    ),
  );
}

main()
  .catch((error) => {
    console.error(error instanceof Error ? error.message : error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await pool.end();
  });
