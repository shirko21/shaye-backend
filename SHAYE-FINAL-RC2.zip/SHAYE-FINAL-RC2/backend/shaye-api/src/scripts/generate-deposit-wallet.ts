import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { HDNodeWallet, Mnemonic, randomBytes } from "ethers";

const outputDir = path.resolve(process.env.WALLET_OUTPUT_DIR || "/wallet-secrets");
const accountPath = process.env.DEPOSIT_WALLET_ACCOUNT_PATH || "m/44'/60'/0'";

function writeSecret(filename: string, value: string): string {
  fs.mkdirSync(outputDir, { recursive: true, mode: 0o700 });
  const target = path.join(outputDir, filename);

  if (fs.existsSync(target) && fs.statSync(target).size > 0) {
    throw new Error(`${filename} already exists and will not be overwritten`);
  }

  const temporary = `${target}.tmp-${process.pid}`;
  fs.writeFileSync(temporary, `${value.trim()}\n`, {
    encoding: "utf8",
    mode: 0o600,
    flag: "wx",
  });
  fs.renameSync(temporary, target);
  fs.chmodSync(target, 0o600);
  return target;
}

const mnemonic = Mnemonic.fromEntropy(randomBytes(32));
const account = HDNodeWallet.fromPhrase(mnemonic.phrase, undefined, accountPath);
const xpub = account.neuter().extendedKey;
const fingerprint = crypto
  .createHash("sha256")
  .update(xpub)
  .digest("hex")
  .slice(0, 32);
const firstAddress = account.neuter().derivePath("0/0").address;

const mnemonicFile = writeSecret("deposit_wallet_mnemonic", mnemonic.phrase);
const xpubFile = writeSecret("deposit_wallet_xpub", xpub);
const fingerprintFile = writeSecret("deposit_wallet_fingerprint", fingerprint);
const metadataFile = writeSecret(
  "deposit_wallet_metadata",
  JSON.stringify(
    {
      createdAt: new Date().toISOString(),
      accountPath,
      changeIndex: 0,
      xpubFingerprint: fingerprint,
      firstAddress,
    },
    null,
    2,
  ),
);

console.log(
  JSON.stringify(
    {
      success: true,
      accountPath,
      xpubFingerprint: fingerprint,
      firstAddress,
      files: {
        mnemonic: mnemonicFile,
        xpub: xpubFile,
        fingerprint: fingerprintFile,
        metadata: metadataFile,
      },
    },
    null,
    2,
  ),
);
