import { blockchainConfig } from "../config/blockchain";
import { pool } from "../config/database";
import { runMigrations } from "../db/migrate";
import {
  getBlockchainControls,
  syncBlockchainSettingsFromRuntime,
} from "../services/blockchain-database.service";
import { getDepositWatcherStatus } from "../services/deposit-watcher.service";
import {
  destroyBlockchainProvider,
  getBlockchainStatus,
} from "../services/blockchain.service";

async function run() {
  await runMigrations();
  await syncBlockchainSettingsFromRuntime();

  const [chain, controls, watcher] = await Promise.all([
    getBlockchainStatus({ forceRefresh: true }),
    getBlockchainControls(),
    getDepositWatcherStatus(),
  ]);

  const worker = watcher.worker as
    | { status?: string; heartbeat_at?: string | Date; last_error?: string | null }
    | null;
  const success = Boolean(
    chain.healthy &&
      blockchainConfig.depositScannerEnabled &&
      controls.depositsEnabled &&
      !controls.emergencyStop &&
      worker &&
      worker.status !== "ERROR",
  );

  console.log(
    JSON.stringify(
      {
        success,
        network: chain.network,
        chainId: chain.actualChainId,
        latestBlock: chain.latestBlock,
        token: chain.token,
        scannerEnvironmentEnabled: blockchainConfig.depositScannerEnabled,
        depositsEnabled: controls.depositsEnabled,
        emergencyStop: controls.emergencyStop,
        worker,
        cursor: watcher.cursor,
        depositCounts: watcher.depositCounts,
      },
      null,
      2,
    ),
  );

  if (!success) process.exitCode = 1;
}

run()
  .catch((error) => {
    console.error(error instanceof Error ? error.message : error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await destroyBlockchainProvider();
    await pool.end();
  });
