import fs from "fs";
import { Wallet } from "ethers";

const file =
  process.env.HOT_WALLET_PRIVATE_KEY_FILE ||
  "/run/secrets/hot_wallet_private_key";
const privateKey = fs.readFileSync(file, "utf8").trim();
if (!/^0x[0-9a-fA-F]{64}$/.test(privateKey)) {
  throw new Error("Hot wallet private key secret is invalid");
}
const wallet = new Wallet(privateKey);
process.stdout.write(`${wallet.address}\n`);
