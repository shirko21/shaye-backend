import { pool, query } from "../config/database";
import { runMigrations } from "../db/migrate";
import { getAutomaticWithdrawalSettings } from "../services/automatic-withdrawal.service";

async function main() {
  await runMigrations();
  const columns = await query<{ column_name: string }>(
    `SELECT column_name
     FROM information_schema.columns
     WHERE table_schema='public'
       AND table_name='blockchain_settings'
       AND column_name IN (
         'auto_withdrawals_enabled','auto_withdrawal_max_amount',
         'auto_withdrawal_daily_limit','auto_withdrawal_daily_count_limit',
         'auto_withdrawal_max_concurrent','hot_wallet_min_token_reserve',
         'hot_wallet_min_bnb_reserve'
       )`,
  );
  const table = await query<{ exists: boolean }>(
    `SELECT to_regclass('public.withdrawal_auto_daily_usage') IS NOT NULL AS exists`,
  );
  const settings = await getAutomaticWithdrawalSettings();
  const success = columns.rows.length === 7 && Boolean(table.rows[0]?.exists);
  console.log(JSON.stringify({ success, columns: columns.rows.map((x) => x.column_name).sort(), settings }, null, 2));
  if (!success) process.exitCode = 1;
}

main()
  .catch((error) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await pool.end();
  });
