import { pool } from "../config/database";
import { runMigrations } from "../db/migrate";
import { getDepositCreditStatus } from "../services/deposit-credit.service";

async function main() {
  await runMigrations();
  const status = await getDepositCreditStatus();
  const success =
    status.environmentEnabled &&
    status.databaseEnabled &&
    status.fundingMode === "BLOCKCHAIN" &&
    !status.emergencyStop &&
    Boolean(status.worker) &&
    ["HEALTHY", "IDLE"].includes(String(status.worker?.status));

  console.log(JSON.stringify({ success, ...status }, null, 2));
  process.exitCode = success ? 0 : 1;
}

main()
  .catch((error) => {
    console.error(error instanceof Error ? error.message : error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await pool.end();
  });
