import fs from "node:fs";
import { Wallet } from "ethers";

const file = process.env.GAS_WALLET_PRIVATE_KEY_FILE || "/run/secrets/gas_wallet_private_key";
const value = fs.readFileSync(file, "utf8").trim();
if (!/^0x[0-9a-fA-F]{64}$/.test(value)) {
  throw new Error("Gas wallet private key is empty or invalid");
}
console.log(new Wallet(value).address);
