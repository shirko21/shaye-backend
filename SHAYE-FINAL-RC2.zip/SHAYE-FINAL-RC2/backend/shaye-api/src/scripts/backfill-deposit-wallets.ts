import { pool, query } from "../config/database";
import { ensureUserDepositWallet } from "../services/deposit-wallet.service";

async function main() {
  const users = await query<{ id: string; email: string }>(
    `SELECT id, email
     FROM users
     WHERE role = 'USER' AND is_active = TRUE
     ORDER BY created_at ASC`,
  );

  let createdOrVerified = 0;
  const failures: Array<{ userId: string; email: string; error: string }> = [];

  for (const user of users.rows) {
    try {
      await ensureUserDepositWallet(user.id);
      createdOrVerified += 1;
    } catch (error) {
      failures.push({
        userId: user.id,
        email: user.email,
        error: error instanceof Error ? error.message : String(error),
      });
    }
  }

  console.log(
    JSON.stringify(
      {
        success: failures.length === 0,
        totalUsers: users.rowCount || 0,
        createdOrVerified,
        failures,
      },
      null,
      2,
    ),
  );

  if (failures.length > 0) process.exitCode = 1;
}

main()
  .catch((error) => {
    console.error(error instanceof Error ? error.message : error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await pool.end();
  });
