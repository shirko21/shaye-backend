import { pool } from "../config/database";
import { runMigrations } from "../db/migrate";
import { getSweeperSettings } from "../services/wallet-sweeper.service";

async function main() {
  await runMigrations();
  const settings = await getSweeperSettings();
  console.log(JSON.stringify({ success: true, data: settings }, null, 2));
}

main()
  .catch((error) => {
    console.error(JSON.stringify({ success: false, error: error.message }, null, 2));
    process.exitCode = 1;
  })
  .finally(async () => {
    await pool.end();
  });
