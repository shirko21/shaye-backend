import fs from "node:fs";
import path from "node:path";
import { Wallet } from "ethers";

const outputDir = path.resolve(process.env.WALLET_OUTPUT_DIR || "/wallet-secrets");
fs.mkdirSync(outputDir, { recursive: true, mode: 0o700 });
const keyFile = path.join(outputDir, "gas_wallet_private_key");
const addressFile = path.join(outputDir, "gas_wallet_address");

if (fs.existsSync(keyFile) && fs.statSync(keyFile).size > 0) {
  throw new Error("gas_wallet_private_key already exists and will not be overwritten");
}

const wallet = Wallet.createRandom();
fs.writeFileSync(keyFile, `${wallet.privateKey}\n`, { mode: 0o600, flag: "wx" });
fs.writeFileSync(addressFile, `${wallet.address}\n`, { mode: 0o600, flag: "wx" });
fs.chmodSync(keyFile, 0o600);
fs.chmodSync(addressFile, 0o600);
console.log(JSON.stringify({ success: true, address: wallet.address }, null, 2));
