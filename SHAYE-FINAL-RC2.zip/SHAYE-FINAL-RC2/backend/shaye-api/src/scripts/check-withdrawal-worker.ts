import { query, pool } from "../config/database";
import { getWithdrawalExecutionStatus } from "../services/withdrawal-execution.service";
import { destroyBlockchainProvider } from "../services/blockchain.service";

async function main() {
  const status = await getWithdrawalExecutionStatus();
  const migration = await query(
    `SELECT
       to_regclass('public.referral_wheel_grants') IS NOT NULL AS wheel_grants,
       EXISTS(
         SELECT 1 FROM information_schema.columns
         WHERE table_name='blockchain_withdrawals'
           AND column_name='raw_transaction'
       ) AS raw_transaction,
       EXISTS(
         SELECT 1 FROM information_schema.columns
         WHERE table_name='blockchain_settings'
           AND column_name='withdrawal_worker_enabled'
       ) AS worker_setting`,
  );
  const schema = migration.rows[0];
  const success =
    Boolean(schema?.wheel_grants) &&
    Boolean(schema?.raw_transaction) &&
    Boolean(schema?.worker_setting);

  console.log(
    JSON.stringify(
      {
        success,
        schema,
        runtime: status,
      },
      null,
      2,
    ),
  );
  if (!success) process.exitCode = 1;
}

main()
  .catch((error) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await destroyBlockchainProvider();
    await pool.end();
  });
