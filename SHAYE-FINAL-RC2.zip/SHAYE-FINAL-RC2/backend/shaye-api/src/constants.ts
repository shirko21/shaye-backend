export const APP_VERSION = "3.0.0-rc2";
export const API_PREFIX = "/api";
export const MAX_MONEY = 1_000_000_000;
