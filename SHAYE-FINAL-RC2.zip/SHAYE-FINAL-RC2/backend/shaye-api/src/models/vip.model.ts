export type VipLevel = number;
