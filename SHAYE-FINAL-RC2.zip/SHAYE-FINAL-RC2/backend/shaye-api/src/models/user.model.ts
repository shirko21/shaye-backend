export type { Role, UserRow } from "../db/types";
