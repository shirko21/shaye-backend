export type ReferralLevel = 1 | 2;
