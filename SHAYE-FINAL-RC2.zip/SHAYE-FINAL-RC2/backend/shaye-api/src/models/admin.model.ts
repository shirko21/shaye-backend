export type AdminAction = string;
