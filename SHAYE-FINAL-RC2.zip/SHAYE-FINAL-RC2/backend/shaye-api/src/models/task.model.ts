export type TaskWindowDto = { key: string; startsAt: Date; endsAt: Date; isOpen: boolean };
