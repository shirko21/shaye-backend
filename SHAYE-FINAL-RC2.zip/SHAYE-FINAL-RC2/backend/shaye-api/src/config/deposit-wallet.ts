import path from "node:path";
import { env } from "../env";

export const depositWalletConfig = {
  enabled: env.DEPOSIT_WALLET_ENABLED,
  xpubFile: path.resolve(env.DEPOSIT_WALLET_XPUB_FILE),
  accountPath: env.DEPOSIT_WALLET_ACCOUNT_PATH,
  changeIndex: env.DEPOSIT_WALLET_CHANGE_INDEX,
} as const;
