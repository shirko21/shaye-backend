import { CorsOptions } from "cors";
import { env } from "../env";

function normalizeOrigin(value: string) {
  return value.trim().replace(/\/+$/, "");
}

const allowedOrigins = new Set(
  env.FRONTEND_URL.split(",")
    .map(normalizeOrigin)
    .filter(Boolean),
);

function isCodespacesTestOrigin(origin: string) {
  return (
    process.env.STAGE9A_TEST_MODE === "true" &&
    /^https:\/\/[a-z0-9-]+-5000\.app\.github\.dev$/i.test(origin)
  );
}

export const corsOptions: CorsOptions = {
  origin(origin, callback) {
    if (!origin) return callback(null, true);
    const normalized = normalizeOrigin(origin);
    if (allowedOrigins.has(normalized) || isCodespacesTestOrigin(normalized)) {
      return callback(null, true);
    }
    return callback(new Error("مبدأ درخواست مجاز نیست."));
  },
  credentials: true,
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"],
};
