export const appConfig = {
  jsonLimit: "12mb",
  requestTimeoutMs: 15_000,
  authRateLimit: { windowMs: 15 * 60 * 1000, limit: 30 },
  apiRateLimit: { windowMs: 60 * 1000, limit: 180 },
};
