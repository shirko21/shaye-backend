import { getAddress } from "ethers";
import { env } from "../env";
import { BscNetworkName } from "../types/blockchain.types";

interface BscNetworkDefinition {
  name: BscNetworkName;
  chainId: number;
  nativeCurrency: "BNB";
  explorerBaseUrl: string;
}

export const BSC_NETWORKS: Record<BscNetworkName, BscNetworkDefinition> = {
  mainnet: {
    name: "mainnet",
    chainId: 56,
    nativeCurrency: "BNB",
    explorerBaseUrl: "https://bscscan.com",
  },
  testnet: {
    name: "testnet",
    chainId: 97,
    nativeCurrency: "BNB",
    explorerBaseUrl: "https://testnet.bscscan.com",
  },
};

const network = BSC_NETWORKS[env.BSC_NETWORK];

export const blockchainConfig = {
  enabled: env.BLOCKCHAIN_ENABLED,
  network,
  rpcUrl: env.BSC_RPC_URL,
  tokenAddress: env.BSC_TOKEN_CONTRACT
    ? getAddress(env.BSC_TOKEN_CONTRACT)
    : undefined,
  expectedTokenDecimals: env.BSC_TOKEN_EXPECTED_DECIMALS,
  requestTimeoutMs: env.BLOCKCHAIN_REQUEST_TIMEOUT_MS,
  statusCacheMs: env.BLOCKCHAIN_STATUS_CACHE_MS,
  watcherIntervalMs: env.BLOCKCHAIN_WATCHER_INTERVAL_MS,
  depositScannerEnabled: env.BLOCKCHAIN_DEPOSIT_SCANNER_ENABLED,
  requiredConfirmations: env.BLOCKCHAIN_REQUIRED_CONFIRMATIONS,
  reorgBufferBlocks: env.BLOCKCHAIN_REORG_BUFFER_BLOCKS,
  scanBatchSize: env.BLOCKCHAIN_SCAN_BATCH_SIZE,
  addressTopicBatchSize: env.BLOCKCHAIN_ADDRESS_TOPIC_BATCH_SIZE,
  initialLookbackBlocks: env.BLOCKCHAIN_INITIAL_LOOKBACK_BLOCKS,
  depositScanStartBlock: env.BLOCKCHAIN_DEPOSIT_SCAN_START_BLOCK,
  cursorLeaseSeconds: env.BLOCKCHAIN_CURSOR_LEASE_SECONDS,
  autoCreditEnabled: env.BLOCKCHAIN_AUTO_CREDIT_ENABLED,
  withdrawalWorkerEnabled: env.BLOCKCHAIN_WITHDRAWAL_WORKER_ENABLED,
  withdrawalAllowMainnet: env.BLOCKCHAIN_WITHDRAWAL_ALLOW_MAINNET,
  withdrawalWorkerIntervalMs: env.BLOCKCHAIN_WITHDRAWAL_WORKER_INTERVAL_MS,
  withdrawalBatchSize: env.BLOCKCHAIN_WITHDRAWAL_BATCH_SIZE,
  withdrawalJobLeaseSeconds: env.BLOCKCHAIN_WITHDRAWAL_JOB_LEASE_SECONDS,
  hotWalletAddress: env.HOT_WALLET_ADDRESS
    ? getAddress(env.HOT_WALLET_ADDRESS)
    : undefined,
  hotWalletPrivateKeyFile: env.HOT_WALLET_PRIVATE_KEY_FILE,
  sweepWorkerEnabled: env.BLOCKCHAIN_SWEEP_WORKER_ENABLED,
  sweepWorkerIntervalMs: env.BLOCKCHAIN_SWEEP_WORKER_INTERVAL_MS,
  sweepJobLeaseSeconds: env.BLOCKCHAIN_SWEEP_JOB_LEASE_SECONDS,
  depositWalletMnemonicFile: env.DEPOSIT_WALLET_MNEMONIC_FILE,
  gasWalletAddress: env.GAS_WALLET_ADDRESS
    ? getAddress(env.GAS_WALLET_ADDRESS)
    : undefined,
  gasWalletPrivateKeyFile: env.GAS_WALLET_PRIVATE_KEY_FILE,
  treasuryWalletAddress: env.TREASURY_WALLET_ADDRESS
    ? getAddress(env.TREASURY_WALLET_ADDRESS)
    : undefined,
  creditWorkerIntervalMs: env.BLOCKCHAIN_CREDIT_WORKER_INTERVAL_MS,
  creditBatchSize: env.BLOCKCHAIN_CREDIT_BATCH_SIZE,
  creditJobLeaseSeconds: env.BLOCKCHAIN_CREDIT_JOB_LEASE_SECONDS,
  configured: Boolean(env.BSC_RPC_URL && env.BSC_TOKEN_CONTRACT),
} as const;
