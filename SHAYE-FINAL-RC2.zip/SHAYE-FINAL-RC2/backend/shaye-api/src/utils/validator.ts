import { z } from "zod";
import { MAX_MONEY } from "../constants";

export const emailSchema = z
  .string()
  .trim()
  .toLowerCase()
  .email()
  .max(254);

export const passwordSchema = z.string().min(8).max(128);

export const amountSchema = z.coerce
  .number()
  .finite()
  .positive()
  .max(MAX_MONEY);

export const walletAddressSchema = z
  .string()
  .trim()
  .regex(/^0x[a-fA-F0-9]{40}$/, "آدرس کیف پول BEP20 معتبر نیست");

export const timezoneSchema = z
  .string()
  .min(3)
  .max(64)
  .refine((value) => {
    try {
      new Intl.DateTimeFormat("en-US", { timeZone: value }).format();
      return true;
    } catch {
      return false;
    }
  }, "منطقه زمانی معتبر نیست");
