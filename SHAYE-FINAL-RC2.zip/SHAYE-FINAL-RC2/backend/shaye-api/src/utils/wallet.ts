export const percentage = (base: unknown, rate: unknown) => Math.round(Number(base) * Number(rate) / 100 * 1_000_000) / 1_000_000;
