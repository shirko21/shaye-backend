import crypto from "crypto";
export const money = (value: unknown) => Math.round(Number(value) * 1_000_000) / 1_000_000;
export const randomId = () => crypto.randomUUID();
export const randomCode = (prefix: string, bytes = 6) => `${prefix}-${crypto.randomBytes(bytes).toString("hex").toUpperCase()}`;
export const normalizeEmail = (value: string) => value.trim().toLowerCase();
export const normalizeInviteCode = (value?: string | null) => value?.trim().toUpperCase() || null;
export const mapUser = (r:any) => ({
  id:r.id,email:r.email,inviteCode:r.invite_code,referredById:r.referred_by_id,
  role:r.role,vipLevel:Number(r.vip_level||0),depositBalance:Number(r.deposit_balance||0),
  profitBalance:Number(r.profit_balance||0),lockedBalance:Number(r.locked_balance||0),
  totalDeposit:Number(r.total_deposit||0),totalWithdraw:Number(r.total_withdraw||0),
  totalProfit:Number(r.total_profit||0),referralProfit:Number(r.referral_profit||0),
  walletAddress:r.wallet_address||"",wheelSpins:Number(r.wheel_spins||0),
  wheelSpinsUsed:Number(r.wheel_spins_used||0),isActive:r.is_active,
  lastSeenAt:r.last_seen_at||null,createdAt:r.created_at,updatedAt:r.updated_at
});
export const mapSetting = (r:any) => ({
  id:r.id,platformName:r.platform_name,sandboxMode:Boolean(r.sandbox_mode),
  fundingMode:r.funding_mode||"MANUAL",depositWalletAddress:r.deposit_wallet_address||"",
  depositNetwork:r.deposit_network||"BEP20",minDeposit:Number(r.min_deposit),
  minWithdrawal:Number(r.min_withdrawal),lockDays:r.lock_days,
  level1ReferralRate:Number(r.level1_referral_rate),level2ReferralRate:Number(r.level2_referral_rate),
  taskHour:r.task_hour,timezone:r.timezone,maintenanceMode:r.maintenance_mode,
  supportUrl:r.support_url,serverTime:new Date().toISOString(),createdAt:r.created_at,updatedAt:r.updated_at
});
export const mapTier = (r:any) => ({id:r.id,level:r.level,label:r.label,minLocked:Number(r.min_locked),dailyRate:Number(r.daily_rate),minWithdrawal:Number(r.min_withdrawal),isActive:r.is_active,createdAt:r.created_at,updatedAt:r.updated_at});
