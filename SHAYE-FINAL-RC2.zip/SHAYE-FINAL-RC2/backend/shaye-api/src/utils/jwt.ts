import jwt, { SignOptions } from "jsonwebtoken";
import { jwtConfig } from "../config/jwt";
import { Role } from "../db/types";
export interface AuthTokenPayload { userId:string; email:string; role:Role; }
export const signAuthToken=(payload:AuthTokenPayload)=>jwt.sign(payload,jwtConfig.secret,{expiresIn:jwtConfig.expiresIn as SignOptions["expiresIn"]});
export const verifyAuthToken=(token:string)=>jwt.verify(token,jwtConfig.secret) as AuthTokenPayload;
