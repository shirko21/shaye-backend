const POSITIVE_DECIMAL_PATTERN = /^(?:0|[1-9]\d*)(?:\.\d{1,18})?$/;
const ZERO_DECIMAL_PATTERN = /^0(?:\.0+)?$/;

export function assertPositiveDecimal(value: string): void {
  if (!POSITIVE_DECIMAL_PATTERN.test(value) || ZERO_DECIMAL_PATTERN.test(value)) {
    throw new Error(`Invalid positive decimal amount: ${value}`);
  }
}
