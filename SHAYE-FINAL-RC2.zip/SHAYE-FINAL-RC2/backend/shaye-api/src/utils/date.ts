import { addDays } from "date-fns";
import { formatInTimeZone, fromZonedTime, toZonedTime } from "date-fns-tz";

export function dateKey(date = new Date(), timezone = "Asia/Tehran"): string {
  return formatInTimeZone(date, timezone, "yyyy-MM-dd");
}

export function taskWindow(now: Date, timezone: string, taskHour: number) {
  const localNow = toZonedTime(now, timezone);
  const startLocal = new Date(
    localNow.getFullYear(),
    localNow.getMonth(),
    localNow.getDate(),
    taskHour,
    0,
    0,
    0,
  );
  if (localNow.getTime() < startLocal.getTime()) startLocal.setDate(startLocal.getDate() - 1);
  const endLocal = addDays(startLocal, 1);
  const startsAt = fromZonedTime(startLocal, timezone);
  const endsAt = fromZonedTime(endLocal, timezone);
  return {
    key: formatInTimeZone(startsAt, timezone, "yyyy-MM-dd"),
    startsAt,
    endsAt,
    isOpen: now >= startsAt && now < endsAt,
  };
}
