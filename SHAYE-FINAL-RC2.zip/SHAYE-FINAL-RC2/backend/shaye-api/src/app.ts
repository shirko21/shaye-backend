import express from "express";
import path from "path";
import cors from "cors";
import helmet from "helmet";
import compression from "compression";
import cookieParser from "cookie-parser";
import morgan from "morgan";
import { env } from "./env";
import { corsOptions } from "./config/cors";
import { appConfig } from "./config/app";
import { apiLimiter } from "./middlewares/rateLimit.middleware";
import {
  errorHandler,
  notFoundHandler,
} from "./middlewares/error.middleware";
import routes from "./routes";
import { API_PREFIX, APP_VERSION } from "./constants";
import { pool } from "./config/database";
import { getBlockchainStatus } from "./services/blockchain.service";

const app = express();
app.disable("x-powered-by");
app.set("trust proxy", env.TRUST_PROXY);

app.use(
  helmet({
    crossOriginEmbedderPolicy: false,
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://cdn.jsdelivr.net"],
        imgSrc: ["'self'", "data:", "https:"],
        connectSrc: ["'self'"],
        fontSrc: ["'self'", "data:", "https://cdn.jsdelivr.net"],
        objectSrc: ["'none'"],
        baseUri: ["'self'"],
        frameAncestors: ["'none'"],
        formAction: ["'self'"],
        upgradeInsecureRequests: env.NODE_ENV === "production" ? [] : null,
      },
    },
  }),
);
app.use(compression());
app.use(cors(corsOptions));
app.use(morgan(env.NODE_ENV === "production" ? "combined" : "dev"));
app.use(express.json({ limit: appConfig.jsonLimit }));
app.use(
  express.urlencoded({
    extended: false,
    limit: appConfig.jsonLimit,
  }),
);
app.use(cookieParser());

app.get("/health", (_req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.json({
    success: true,
    project: "SHAYE",
    version: APP_VERSION,
    status: "running",
    uptimeSeconds: Math.floor(process.uptime()),
    time: new Date().toISOString(),
  });
});

app.get("/ready", async (_req, res, next) => {
  try {
    await pool.query("SELECT 1");
    res.setHeader("Cache-Control", "no-store");
    res.json({ success: true, status: "ready" });
  } catch (error) {
    next(error);
  }
});

app.get("/health/blockchain", async (_req, res, next) => {
  try {
    const status = await getBlockchainStatus();
    res.setHeader("Cache-Control", "no-store");
    res.status(status.enabled && !status.healthy ? 503 : 200).json({
      success: !status.enabled || status.healthy,
      data: status,
    });
  } catch (error) {
    next(error);
  }
});

app.use(API_PREFIX, apiLimiter, routes);

if (env.SERVE_FRONTEND) {
  const frontendPath = path.resolve(process.cwd(), env.FRONTEND_PATH);

  app.use(
    express.static(frontendPath, {
      extensions: ["html"],
      maxAge:
        process.env.STAGE9A_TEST_MODE === "true"
          ? 0
          : env.NODE_ENV === "production"
            ? "1h"
            : 0,
      setHeaders(res, filePath) {
        if (process.env.STAGE9A_TEST_MODE === "true") {
          res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
          res.setHeader("Pragma", "no-cache");
          res.setHeader("Expires", "0");
        } else if (filePath.endsWith(".html")) {
          res.setHeader("Cache-Control", "no-cache");
        }
      },
    }),
  );

  app.get("*", (req, res, next) => {
    if (
      req.path.startsWith(API_PREFIX) ||
      req.path === "/health" ||
      req.path === "/ready" ||
      req.path === "/health/blockchain"
    ) {
      return next();
    }
    return res.sendFile(path.join(frontendPath, "index.html"));
  });
} else {
  app.use(notFoundHandler);
}

app.use(errorHandler);
export default app;
