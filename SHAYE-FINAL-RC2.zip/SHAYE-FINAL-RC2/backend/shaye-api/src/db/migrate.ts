import fs from "fs/promises";
import path from "path";
import { pool, withTransaction } from "../config/database";
import { logger } from "../utils/logger";

export async function runMigrations() {
  await pool.query(`CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT now())`);
  const dir = path.resolve(process.cwd(), "db/migrations");
  const files = (await fs.readdir(dir)).filter((name) => name.endsWith(".sql")).sort();
  const applied = new Set((await pool.query<{name:string}>("SELECT name FROM schema_migrations")).rows.map((r) => r.name));
  for (const name of files) {
    if (applied.has(name)) continue;
    const sql = await fs.readFile(path.join(dir, name), "utf8");
    await withTransaction(async (client) => {
      await client.query(sql);
      await client.query("INSERT INTO schema_migrations(name) VALUES($1)", [name]);
    });
    logger.info("Applied migration", name);
  }
}
