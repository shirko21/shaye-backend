export const BLOCKCHAIN_JOB_TYPES = [
  "SCAN_DEPOSITS",
  "CONFIRM_DEPOSIT",
  "CREDIT_DEPOSIT",
  "PREPARE_WITHDRAWAL",
  "SEND_WITHDRAWAL",
  "CONFIRM_WITHDRAWAL",
  "FUND_GAS",
  "SWEEP_TOKEN",
  "RECONCILE",
] as const;

export type BlockchainJobType = (typeof BLOCKCHAIN_JOB_TYPES)[number];
export type BlockchainJobStatus =
  | "PENDING"
  | "RUNNING"
  | "RETRY"
  | "COMPLETED"
  | "FAILED"
  | "CANCELLED";

export type BlockchainDepositStatus =
  | "DETECTED"
  | "CONFIRMING"
  | "CONFIRMED"
  | "CREDITED"
  | "ORPHANED"
  | "IGNORED"
  | "FAILED"
  | "REVIEW_REQUIRED";

export type BlockchainWithdrawalStatus =
  | "AWAITING_APPROVAL"
  | "QUEUED"
  | "RESERVED"
  | "SIGNING"
  | "BROADCASTED"
  | "CONFIRMING"
  | "CONFIRMED"
  | "COMPLETED"
  | "FAILED"
  | "REVIEW_REQUIRED"
  | "CANCELLED"
  | "REPLACED";

export type WalletSweepStatus =
  | "QUEUED"
  | "DISCOVERED"
  | "GAS_REQUIRED"
  | "GAS_SIGNING"
  | "GAS_SENT"
  | "GAS_CONFIRMING"
  | "TOKEN_SIGNING"
  | "BROADCASTED"
  | "CONFIRMING"
  | "COMPLETED"
  | "FAILED"
  | "REVIEW_REQUIRED"
  | "CANCELLED";

export type LedgerDirection = "DEBIT" | "CREDIT";
export type LedgerAccountType =
  | "ASSET"
  | "LIABILITY"
  | "EQUITY"
  | "REVENUE"
  | "EXPENSE";

export interface BlockchainControls {
  network: "testnet" | "mainnet";
  chainId: number;
  tokenContract: string | null;
  tokenSymbol: string;
  tokenDecimals: number;
  requiredConfirmations: number;
  reorgBufferBlocks: number;
  scanBatchSize: number;
  depositsEnabled: boolean;
  withdrawalsEnabled: boolean;
  sweepsEnabled: boolean;
  sweepWorkerEnabled: boolean;
  sweepMinAmount: number;
  sweepDiscoveryBatchSize: number;
  sweepJobBatchSize: number;
  sweepMaxConcurrent: number;
  sweepTargetGasBnb: number;
  sweepGasWalletMinBnbReserve: number;
  sweepPauseReason: string | null;
  sweepPausedAt: Date | null;
  autoCreditEnabled: boolean;
  withdrawalWorkerEnabled: boolean;
  withdrawalApprovalRequired: boolean;
  autoWithdrawalsEnabled: boolean;
  autoWithdrawalMaxAmount: number;
  autoWithdrawalDailyLimit: number;
  autoWithdrawalDailyCountLimit: number;
  autoWithdrawalMaxConcurrent: number;
  hotWalletMinTokenReserve: number;
  hotWalletMinBnbReserve: number;
  autoWithdrawalPauseReason: string | null;
  autoWithdrawalPausedAt: Date | null;
  emergencyStop: boolean;
  emergencyReason: string | null;
  updatedAt: Date;
}

export interface BlockchainJobRow {
  id: string;
  job_type: BlockchainJobType;
  idempotency_key: string;
  payload: Record<string, unknown>;
  status: BlockchainJobStatus;
  priority: number;
  attempts: number;
  max_attempts: number;
  run_after: Date;
  locked_by: string | null;
  locked_at: Date | null;
  lock_expires_at: Date | null;
  last_error: string | null;
  result: Record<string, unknown> | null;
  completed_at: Date | null;
  created_at: Date;
  updated_at: Date;
}

export interface LedgerPostingEntry {
  accountId: string;
  direction: LedgerDirection;
  amount: string;
  userId?: string | null;
  memo?: string | null;
  metadata?: Record<string, unknown>;
}

export interface LedgerPostingInput {
  idempotencyKey: string;
  referenceType?: string | null;
  referenceId?: string | null;
  description: string;
  metadata?: Record<string, unknown>;
  entries: LedgerPostingEntry[];
}
