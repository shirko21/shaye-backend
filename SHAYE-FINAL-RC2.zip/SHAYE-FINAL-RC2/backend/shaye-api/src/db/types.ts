export type Role = "USER" | "ADMIN";
export type DepositStatus = "PENDING" | "APPROVED" | "REJECTED";
export type WithdrawalStatus =
  | "PENDING"
  | "RESERVED"
  | "PROCESSING"
  | "BROADCASTED"
  | "CONFIRMING"
  | "APPROVED"
  | "COMPLETED"
  | "FAILED"
  | "REJECTED"
  | "CANCELLED";
export type LockStatus = "ACTIVE" | "RELEASED";
export interface UserRow {
  id: string;
  email: string;
  password_hash: string;
  invite_code: string;
  referred_by_id: string | null;
  role: Role;
  vip_level: number;
  deposit_balance: string;
  profit_balance: string;
  locked_balance: string;
  total_deposit: string;
  total_withdraw: string;
  total_profit: string;
  referral_profit: string;
  wallet_address: string | null;
  wheel_spins: number;
  wheel_spins_used: number;
  is_active: boolean;
  last_seen_at: Date | null;
  created_at: Date;
  updated_at: Date;
}
