export interface WalletSummary { depositBalance: number; profitBalance: number; lockedBalance: number; totalDeposit: number; totalWithdraw: number; totalProfit: number; referralProfit: number; }
