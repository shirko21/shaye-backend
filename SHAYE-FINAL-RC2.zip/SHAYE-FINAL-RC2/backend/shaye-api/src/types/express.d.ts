import { Role } from "../db/types";
declare global { namespace Express { interface Request { auth?: { userId:string; email:string; role:Role } } } } export {};
