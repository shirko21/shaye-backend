export type BscNetworkName = "mainnet" | "testnet";

export interface BlockchainTokenStatus {
  configured: boolean;
  address: string | null;
  contractCodePresent: boolean | null;
  name: string | null;
  symbol: string | null;
  decimals: number | null;
  expectedDecimals: number | null;
  decimalsMatch: boolean | null;
}

export interface BlockchainStatus {
  enabled: boolean;
  configured: boolean;
  healthy: boolean;
  status: "disabled" | "not_configured" | "healthy" | "unhealthy";
  network: BscNetworkName;
  expectedChainId: number;
  actualChainId: number | null;
  chainIdMatch: boolean | null;
  latestBlock: number | null;
  rpcLatencyMs: number | null;
  token: BlockchainTokenStatus;
  checkedAt: string;
  error: string | null;
}
