import { Role } from "../db/types";
export interface AuthUser { id:string; email:string; role:Role; inviteCode:string; vipLevel:number; }
