#!/usr/bin/env sh
set -eu

cd "$(dirname "$0")/.."

[ -f .env.deploy ] || {
  echo "فایل .env.deploy پیدا نشد. ابتدا نصب اصلی سایت را انجام دهید."
  exit 1
}
[ -s secrets/deposit_wallet_xpub ] || {
  echo "کیف پول آدرس‌های اختصاصی هنوز ساخته نشده است. ابتدا مرحله ۳ را فعال کنید."
  exit 1
}
command -v docker >/dev/null 2>&1 || {
  echo "Docker روی VPS نصب نیست."
  exit 1
}
docker compose version >/dev/null 2>&1 || {
  echo "Docker Compose روی VPS در دسترس نیست."
  exit 1
}

printf "آدرس RPC شبکه BSC Testnet را وارد کنید: "
read -r RPC_URL
printf "آدرس قرارداد توکن آزمایشی روی BSC Testnet را وارد کنید (0x...): "
read -r TOKEN_CONTRACT
printf "شماره بلاک شروع اسکن (اختیاری؛ برای حالت خودکار Enter بزنید): "
read -r START_BLOCK

case "$RPC_URL" in
  http://*|https://*) ;;
  *) echo "آدرس RPC معتبر نیست."; exit 1 ;;
esac
printf '%s' "$TOKEN_CONTRACT" | grep -Eq '^0x[0-9a-fA-F]{40}$' || {
  echo "آدرس قرارداد توکن معتبر نیست."
  exit 1
}
if [ -n "$START_BLOCK" ]; then
  printf '%s' "$START_BLOCK" | grep -Eq '^[0-9]+$' || {
    echo "شماره بلاک باید عدد صحیح مثبت باشد."
    exit 1
  }
fi

echo ""
echo "این مرحله فقط باید روی TESTNET انجام شود و نباید پول واقعی ارسال شود."
printf "برای ادامه دقیقاً TESTNET را تایپ کنید: "
read -r CONFIRM
[ "$CONFIRM" = "TESTNET" ] || {
  echo "عملیات لغو شد."
  exit 1
}

set_env_value() {
  key="$1"
  value="$2"
  tmp=".env.deploy.tmp.$$"
  awk -v key="$key" -v value="$value" '
    BEGIN { done=0 }
    index($0, key "=") == 1 { print key "=" value; done=1; next }
    { print }
    END { if (!done) print key "=" value }
  ' .env.deploy > "$tmp"
  mv "$tmp" .env.deploy
}

set_env_value BLOCKCHAIN_ENABLED true
set_env_value BSC_NETWORK testnet
set_env_value BSC_RPC_URL "$RPC_URL"
set_env_value BSC_TOKEN_CONTRACT "$TOKEN_CONTRACT"
set_env_value BSC_TOKEN_EXPECTED_DECIMALS 18
set_env_value BLOCKCHAIN_DEPOSIT_SCANNER_ENABLED true
set_env_value BLOCKCHAIN_REQUIRED_CONFIRMATIONS 12
set_env_value BLOCKCHAIN_REORG_BUFFER_BLOCKS 24
set_env_value BLOCKCHAIN_SCAN_BATCH_SIZE 500
set_env_value BLOCKCHAIN_ADDRESS_TOPIC_BATCH_SIZE 100
set_env_value BLOCKCHAIN_INITIAL_LOOKBACK_BLOCKS 2000
set_env_value BLOCKCHAIN_DEPOSIT_SCAN_START_BLOCK "$START_BLOCK"
set_env_value BLOCKCHAIN_CURSOR_LEASE_SECONDS 120
chmod 600 .env.deploy

echo "در حال ساخت و روشن‌کردن سایت و Worker مرحله ۴..."
docker compose --profile blockchain --env-file .env.deploy up -d --build

echo "در حال فعال‌کردن شناسایی واریز در کنترل‌های دیتابیس..."
docker compose --env-file .env.deploy exec -T db sh -c \
  'psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "UPDATE blockchain_settings SET deposits_enabled = TRUE, emergency_stop = FALSE, emergency_reason = NULL, updated_at = now() WHERE id = '\''default'\'';"'

echo "حدود ۲۰ ثانیه صبر کنید تا اولین چرخه اسکن انجام شود..."
sleep 20

./scripts/check-deposit-watcher.sh

echo ""
echo "مرحله ۴ روی BSC Testnet فعال شد."
echo "در این مرحله فقط تراکنش شناسایی و تأیید می‌شود؛ موجودی حساب هنوز خودکار افزایش نمی‌یابد."
