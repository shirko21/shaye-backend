#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."

# This command is intentionally manual. Before running it, the manager must
# inspect the txHash on BscScan. Failed SEND jobs are returned to SIGNING so
# the exact persisted raw transaction is rebroadcast. Failed CONFIRM jobs are
# returned to CONFIRMING and never create a second transfer.
docker compose --env-file .env.deploy exec -T db sh -c \
  'psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" <<'"'"'SQL'"'"'
BEGIN;

UPDATE blockchain_withdrawals bw
SET status = CASE
      WHEN j.job_type = '"'"'CONFIRM_WITHDRAWAL'"'"' THEN '"'"'CONFIRMING'"'"'
      WHEN bw.raw_transaction IS NOT NULL THEN '"'"'SIGNING'"'"'
      ELSE '"'"'RESERVED'"'"'
    END,
    failure_reason = NULL,
    last_error = NULL,
    failed_at = NULL,
    updated_at = now()
FROM blockchain_jobs j
WHERE j.payload->>'"'"'blockchainWithdrawalId'"'"' = bw.id
  AND j.job_type IN ('"'"'SEND_WITHDRAWAL'"'"','"'"'CONFIRM_WITHDRAWAL'"'"')
  AND j.status = '"'"'FAILED'"'"'
  AND bw.status = '"'"'REVIEW_REQUIRED'"'"';

UPDATE withdrawals w
SET status = CASE
      WHEN bw.status = '"'"'CONFIRMING'"'"' THEN '"'"'CONFIRMING'"'"'
      ELSE '"'"'RESERVED'"'"'
    END,
    failure_reason = NULL,
    updated_at = now()
FROM blockchain_withdrawals bw
WHERE w.id = bw.withdrawal_id
  AND w.status = '"'"'REVIEW_REQUIRED'"'"'
  AND bw.status IN ('"'"'RESERVED'"'"','"'"'SIGNING'"'"','"'"'CONFIRMING'"'"');

UPDATE blockchain_jobs
SET status='"'"'RETRY'"'"', run_after=now(), attempts=0,
    locked_by=NULL, locked_at=NULL, lock_expires_at=NULL,
    last_error=NULL, completed_at=NULL, result=NULL, updated_at=now()
WHERE job_type IN ('"'"'SEND_WITHDRAWAL'"'"','"'"'CONFIRM_WITHDRAWAL'"'"')
  AND status='"'"'FAILED'"'"';

COMMIT;
SQL'

echo "Jobهای ناموفق برداشت پس از بررسی مدیر برای تلاش مجدد آماده شدند."
