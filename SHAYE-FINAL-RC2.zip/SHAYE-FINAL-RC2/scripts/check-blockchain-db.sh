#!/usr/bin/env sh
set -eu

cd "$(dirname "$0")/.."
ENV_FILE="${1:-.env.deploy}"

[ -f "$ENV_FILE" ] || {
  echo "فایل تنظیمات پیدا نشد: $ENV_FILE"
  exit 1
}

command -v docker >/dev/null 2>&1 || {
  echo "Docker نصب نیست."
  exit 1
}

echo "بررسی جدول‌های مرحله ۲..."
docker compose --env-file "$ENV_FILE" exec -T db sh -lc '
  psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" <<"SQL"
SELECT name, applied_at
FROM schema_migrations
WHERE name = '\''005_blockchain_database.sql'\'';

SELECT table_name
FROM information_schema.tables
WHERE table_schema = '\''public'\''
  AND table_name IN (
    '\''blockchain_settings'\'',
    '\''blockchain_wallets'\'',
    '\''blockchain_deposits'\'',
    '\''blockchain_withdrawals'\'',
    '\''blockchain_cursors'\'',
    '\''blockchain_jobs'\'',
    '\''wallet_sweeps'\'',
    '\''ledger_accounts'\'',
    '\''ledger_journals'\'',
    '\''ledger_entries'\''
  )
ORDER BY table_name;

SELECT network, chain_id, token_contract, emergency_stop,
       deposits_enabled, withdrawals_enabled, sweeps_enabled
FROM blockchain_settings
WHERE id = '\''default'\'';
SQL
'

echo "بررسی مرحله ۲ تمام شد."
