#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
[ $# -eq 1 ] || { echo "استفاده: ./scripts/restore.sh backups/file.dump"; exit 1; }
[ -f .env.deploy ] || { echo ".env.deploy پیدا نشد."; exit 1; }
[ -f "$1" ] || { echo "فایل بکاپ پیدا نشد."; exit 1; }
set -a
. ./.env.deploy
set +a
printf "تمام اطلاعات فعلی جایگزین شود؟ [yes]: "
read -r ANSWER
[ "$ANSWER" = "yes" ] || exit 1
docker compose --env-file .env.deploy exec -T db \
  pg_restore -U "$POSTGRES_USER" -d "$POSTGRES_DB" --clean --if-exists \
  < "$1"
echo "بازیابی انجام شد."
