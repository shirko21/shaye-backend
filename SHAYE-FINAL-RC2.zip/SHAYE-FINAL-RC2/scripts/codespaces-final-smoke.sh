#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
COMPOSE="$ROOT/docker-compose.codespaces.yml"
BASE="http://127.0.0.1:5000"
COOKIE="$(mktemp)"
BODY="$(mktemp)"
trap 'rm -f "$COOKIE" "$BODY"' EXIT

cd "$ROOT"
echo "[1/7] Build and start Codespaces stack"
docker compose -f "$COMPOSE" up -d --build

for i in $(seq 1 60); do
  if curl -fsS "$BASE/ready" >/dev/null 2>&1; then break; fi
  sleep 2
done
curl -fsS "$BASE/ready" >/dev/null

echo "[2/7] Static UI assets"
curl -fsS "$BASE/dashboard.html" | grep -q 'assets/js/lucky-wheel.js'
curl -fsS "$BASE/dashboard.html" | grep -q 'assets/js/user-shell.js'
! curl -fsS "$BASE/login.html" | grep -q 'assets/js/user-shell.js'
curl -fsS "$BASE/admin.html" | grep -q 'assets/js/admin-support.js'

echo "[3/7] Codespaces CORS"
if [[ -n "${CODESPACE_NAME:-}" && -n "${GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN:-}" ]]; then
  ORIGIN="https://${CODESPACE_NAME}-5000.${GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN}"
  HEADERS="$(mktemp)"
  curl -sS -D "$HEADERS" -o /dev/null -X OPTIONS \
    -H "Origin: $ORIGIN" \
    -H 'Access-Control-Request-Method: POST' \
    -H 'Access-Control-Request-Headers: content-type' \
    "$BASE/api/auth/login" || true
  grep -qi "^Access-Control-Allow-Origin: ${ORIGIN}\r\?$" "$HEADERS"
  rm -f "$HEADERS"
else
  echo "Codespaces environment variables are not available; CORS browser-origin check skipped."
fi

echo "[4/7] Register and session"
EMAIL="final-smoke-$(date +%s)-$RANDOM@example.com"
PASSWORD="Stage9A-Smoke-Password-123"
STATUS="$(curl -sS -o "$BODY" -w '%{http_code}' -c "$COOKIE" \
  -H 'Content-Type: application/json' \
  -d "{\"email\":\"$EMAIL\",\"password\":\"$PASSWORD\",\"inviteCode\":null}" \
  "$BASE/api/auth/register")"
[[ "$STATUS" == "201" ]]
curl -fsS -b "$COOKIE" "$BASE/api/auth/me" | grep -q "$EMAIL"

echo "[5/7] Main authenticated APIs"
for endpoint in \
  /api/wallet/summary \
  /api/public/config \
  /api/tasks/status \
  /api/user/team \
  /api/user/notifications \
  /api/support/unread \
  /api/wheel/status; do
  curl -fsS -b "$COOKIE" "$BASE$endpoint" >/dev/null
done

echo "[6/7] Support chat"
curl -fsS -b "$COOKIE" -H 'Content-Type: application/json' \
  -d '{"body":"پیام آزمایشی بررسی نهایی پشتیبانی"}' \
  "$BASE/api/support/messages" >/dev/null
curl -fsS -b "$COOKIE" "$BASE/api/support/messages" | grep -q 'پیام آزمایشی بررسی نهایی پشتیبانی'

echo "[7/7] Backend tests inside app image"
docker compose -f "$COMPOSE" exec -T app npm test

echo "✅ SHAYE 3.0 RC2 Codespaces smoke test passed."
echo "Test account: $EMAIL"
