#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
docker compose --env-file .env.deploy exec -T app \
  node dist/scripts/check-auto-withdrawal.js
