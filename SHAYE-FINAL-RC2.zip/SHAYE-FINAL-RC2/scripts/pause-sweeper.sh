#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
[ -f .env.deploy ] || { echo "فایل .env.deploy پیدا نشد."; exit 1; }
REASON="${1:-توقف دستی جمع‌آوری موجودی از طریق اسکریپت سرور}"
docker compose --env-file .env.deploy exec -T db sh -c \
  'psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" -v reason="$1"' sh "$REASON" <<'SQL'
UPDATE blockchain_settings
SET sweeps_enabled=FALSE, sweep_worker_enabled=FALSE,
    sweep_pause_reason=:'reason', sweep_paused_at=now(), updated_at=now()
WHERE id='default';
SQL
echo "جمع‌آوری موجودی متوقف شد. Worker روشن می‌ماند ولی تراکنش جدیدی ارسال نمی‌کند."
