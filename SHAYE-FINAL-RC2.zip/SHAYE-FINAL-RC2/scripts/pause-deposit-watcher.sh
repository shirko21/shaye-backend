#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."

[ -f .env.deploy ] || {
  echo "فایل .env.deploy پیدا نشد."
  exit 1
}

docker compose --env-file .env.deploy exec -T db sh -c \
  'psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "UPDATE blockchain_settings SET emergency_stop = TRUE, deposits_enabled = FALSE, emergency_reason = '\''Paused by administrator'\'', updated_at = now() WHERE id = '\''default'\'';"'

echo "شناسایی خودکار واریز فوراً متوقف شد. برای ادامه دوباره setup-deposit-watcher.sh را اجرا نکنید؛ ابتدا علت توقف را بررسی کنید."
