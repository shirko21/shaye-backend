#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
[ -f .env.deploy ] || { echo ".env.deploy پیدا نشد."; exit 1; }
set -a
. ./.env.deploy
set +a
mkdir -p backups
STAMP="$(date +%Y%m%d-%H%M%S)"
docker compose --env-file .env.deploy exec -T db \
  pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc \
  > "backups/shaye-$STAMP.dump"
find backups -type f -name 'shaye-*.dump' -mtime +14 -delete
echo "Backup: backups/shaye-$STAMP.dump"
