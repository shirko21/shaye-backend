#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKEND_DIR="$ROOT_DIR/backend/shaye-api"
COMPOSE_FILE="$ROOT_DIR/docker-compose.codespaces.yml"
LOG_DIR="$ROOT_DIR/stage9a-logs"
mkdir -p "$LOG_DIR"

say() { printf '\n[Stage 9A] %s\n' "$*"; }
fail() { printf '\n[Stage 9A ERROR] %s\n' "$*" >&2; exit 1; }

command -v node >/dev/null 2>&1 || fail "Node.js پیدا نشد. Codespace را دوباره بسازید."
command -v npm >/dev/null 2>&1 || fail "npm پیدا نشد."
command -v docker >/dev/null 2>&1 || fail "Docker در این Codespace فعال نیست."
docker compose version >/dev/null 2>&1 || fail "Docker Compose پیدا نشد."

say "نسخه ابزارها"
node --version
npm --version
docker --version
docker compose version

say "نصب وابستگی‌های Backend با npm ci"
(
  cd "$BACKEND_DIR"
  npm ci 2>&1 | tee "$LOG_DIR/npm-ci.log"
)

say "TypeScript typecheck و تست‌های خودکار"
(
  cd "$BACKEND_DIR"
  npm run check 2>&1 | tee "$LOG_DIR/npm-check.log"
)

say "بررسی JavaScript فرانت‌اند"
while IFS= read -r -d '' file; do
  node --check "$file"
done < <(find "$ROOT_DIR/frontend" -type f -name '*.js' -print0)

say "بررسی مهم: آدرس برداشت مشترک مجاز است"
if grep -RniE "UNIQUE[[:space:]]*\([^)]*(wallet_address|destination_address)|CREATE[[:space:]]+UNIQUE[[:space:]]+INDEX[^;]*(wallet_address|destination_address)" "$ROOT_DIR/backend/shaye-api/db/migrations"; then
  fail "محدودیت یکتا برای آدرس مقصد برداشت پیدا شد."
fi
printf '%s\n' "OK: هیچ محدودیت یکتایی روی آدرس مقصد برداشت وجود ندارد."

say "ساخت و اجرای PostgreSQL و برنامه؛ بلاک‌چین عمداً خاموش است"
docker compose -f "$COMPOSE_FILE" up -d --build 2>&1 | tee "$LOG_DIR/docker-up.log"

say "منتظر آماده‌شدن برنامه"
for attempt in $(seq 1 60); do
  if curl -fsS http://127.0.0.1:5000/ready > "$LOG_DIR/ready.json" 2>/dev/null; then
    break
  fi
  if [ "$attempt" -eq 60 ]; then
    docker compose -f "$COMPOSE_FILE" ps || true
    docker compose -f "$COMPOSE_FILE" logs --tail=200 app db || true
    fail "برنامه آماده نشد. لاگ‌ها را ارسال کنید."
  fi
  sleep 2
done

say "تست endpointهای سلامت"
curl -fsS http://127.0.0.1:5000/health | tee "$LOG_DIR/health.json"
printf '\n'
curl -fsS http://127.0.0.1:5000/ready | tee "$LOG_DIR/ready.json"
printf '\n'

say "وضعیت سرویس‌ها"
docker compose -f "$COMPOSE_FILE" ps | tee "$LOG_DIR/docker-ps.txt"

cat <<'DONE'

✅ مرحله 9A اولیه با موفقیت اجرا شد.
- PostgreSQL و Migrationها اجرا شده‌اند.
- Backend و Frontend روی پورت 5000 در دسترس‌اند.
- همه Workerهای بلاک‌چین و برداشت/واریز واقعی خاموش هستند.
- از بخش Ports در Codespaces روی پورت 5000 بزنید و Open in Browser را انتخاب کنید.

حساب آزمایشی مدیر:
Email: admin-stage9a@example.com
Password: Stage9A-Test-Only-Change-Me

این اطلاعات فقط برای Codespaces و تست است و در VPS استفاده نمی‌شود.
DONE
