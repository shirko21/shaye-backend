#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
COMPOSE_FILE="$ROOT_DIR/docker-compose.codespaces.yml"
docker compose -f "$COMPOSE_FILE" ps
printf '\n--- health ---\n'
curl -fsS http://127.0.0.1:5000/health || true
printf '\n\n--- ready ---\n'
curl -fsS http://127.0.0.1:5000/ready || true
printf '\n\n--- recent app logs ---\n'
docker compose -f "$COMPOSE_FILE" logs --tail=100 app
