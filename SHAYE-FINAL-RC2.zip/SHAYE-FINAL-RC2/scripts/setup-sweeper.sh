#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."

[ -f .env.deploy ] || { echo "ابتدا نصب اصلی سایت را انجام دهید تا .env.deploy ساخته شود."; exit 1; }
command -v docker >/dev/null 2>&1 || { echo "Docker روی VPS نصب نیست."; exit 1; }
docker compose version >/dev/null 2>&1 || { echo "Docker Compose v2 در دسترس نیست."; exit 1; }

get_env_value() {
  key="$1"
  awk -F= -v key="$key" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' .env.deploy
}
set_env_value() {
  key="$1"; value="$2"; tmp=".env.deploy.tmp.$$"
  awk -v key="$key" -v value="$value" '
    BEGIN { done=0 }
    index($0, key "=") == 1 { print key "=" value; done=1; next }
    { print }
    END { if (!done) print key "=" value }
  ' .env.deploy > "$tmp"
  mv "$tmp" .env.deploy
}

[ "$(get_env_value BSC_NETWORK)" = "testnet" ] || { echo "مرحله ۸ فقط روی BSC Testnet فعال می‌شود."; exit 1; }
[ "$(get_env_value BLOCKCHAIN_ENABLED)" = "true" ] || { echo "اتصال بلاک‌چین هنوز فعال نشده است."; exit 1; }
[ "$(get_env_value DEPOSIT_WALLET_ENABLED)" = "true" ] || { echo "ابتدا مرحله ۳ و آدرس اختصاصی کاربران را فعال کنید."; exit 1; }
[ -s secrets/deposit_wallet_mnemonic ] || { echo "عبارت بازیابی کیف پول واریز روی VPS پیدا نشد. ابتدا setup-deposit-wallet.sh را اجرا کنید."; exit 1; }
[ -n "$(get_env_value BSC_RPC_URL)" ] || { echo "BSC_RPC_URL خالی است."; exit 1; }
[ -n "$(get_env_value BSC_TOKEN_CONTRACT)" ] || { echo "BSC_TOKEN_CONTRACT خالی است."; exit 1; }

printf "\nاین مرحله فقط روی Testnet مقدار کمی BNB به آدرس کاربر می‌فرستد و توکن آزمایشی را به خزانه منتقل می‌کند.\n"
printf "برای ادامه دقیقاً SWEEP-TESTNET را تایپ کنید: "
read -r CONFIRM
[ "$CONFIRM" = "SWEEP-TESTNET" ] || { echo "لغو شد."; exit 1; }

mkdir -p secrets
chmod 700 secrets
[ -f secrets/gas_wallet_private_key ] || : > secrets/gas_wallet_private_key
chmod 600 secrets/gas_wallet_private_key

echo "در حال ساخت تصویر برنامه..."
docker compose --env-file .env.deploy build app

if [ ! -s secrets/gas_wallet_private_key ]; then
  rm -f secrets/gas_wallet_address
  echo "در حال ساخت کیف پول Gas آزمایشی روی همین VPS..."
  docker compose --env-file .env.deploy run --rm --no-deps --user 0:0 \
    -e WALLET_OUTPUT_DIR=/wallet-secrets \
    -v "$(pwd)/secrets:/wallet-secrets" \
    app node dist/scripts/generate-gas-wallet.js
fi
chmod 600 secrets/gas_wallet_private_key

GAS_ADDRESS=""
if [ -s secrets/gas_wallet_address ]; then
  GAS_ADDRESS="$(tr -d '\r\n ' < secrets/gas_wallet_address)"
else
  docker compose --profile tools --env-file .env.deploy build gas-wallet-tools >/dev/null
  GAS_ADDRESS="$(docker compose --profile tools --env-file .env.deploy run --rm --no-deps -T gas-wallet-tools 2>/dev/null | tail -n 1 | tr -d '\r')"
fi
printf "%s" "$GAS_ADDRESS" | grep -Eq '^0x[0-9A-Fa-f]{40}$' || { echo "آدرس کیف Gas معتبر ساخته نشد."; exit 1; }

TREASURY="$(get_env_value TREASURY_WALLET_ADDRESS)"
if ! printf "%s" "$TREASURY" | grep -Eq '^0x[0-9A-Fa-f]{40}$'; then
  echo ""
  echo "آدرس عمومی کیف خزانه Testnet را وارد کنید. این آدرس محرمانه نیست."
  echo "کلید خصوصی یا عبارت بازیابی خزانه را اینجا وارد نکنید."
  printf "TREASURY_WALLET_ADDRESS (0x...): "
  read -r TREASURY
fi
printf "%s" "$TREASURY" | grep -Eq '^0x[0-9A-Fa-f]{40}$' || { echo "آدرس خزانه معتبر نیست."; exit 1; }
[ "$(printf "%s" "$TREASURY" | tr '[:upper:]' '[:lower:]')" != "$(printf "%s" "$GAS_ADDRESS" | tr '[:upper:]' '[:lower:]')" ] || { echo "کیف Gas و خزانه باید دو آدرس جدا باشند."; exit 1; }

set_env_value BLOCKCHAIN_SWEEP_WORKER_ENABLED true
set_env_value BLOCKCHAIN_SWEEP_WORKER_INTERVAL_MS 20000
set_env_value BLOCKCHAIN_SWEEP_JOB_LEASE_SECONDS 240
set_env_value DEPOSIT_WALLET_MNEMONIC_FILE /run/secrets/deposit_wallet_mnemonic
set_env_value GAS_WALLET_ADDRESS "$GAS_ADDRESS"
set_env_value GAS_WALLET_PRIVATE_KEY_FILE /run/secrets/gas_wallet_private_key
set_env_value TREASURY_WALLET_ADDRESS "$TREASURY"
chmod 600 .env.deploy

echo "در حال اجرای Migration و روشن‌کردن Worker جمع‌آوری..."
docker compose --profile blockchain --env-file .env.deploy up -d --build

echo "در حال فعال‌کردن تنظیمات امن پیش‌فرض مرحله ۸ در PostgreSQL..."
docker compose --env-file .env.deploy exec -T db sh -c \
  'psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "UPDATE blockchain_settings SET sweeps_enabled=TRUE, sweep_worker_enabled=TRUE, sweep_min_amount=10, sweep_discovery_batch_size=50, sweep_job_batch_size=3, sweep_max_concurrent=1, sweep_target_gas_bnb=0.001, sweep_gas_wallet_min_bnb_reserve=0.05, sweep_pause_reason=NULL, sweep_paused_at=NULL, updated_at=now() WHERE id='\''default'\'';"'

sleep 10
./scripts/check-sweeper.sh

echo ""
echo "مرحله ۸ روی Testnet فعال شد."
echo "آدرس کیف Gas آزمایشی:"
echo "$GAS_ADDRESS"
echo "آدرس خزانه Testnet:"
echo "$TREASURY"
echo ""
echo "برای انجام تست، بعداً باید مقدار کمی BNB آزمایشی به کیف Gas بفرستید."
echo "کلید خصوصی Gas فقط در secrets/gas_wallet_private_key روی VPS است و نباید ارسال یا کپی شود."
