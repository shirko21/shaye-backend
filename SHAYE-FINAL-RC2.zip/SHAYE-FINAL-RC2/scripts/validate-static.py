#!/usr/bin/env python3
from __future__ import annotations
from html.parser import HTMLParser
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
FRONT = ROOT / 'frontend'
AUTH_PAGES = {'dashboard.html','wallet.html','team.html','tasks.html','report.html','deposit.html','withdraw.html'}
PUBLIC_AUTH = {'index.html','login.html','register.html'}

class Parser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids=[]; self.refs=[]; self.scripts=[]; self.styles=[]
    def handle_starttag(self, tag, attrs):
        d=dict(attrs)
        if 'id' in d:self.ids.append(d['id'])
        for key in ('src','href'):
            v=d.get(key)
            if v and not (v.startswith(('http://','https://','data:','#','mailto:','tel:','javascript:'))):
                self.refs.append(v.split('?',1)[0].split('#',1)[0])
        if tag=='script' and d.get('src'): self.scripts.append(d['src'])
        if tag=='link' and d.get('rel')=='stylesheet': self.styles.append(d.get('href',''))

errors=[]
for html in sorted(FRONT.glob('*.html')):
    p=Parser(); text=html.read_text(encoding='utf-8'); p.feed(text)
    dup=sorted({x for x in p.ids if p.ids.count(x)>1})
    if dup: errors.append(f'{html.name}: duplicate ids {dup}')
    for ref in p.refs:
        if not ref: continue
        target=(html.parent/ref).resolve()
        try: target.relative_to(ROOT.resolve())
        except ValueError: continue
        if not target.exists(): errors.append(f'{html.name}: missing reference {ref}')
    has_wheel='assets/js/lucky-wheel.js' in text
    has_shell='assets/js/user-shell.js' in text
    if html.name in AUTH_PAGES:
        if not has_wheel: errors.append(f'{html.name}: wheel script missing')
        if not has_shell: errors.append(f'{html.name}: user shell missing')
        if 'bottom-nav' not in text: errors.append(f'{html.name}: bottom navigation missing')
        for target in ('dashboard.html','wallet.html','team.html','tasks.html','report.html'):
            if f'data-page="{target}"' not in text:
                errors.append(f'{html.name}: navigation target missing: {target}')
    if html.name in PUBLIC_AUTH:
        if has_wheel or has_shell: errors.append(f'{html.name}: authenticated floating tools must not load')

required=[
 'frontend/assets/js/lucky-wheel.js','frontend/assets/css/lucky-wheel.css',
 'frontend/assets/js/user-shell.js','frontend/assets/css/user-shell.css',
 'frontend/assets/js/admin-support.js','frontend/assets/css/admin-support.css',
 'backend/shaye-api/src/services/deposit-watcher.service.ts',
 'backend/shaye-api/src/services/deposit-credit.service.ts',
 'backend/shaye-api/src/services/withdrawal-execution.service.ts',
 'backend/shaye-api/src/services/automatic-withdrawal.service.ts',
 'backend/shaye-api/src/services/wallet-sweeper.service.ts',
]
for f in required:
    if not (ROOT/f).is_file() or (ROOT/f).stat().st_size==0: errors.append(f'missing required file: {f}')

# Ensure admin support UI is actually wired.
admin=(FRONT/'admin.html').read_text(encoding='utf-8')
for token in ('data-tab="supportPage"','id="supportPage"','assets/js/admin-support.js','assets/css/admin-support.css'):
    if token not in admin: errors.append(f'admin.html missing {token}')

# Secrets must be empty placeholders.
for f in ('deposit_wallet_mnemonic','deposit_wallet_xpub','gas_wallet_private_key','hot_wallet_private_key'):
    p=ROOT/'secrets'/f
    if not p.exists(): errors.append(f'missing secret placeholder: {f}')
    elif p.stat().st_size != 0: errors.append(f'secret placeholder is not empty: {f}')

# No known internal registry or obvious private material.
text_files=[]
for p in ROOT.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.js','.ts','.json','.yml','.yaml','.md','.txt','.html','.css','.example'}:
        text_files.append(p)
for p in text_files:
    try:t=p.read_text(encoding='utf-8',errors='ignore')
    except Exception:continue
    if 'packages.applied-caas-gateway1.internal.api.openai.org' in t: errors.append(f'internal npm registry in {p.relative_to(ROOT)}')
    if re.search(r'\b(?:0x)?[0-9a-fA-F]{64}\b',t) and 'integrity' not in str(p) and p.name not in {'package-lock.json'}:
        # Many hashes are legitimate; only flag files in secrets/env/frontend.
        if 'secrets' in p.parts or p.suffix in {'.env'} or 'frontend' in p.parts:
            errors.append(f'possible private key/hash in {p.relative_to(ROOT)}')

# Mainnet must remain blocked in shipped examples.
deploy=(ROOT/'.env.deploy.example').read_text()
for line in ('BSC_NETWORK=testnet','BLOCKCHAIN_WITHDRAWAL_ALLOW_MAINNET=false'):
    if line not in deploy: errors.append(f'deployment example missing safety line: {line}')

# Shared destination addresses must not be globally unique; only exact request idempotency is allowed.
migrations='\n'.join(p.read_text(errors='ignore') for p in (ROOT/'backend/shaye-api/db/migrations').glob('*.sql'))
if re.search(r'UNIQUE\s*\([^)]*wallet_address',migrations,re.I): errors.append('withdrawal destination address is incorrectly unique')

if errors:
    print('STATIC VALIDATION FAILED')
    for e in errors: print('-',e)
    sys.exit(1)
print('✅ Static release validation passed.')
