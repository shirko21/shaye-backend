#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
[ -f .env.deploy ] || { echo "فایل .env.deploy پیدا نشد."; exit 1; }
docker compose --env-file .env.deploy exec -T db sh -c \
  'psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB"' <<'SQL'
UPDATE blockchain_jobs
SET status='RETRY', run_after=now(), attempts=0, last_error=NULL,
    locked_by=NULL, locked_at=NULL, lock_expires_at=NULL, updated_at=now()
WHERE job_type IN ('FUND_GAS','SWEEP_TOKEN') AND status='FAILED';

UPDATE wallet_sweeps
SET status=CASE
      WHEN sweep_tx_hash IS NOT NULL THEN 'CONFIRMING'
      WHEN gas_funding_tx_hash IS NOT NULL THEN 'GAS_CONFIRMING'
      ELSE 'DISCOVERED'
    END,
    last_error=NULL, next_attempt_at=now(), updated_at=now()
WHERE status='FAILED';
SQL
echo "کارهای ناموفق جمع‌آوری برای بررسی دوباره در صف قرار گرفتند."
