#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
[ -f .env.deploy ] || { echo ".env.deploy پیدا نشد."; exit 1; }
docker compose --env-file .env.deploy exec -T db sh -c \
  'psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "UPDATE blockchain_settings SET auto_withdrawals_enabled=FALSE, auto_withdrawal_pause_reason='\''توقف دستی از VPS'\'', auto_withdrawal_paused_at=now(), updated_at=now() WHERE id='\''default'\'';"'
echo "برداشت خودکار متوقف شد. برداشت‌های دستی و Worker تأیید تراکنش‌های قبلی همچنان فعال می‌مانند."
