#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
[ -f .env.deploy ] || { echo "فایل .env.deploy پیدا نشد."; exit 1; }

tmp=".env.deploy.tmp.$$"
awk '
  BEGIN { done=0 }
  index($0, "BLOCKCHAIN_AUTO_CREDIT_ENABLED=") == 1 {
    print "BLOCKCHAIN_AUTO_CREDIT_ENABLED=false"; done=1; next
  }
  { print }
  END { if (!done) print "BLOCKCHAIN_AUTO_CREDIT_ENABLED=false" }
' .env.deploy > "$tmp"
mv "$tmp" .env.deploy
chmod 600 .env.deploy

docker compose --env-file .env.deploy exec -T db sh -c \
  'psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "UPDATE blockchain_settings SET auto_credit_enabled = FALSE, updated_at = now() WHERE id = '\''default'\'';"'
docker compose --profile blockchain --env-file .env.deploy up -d --build deposit-credit-worker

echo "اعتباردهی خودکار متوقف شد. شناسایی واریزها می‌تواند همچنان ادامه داشته باشد."
