#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
[ -f .env.deploy ] || { echo "ابتدا سایت و مرحله ۶ را روی VPS نصب کنید."; exit 1; }
command -v docker >/dev/null 2>&1 || { echo "Docker نصب نیست."; exit 1; }

get_env_value() {
  key="$1"
  awk -F= -v key="$key" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' .env.deploy
}
[ "$(get_env_value BSC_NETWORK)" = "testnet" ] || { echo "مرحله ۷ فقط روی Testnet فعال می‌شود."; exit 1; }
[ "$(get_env_value BLOCKCHAIN_WITHDRAWAL_WORKER_ENABLED)" = "true" ] || { echo "ابتدا مرحله ۶ و Worker برداشت را فعال کنید."; exit 1; }

printf "این مرحله برداشت‌های کوچک را بدون تأیید مدیر وارد صف Testnet می‌کند.\n"
printf "برای ادامه دقیقاً AUTO-WITHDRAW-TESTNET را تایپ کنید: "
read -r CONFIRM
[ "$CONFIRM" = "AUTO-WITHDRAW-TESTNET" ] || { echo "لغو شد."; exit 1; }

docker compose --profile blockchain --env-file .env.deploy up -d --build

docker compose --env-file .env.deploy exec -T db sh -c \
  'psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "UPDATE blockchain_settings SET auto_withdrawals_enabled=TRUE, auto_withdrawal_max_amount=50, auto_withdrawal_daily_limit=500, auto_withdrawal_daily_count_limit=20, auto_withdrawal_max_concurrent=3, hot_wallet_min_token_reserve=10, hot_wallet_min_bnb_reserve=0.01, auto_withdrawal_pause_reason=NULL, auto_withdrawal_paused_at=NULL, updated_at=now() WHERE id='\''default'\'';"'

sleep 8
./scripts/check-auto-withdrawals.sh
printf "\nمرحله ۷ روی Testnet فعال شد. همه سقف‌ها از پنل مدیریت قابل تغییر هستند.\n"
