#!/usr/bin/env sh
set -eu

cd "$(dirname "$0")/.."

command -v docker >/dev/null 2>&1 || {
  echo "Docker نصب نیست. ابتدا Docker و Docker Compose را نصب کنید."
  exit 1
}
docker compose version >/dev/null 2>&1 || {
  echo "Docker Compose v2 در دسترس نیست."
  exit 1
}
command -v openssl >/dev/null 2>&1 || {
  echo "OpenSSL نصب نیست."
  exit 1
}

printf "دامنه بدون https (مثال: example.com): "
read -r DOMAIN
printf "ایمیل مدیر: "
read -r ADMIN_EMAIL
printf "آدرس دریافت USDT BEP20 (اختیاری؛ با Enter خالی بگذارید): "
read -r DEPOSIT_WALLET_ADDRESS
printf "رمز مدیر (حداقل 8 کاراکتر؛ فقط حروف، عدد و @._+-): "
stty -echo
read -r ADMIN_PASSWORD
stty echo
printf "\n"

case "$DOMAIN" in
  *://*|*/*|*' '*|'') echo "دامنه معتبر نیست."; exit 1 ;;
esac
case "$ADMIN_EMAIL" in
  *@*.*) ;;
  *) echo "ایمیل معتبر نیست."; exit 1 ;;
esac
if [ -z "$DEPOSIT_WALLET_ADDRESS" ]; then
  DEPOSIT_WALLET_ADDRESS="0x0000000000000000000000000000000000000000"
elif ! printf '%s' "$DEPOSIT_WALLET_ADDRESS" | grep -Eq '^0x[0-9a-fA-F]{40}$'; then
  echo "آدرس BEP20 معتبر نیست."
  exit 1
fi
case "$ADMIN_PASSWORD" in
  *[!A-Za-z0-9@._+-]*|'') echo "رمز فقط می‌تواند شامل حروف، عدد و @._+- باشد."; exit 1 ;;
esac
[ ${#ADMIN_PASSWORD} -ge 8 ] || {
  echo "رمز مدیر باید حداقل 8 کاراکتر باشد."
  exit 1
}

POSTGRES_PASSWORD="$(openssl rand -hex 24)"
JWT_SECRET="$(openssl rand -hex 48)"

cat > .env.deploy <<ENV
DOMAIN=$DOMAIN
POSTGRES_DB=shaye
POSTGRES_USER=shaye
POSTGRES_PASSWORD=$POSTGRES_PASSWORD
JWT_SECRET=$JWT_SECRET
ADMIN_EMAIL=$ADMIN_EMAIL
ADMIN_PASSWORD=$ADMIN_PASSWORD
DEPOSIT_WALLET_ADDRESS=$DEPOSIT_WALLET_ADDRESS
BLOCKCHAIN_ENABLED=false
BSC_NETWORK=testnet
BSC_RPC_URL=
BSC_TOKEN_CONTRACT=
BSC_TOKEN_EXPECTED_DECIMALS=18
BLOCKCHAIN_REQUEST_TIMEOUT_MS=8000
BLOCKCHAIN_STATUS_CACHE_MS=15000
BLOCKCHAIN_WATCHER_INTERVAL_MS=15000
BLOCKCHAIN_DEPOSIT_SCANNER_ENABLED=false
BLOCKCHAIN_REQUIRED_CONFIRMATIONS=12
BLOCKCHAIN_REORG_BUFFER_BLOCKS=24
BLOCKCHAIN_SCAN_BATCH_SIZE=500
BLOCKCHAIN_ADDRESS_TOPIC_BATCH_SIZE=100
BLOCKCHAIN_INITIAL_LOOKBACK_BLOCKS=2000
BLOCKCHAIN_DEPOSIT_SCAN_START_BLOCK=
BLOCKCHAIN_CURSOR_LEASE_SECONDS=120
DEPOSIT_WALLET_ENABLED=false
DEPOSIT_WALLET_ACCOUNT_PATH=m/44'/60'/0'
DEPOSIT_WALLET_CHANGE_INDEX=0
ENV

chmod 600 .env.deploy

mkdir -p secrets
chmod 700 secrets
[ -f secrets/deposit_wallet_xpub ] || : > secrets/deposit_wallet_xpub
[ -f secrets/hot_wallet_private_key ] || : > secrets/hot_wallet_private_key
chmod 600 secrets/deposit_wallet_xpub secrets/hot_wallet_private_key

docker compose --env-file .env.deploy up -d --build

echo ""
echo "راه‌اندازی انجام شد: https://$DOMAIN"
echo "وضعیت سرویس‌ها: docker compose --env-file .env.deploy ps"
