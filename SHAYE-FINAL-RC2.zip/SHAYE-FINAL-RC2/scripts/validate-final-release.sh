#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
API="$ROOT/backend/shaye-api"

echo "[1/9] Static release rules"
python3 "$ROOT/scripts/validate-static.py"

echo "[2/9] JavaScript syntax"
find "$ROOT/frontend/assets/js" -type f -name '*.js' -print0 | xargs -0 -n1 node --check

echo "[3/9] Frontend API bindings"
node "$ROOT/scripts/validate-api-bindings.js"

echo "[4/9] TypeScript syntax"
NODE_PATH="$(npm root -g)" node - <<'NODE' "$ROOT"
const fs=require('fs'),path=require('path'),ts=require('typescript');
const root=process.argv[2], base=path.join(root,'backend/shaye-api/src');
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())walk(p);else if(p.endsWith('.ts')){const source=fs.readFileSync(p,'utf8');const r=ts.transpileModule(source,{reportDiagnostics:true,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}});const bad=(r.diagnostics||[]).filter(d=>d.category===ts.DiagnosticCategory.Error);if(bad.length){console.error(p,bad.map(x=>ts.flattenDiagnosticMessageText(x.messageText,' ' )).join('\n'));process.exitCode=1}}}}
walk(base);if(process.exitCode)process.exit(process.exitCode);console.log('TypeScript syntax parsed successfully.');
NODE

echo "[5/9] CSS syntax"
NODE_PATH="$(npm root -g)" node - <<'NODE' "$ROOT"
const fs=require('fs'),path=require('path'),postcss=require('postcss');
const root=process.argv[2];
for(const f of fs.readdirSync(path.join(root,'frontend/assets/css')).filter(x=>x.endsWith('.css'))){
  postcss.parse(fs.readFileSync(path.join(root,'frontend/assets/css',f),'utf8'),{from:f});
}
console.log('CSS parsed successfully.');
NODE

if [[ "${1:-}" == "--static-only" ]]; then
  echo "✅ SHAYE 3.0 RC2 static validation completed."
  exit 0
fi

echo "[6/9] Install backend dependencies"
cd "$API"
npm ci --no-audit --no-fund

echo "[7/9] TypeScript typecheck"
npm run typecheck

echo "[8/9] Backend build"
npm run build

echo "[9/9] Backend tests"
node --test dist/tests/*.test.js

echo "✅ SHAYE 3.0 RC2 full validation completed."
