'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm');
const root=path.resolve(__dirname,'..');
const apiFile=path.join(root,'frontend/assets/js/api.js');
const context={window:{},fetch:async()=>({ok:true,json:async()=>({data:null})}),console};
context.window.window=context.window;
vm.runInNewContext(fs.readFileSync(apiFile,'utf8'),context,{filename:apiFile});
const api=context.window.ShayeAPI;
const functions=new Set();
for(const [group,obj] of Object.entries(api||{})){
  if(typeof obj==='function')functions.add(group);
  else if(obj&&typeof obj==='object')for(const [name,value] of Object.entries(obj))if(typeof value==='function')functions.add(group+'.'+name);
}
const missing=[];
for(const file of fs.readdirSync(path.join(root,'frontend/assets/js')).filter(x=>x.endsWith('.js')&&x!=='api.js')){
  const text=fs.readFileSync(path.join(root,'frontend/assets/js',file),'utf8');
  const re=/(?:\bAPI|\bShayeAPI)(?:\?\.)?\.([A-Za-z_$][\w$]*)(?:\?\.)?\.([A-Za-z_$][\w$]*)/g;
  let m;while((m=re.exec(text))){const key=m[1]+'.'+m[2];if(!functions.has(key))missing.push(file+': '+key)}
}
if(missing.length){console.error('Undefined API bindings:\n'+[...new Set(missing)].join('\n'));process.exit(1)}
console.log('API bindings validated.');
