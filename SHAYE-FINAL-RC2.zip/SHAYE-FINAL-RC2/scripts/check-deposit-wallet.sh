#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."

[ -f .env.deploy ] || {
  echo "فایل .env.deploy پیدا نشد."
  exit 1
}
[ -s secrets/deposit_wallet_xpub ] || {
  echo "فایل کلید عمومی کیف پول خالی است. ابتدا ./scripts/setup-deposit-wallet.sh را اجرا کنید."
  exit 1
}

docker compose --env-file .env.deploy exec -T app \
  node dist/scripts/check-deposit-wallet.js
