#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."

echo "این دستور فقط Jobهای ناموفق مرحله ۵ را دوباره در صف قرار می‌دهد."
printf "برای ادامه RETRY را تایپ کنید: "
read -r CONFIRM
[ "$CONFIRM" = "RETRY" ] || { echo "لغو شد."; exit 1; }

docker compose --env-file .env.deploy exec -T db sh -c \
  'psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "UPDATE blockchain_jobs SET status = '\''RETRY'\'', run_after = now(), attempts = 0, last_error = NULL, locked_by = NULL, locked_at = NULL, lock_expires_at = NULL, updated_at = now() WHERE job_type = '\''CREDIT_DEPOSIT'\'' AND status = '\''FAILED'\'';"'

echo "Jobهای ناموفق دوباره در صف قرار گرفتند."
