#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
docker compose -f "$ROOT_DIR/docker-compose.codespaces.yml" down
printf '%s\n' "Stage 9A متوقف شد. دیتابیس آزمایشی حفظ شده است."
