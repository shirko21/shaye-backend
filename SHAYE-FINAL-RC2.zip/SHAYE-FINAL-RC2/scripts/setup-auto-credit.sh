#!/usr/bin/env sh
set -eu

cd "$(dirname "$0")/.."

[ -f .env.deploy ] || {
  echo "فایل .env.deploy پیدا نشد. ابتدا نصب اصلی سایت را انجام دهید."
  exit 1
}
command -v docker >/dev/null 2>&1 || {
  echo "Docker روی VPS نصب نیست."
  exit 1
}
docker compose version >/dev/null 2>&1 || {
  echo "Docker Compose روی VPS در دسترس نیست."
  exit 1
}

get_env_value() {
  key="$1"
  awk -F= -v key="$key" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' .env.deploy
}

[ "$(get_env_value BSC_NETWORK)" = "testnet" ] || {
  echo "مرحله ۵ ابتدا فقط باید روی BSC Testnet فعال شود."
  exit 1
}
[ "$(get_env_value BLOCKCHAIN_ENABLED)" = "true" ] || {
  echo "اتصال بلاک‌چین هنوز فعال نشده است. ابتدا مرحله ۴ را راه‌اندازی کنید."
  exit 1
}
[ "$(get_env_value BLOCKCHAIN_DEPOSIT_SCANNER_ENABLED)" = "true" ] || {
  echo "Worker شناسایی واریز هنوز فعال نشده است. ابتدا مرحله ۴ را راه‌اندازی کنید."
  exit 1
}

printf "این مرحله موجودی کاربران را بعد از تأیید شبکه به‌صورت خودکار افزایش می‌دهد.\n"
printf "فقط برای تست‌نت و توکن آزمایشی ادامه دهید.\n"
printf "برای ادامه دقیقاً AUTO-CREDIT-TESTNET را تایپ کنید: "
read -r CONFIRM
[ "$CONFIRM" = "AUTO-CREDIT-TESTNET" ] || {
  echo "عملیات لغو شد."
  exit 1
}

set_env_value() {
  key="$1"
  value="$2"
  tmp=".env.deploy.tmp.$$"
  awk -v key="$key" -v value="$value" '
    BEGIN { done=0 }
    index($0, key "=") == 1 { print key "=" value; done=1; next }
    { print }
    END { if (!done) print key "=" value }
  ' .env.deploy > "$tmp"
  mv "$tmp" .env.deploy
}

set_env_value BLOCKCHAIN_AUTO_CREDIT_ENABLED true
set_env_value BLOCKCHAIN_CREDIT_WORKER_INTERVAL_MS 10000
set_env_value BLOCKCHAIN_CREDIT_BATCH_SIZE 20
set_env_value BLOCKCHAIN_CREDIT_JOB_LEASE_SECONDS 120
chmod 600 .env.deploy

echo "در حال ساخت نسخه مرحله ۵ و اجرای Migration..."
docker compose --profile blockchain --env-file .env.deploy up -d --build

echo "در حال فعال‌کردن اعتباردهی خودکار در دیتابیس..."
docker compose --env-file .env.deploy exec -T db sh -c \
  'psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "UPDATE blockchain_settings SET deposits_enabled = TRUE, auto_credit_enabled = TRUE, emergency_stop = FALSE, emergency_reason = NULL, updated_at = now() WHERE id = '\''default'\''; UPDATE app_settings SET funding_mode = '\''BLOCKCHAIN'\'', updated_at = now() WHERE id = '\''default'\'';"'

echo "حدود ۲۰ ثانیه صبر کنید تا Worker آماده شود..."
sleep 20
./scripts/check-auto-credit.sh

echo ""
echo "مرحله ۵ روی Testnet فعال شد."
echo "از این لحظه واریز آزمایشی پس از تأیید شبکه، خودکار به موجودی قفل‌شده اضافه می‌شود."
