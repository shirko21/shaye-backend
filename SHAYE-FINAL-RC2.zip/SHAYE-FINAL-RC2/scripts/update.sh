#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
[ -f .env.deploy ] || { echo ".env.deploy پیدا نشد."; exit 1; }
docker compose --env-file .env.deploy build --pull
docker compose --env-file .env.deploy up -d
docker image prune -f
docker compose --env-file .env.deploy ps
