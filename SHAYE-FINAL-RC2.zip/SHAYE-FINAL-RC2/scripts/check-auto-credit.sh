#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
docker compose --profile blockchain --env-file .env.deploy exec -T deposit-credit-worker \
  node dist/scripts/check-deposit-credit.js
