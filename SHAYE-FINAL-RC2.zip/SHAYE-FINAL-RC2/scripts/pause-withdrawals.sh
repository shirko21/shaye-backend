#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
[ -f .env.deploy ] || { echo ".env.deploy پیدا نشد."; exit 1; }

tmp=".env.deploy.tmp.$$"
awk '
  index($0, "BLOCKCHAIN_WITHDRAWAL_WORKER_ENABLED=") == 1 {
    print "BLOCKCHAIN_WITHDRAWAL_WORKER_ENABLED=false"; done=1; next
  }
  { print }
  END { if (!done) print "BLOCKCHAIN_WITHDRAWAL_WORKER_ENABLED=false" }
' .env.deploy > "$tmp"
mv "$tmp" .env.deploy
chmod 600 .env.deploy

docker compose --env-file .env.deploy exec -T db sh -c \
  'psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "UPDATE blockchain_settings SET withdrawals_enabled=FALSE, withdrawal_worker_enabled=FALSE, updated_at=now() WHERE id='\''default'\'';"'
docker compose --profile blockchain --env-file .env.deploy up -d --build
echo "برداشت بلاک‌چینی متوقف شد. درخواست‌های رزروشده حذف یا برگشت داده نشدند."
