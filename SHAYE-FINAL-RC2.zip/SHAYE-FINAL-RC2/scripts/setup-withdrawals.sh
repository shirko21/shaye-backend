#!/usr/bin/env sh
set -eu

cd "$(dirname "$0")/.."

[ -f .env.deploy ] || {
  echo "فایل .env.deploy پیدا نشد. ابتدا نصب اصلی سایت را انجام دهید."
  exit 1
}
command -v docker >/dev/null 2>&1 || {
  echo "Docker روی VPS نصب نیست."
  exit 1
}
docker compose version >/dev/null 2>&1 || {
  echo "Docker Compose روی VPS در دسترس نیست."
  exit 1
}
command -v openssl >/dev/null 2>&1 || {
  echo "برنامه openssl روی VPS نصب نیست."
  echo "در Ubuntu این دستور را اجرا کنید: sudo apt update && sudo apt install -y openssl"
  exit 1
}

get_env_value() {
  key="$1"
  awk -F= -v key="$key" '$1 == key {sub(/^[^=]*=/, ""); print; exit}' .env.deploy
}

[ "$(get_env_value BSC_NETWORK)" = "testnet" ] || {
  echo "مرحله ۶ فقط باید روی BSC Testnet فعال شود."
  exit 1
}
[ "$(get_env_value BLOCKCHAIN_ENABLED)" = "true" ] || {
  echo "اتصال بلاک‌چین فعال نیست. ابتدا مراحل ۱ تا ۵ را روی VPS راه‌اندازی کنید."
  exit 1
}
[ -n "$(get_env_value BSC_RPC_URL)" ] || {
  echo "BSC_RPC_URL خالی است."
  exit 1
}
[ -n "$(get_env_value BSC_TOKEN_CONTRACT)" ] || {
  echo "BSC_TOKEN_CONTRACT خالی است."
  exit 1
}

printf "\nاین مرحله یک کیف پول Hot آزمایشی می‌سازد و برداشت تأییدشده مدیر را روی Testnet ارسال می‌کند.\n"
printf "این نسخه نباید با پول واقعی یا Mainnet استفاده شود.\n"
printf "برای ادامه دقیقاً WITHDRAW-TESTNET را تایپ کنید: "
read -r CONFIRM
[ "$CONFIRM" = "WITHDRAW-TESTNET" ] || {
  echo "عملیات لغو شد."
  exit 1
}

mkdir -p secrets
chmod 700 secrets

if [ ! -s secrets/hot_wallet_private_key ]; then
  echo "در حال ساخت کلید خصوصی کیف پول Hot آزمایشی..."
  umask 077
  printf "0x%s\n" "$(openssl rand -hex 32)" > secrets/hot_wallet_private_key
fi
chmod 600 secrets/hot_wallet_private_key

echo "در حال ساخت ابزار بررسی آدرس..."
docker compose --profile tools --env-file .env.deploy build wallet-tools >/dev/null

HOT_ADDRESS=""
attempt=0
while [ -z "$HOT_ADDRESS" ] && [ "$attempt" -lt 5 ]; do
  attempt=$((attempt + 1))
  if HOT_ADDRESS="$(docker compose --profile tools --env-file .env.deploy run --rm --no-deps -T wallet-tools 2>/dev/null | tail -n 1 | tr -d '\r')" &&
     printf "%s" "$HOT_ADDRESS" | grep -Eq '^0x[0-9A-Fa-f]{40}$'; then
    break
  fi
  umask 077
  printf "0x%s\n" "$(openssl rand -hex 32)" > secrets/hot_wallet_private_key
  chmod 600 secrets/hot_wallet_private_key
  HOT_ADDRESS=""
done

[ -n "$HOT_ADDRESS" ] || {
  echo "ساخت کیف پول Hot موفق نبود."
  exit 1
}

set_env_value() {
  key="$1"
  value="$2"
  tmp=".env.deploy.tmp.$$"
  awk -v key="$key" -v value="$value" '
    BEGIN { done=0 }
    index($0, key "=") == 1 { print key "=" value; done=1; next }
    { print }
    END { if (!done) print key "=" value }
  ' .env.deploy > "$tmp"
  mv "$tmp" .env.deploy
}

set_env_value BLOCKCHAIN_WITHDRAWAL_WORKER_ENABLED true
set_env_value BLOCKCHAIN_WITHDRAWAL_ALLOW_MAINNET false
set_env_value BLOCKCHAIN_WITHDRAWAL_WORKER_INTERVAL_MS 10000
set_env_value BLOCKCHAIN_WITHDRAWAL_BATCH_SIZE 5
set_env_value BLOCKCHAIN_WITHDRAWAL_JOB_LEASE_SECONDS 180
set_env_value HOT_WALLET_ADDRESS "$HOT_ADDRESS"
set_env_value HOT_WALLET_PRIVATE_KEY_FILE /run/secrets/hot_wallet_private_key
chmod 600 .env.deploy

echo "در حال اجرای Migration و روشن‌کردن Worker برداشت..."
docker compose --profile blockchain --env-file .env.deploy up -d --build

echo "در حال فعال‌کردن برداشت Testnet در دیتابیس..."
docker compose --env-file .env.deploy exec -T db sh -c \
  'psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "UPDATE blockchain_settings SET withdrawals_enabled = TRUE, withdrawal_worker_enabled = TRUE, withdrawal_approval_required = TRUE, emergency_stop = FALSE, emergency_reason = NULL, updated_at = now() WHERE id = '\''default'\''; UPDATE app_settings SET funding_mode = '\''BLOCKCHAIN'\'', updated_at = now() WHERE id = '\''default'\'';"'

echo "حدود ۱۵ ثانیه صبر کنید..."
sleep 15
./scripts/check-withdrawals.sh

echo ""
echo "مرحله ۶ روی Testnet فعال شد."
echo "آدرس کیف پول Hot آزمایشی:"
echo "$HOT_ADDRESS"
echo ""
echo "برای انجام برداشت آزمایشی، بعداً باید مقدار کمی BNB آزمایشی و توکن آزمایشی"
echo "به همین آدرس بفرستید. کلید خصوصی داخل secrets/hot_wallet_private_key است؛"
echo "آن را برای هیچ‌کس ارسال نکنید و از این کیف پول برای پول واقعی استفاده نکنید."
