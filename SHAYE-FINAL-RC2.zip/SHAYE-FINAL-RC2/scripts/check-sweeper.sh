#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
[ -f .env.deploy ] || { echo "فایل .env.deploy پیدا نشد."; exit 1; }
docker compose --env-file .env.deploy exec -T app node dist/scripts/check-sweeper.js
