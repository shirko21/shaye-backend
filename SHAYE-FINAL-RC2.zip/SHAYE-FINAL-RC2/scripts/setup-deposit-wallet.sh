#!/usr/bin/env sh
set -eu

cd "$(dirname "$0")/.."

[ -f .env.deploy ] || {
  echo "فایل .env.deploy پیدا نشد. ابتدا ./scripts/setup.sh را اجرا کنید."
  exit 1
}

command -v docker >/dev/null 2>&1 || {
  echo "Docker نصب نیست."
  exit 1
}

docker compose version >/dev/null 2>&1 || {
  echo "Docker Compose v2 در دسترس نیست."
  exit 1
}

mkdir -p secrets
chmod 700 secrets
[ -f secrets/deposit_wallet_xpub ] || : > secrets/deposit_wallet_xpub
chmod 600 secrets/deposit_wallet_xpub

if [ -s secrets/deposit_wallet_mnemonic ] || [ -s secrets/deposit_wallet_xpub ]; then
  echo "کیف پول واریز قبلاً ساخته شده است. برای جلوگیری از از دست رفتن دسترسی، فایل‌ها بازنویسی نشدند."
  echo "برای بررسی، اجرا کنید: ./scripts/check-deposit-wallet.sh"
  exit 1
fi

echo "در حال ساخت تصویر برنامه..."
docker compose --env-file .env.deploy build app

echo "در حال ساخت کیف پول HD روی همین VPS..."
docker compose --env-file .env.deploy run --rm --no-deps --user 0:0 \
  -e WALLET_OUTPUT_DIR=/wallet-secrets \
  -v "$(pwd)/secrets:/wallet-secrets" \
  app node dist/scripts/generate-deposit-wallet.js

chmod 700 secrets
chmod 600 secrets/deposit_wallet_*

set_env_value() {
  key="$1"
  value="$2"
  if grep -q "^${key}=" .env.deploy; then
    tmp=".env.deploy.tmp.$$"
    awk -v key="$key" -v value="$value" '
      BEGIN { done=0 }
      index($0, key "=") == 1 { print key "=" value; done=1; next }
      { print }
      END { if (!done) print key "=" value }
    ' .env.deploy > "$tmp"
    mv "$tmp" .env.deploy
  else
    printf '\n%s=%s\n' "$key" "$value" >> .env.deploy
  fi
}

set_env_value DEPOSIT_WALLET_ENABLED true
set_env_value DEPOSIT_WALLET_ACCOUNT_PATH "m/44'/60'/0'"
set_env_value DEPOSIT_WALLET_CHANGE_INDEX 0
chmod 600 .env.deploy

echo "در حال اجرای مجدد برنامه و اعمال Migration مرحله ۳..."
docker compose --env-file .env.deploy up -d --build

echo "در حال ساخت آدرس اختصاصی برای کاربران فعلی..."
docker compose --env-file .env.deploy exec -T app \
  node dist/scripts/backfill-deposit-wallets.js

echo "در حال بررسی تنظیمات کیف پول..."
./scripts/check-deposit-wallet.sh

echo ""
echo "کیف پول مرحله ۳ ساخته شد."
echo "عبارت بازیابی فقط در این فایل قرار دارد:"
echo "  $(pwd)/secrets/deposit_wallet_mnemonic"
echo ""
printf "برای نمایش یک‌باره عبارت بازیابی در همین ترمینال، عبارت SHOW را تایپ کنید؛ برای ردکردن Enter بزنید: "
read -r answer || answer=""
if [ "$answer" = "SHOW" ]; then
  echo ""
  echo "عبارت بازیابی را روی کاغذ بنویسید و از آن عکس نگیرید:"
  echo "------------------------------------------------------------"
  cat secrets/deposit_wallet_mnemonic
  echo "------------------------------------------------------------"
fi

echo "پایان. فایل‌های پوشه secrets را در GitHub، چت یا ZIP قرار ندهید."
