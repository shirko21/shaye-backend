# مرحله ۲ اتصال بلاک‌چین — دیتابیس و دفتر مالی

این نسخه ساختار پایدار دیتابیس را برای مراحل بعدی واریز، برداشت و Sweep بلاک‌چینی اضافه می‌کند. در این مرحله هنوز هیچ آدرس اختصاصی ساخته نمی‌شود، بلاک‌ها اسکن نمی‌شوند و هیچ تراکنش واقعی امضا یا ارسال نمی‌شود.

## موارد اضافه‌شده

- migration جدید `005_blockchain_database.sql`
- کنترل مرکزی بلاک‌چین و توقف اضطراری
- جدول آدرس‌های عمومی کاربران
- جدول رویدادهای واریز با شناسه یکتای `chainId + txHash + logIndex`
- جدول برداشت بلاک‌چینی و کلید idempotency
- Cursor برای ادامه اسکن پس از خاموشی Worker
- صف Job با قفل، زمان انقضای Lease، Retry و `FOR UPDATE SKIP LOCKED`
- جدول عملیات Sweep و تأمین BNB کارمزد
- دفتر مالی دوطرفه شامل Account، Journal و Entry
- جلوگیری دیتابیسی از ثبت Journal نامتوازن
- غیرقابل‌تغییرشدن Journal بعد از ثبت نهایی
- حساب‌های سیستمی اولیه USDT و BNB
- همگام‌سازی شبکه، Chain ID و قرارداد توکن از متغیرهای محیطی به دیتابیس
- بازیابی Jobهایی که Worker آن‌ها را نیمه‌کاره رها کرده است

## حالت ایمن پیش‌فرض

پس از ساخت دیتابیس، تنظیمات زیر فعال هستند:

```text
emergency_stop = true
deposits_enabled = false
withdrawals_enabled = false
sweeps_enabled = false
```

بنابراین این مرحله به‌تنهایی نمی‌تواند پولی را جابه‌جا یا موجودی کاربر را تغییر دهد.

## اجرای migration

Migration با شروع سرویس `app` یا `blockchain-watcher` به‌صورت خودکار اجرا می‌شود:

```bash
docker compose --env-file .env.deploy up -d --build
```

برای مشاهده گزارش:

```bash
docker compose --env-file .env.deploy logs -f app
```

باید خط زیر دیده شود:

```text
Applied migration 005_blockchain_database.sql
```

## بررسی دیتابیس

پس از اجرای سرویس:

```bash
./scripts/check-blockchain-db.sh
```

یا برای فایل env دیگر:

```bash
./scripts/check-blockchain-db.sh .env.production
```

## کاری که در این مرحله باید انجام دهید

در حال حاضر لازم نیست برنامه، کیف پول یا افزونه جدیدی نصب کنید. هنگام انتقال این نسخه به VPS فقط Docker و Docker Compose لازم است که در راهنمای استقرار پروژه آمده است.

هیچ Seed Phrase، Private Key، Keystore یا رمز کیف پولی وارد نکنید. مرحله ۳ فقط با آدرس‌ها و مشتق‌سازی Testnet شروع خواهد شد و اطلاعات محرمانه جداگانه مدیریت می‌شوند.

## نکته ارتقا از مرحله ۱

اگر دیتابیس مرحله ۱ از قبل روی VPS اجرا شده باشد، فایل مرحله ۲ را جایگزین و سپس اجرا کنید:

```bash
docker compose --env-file .env.deploy up -d --build
```

اطلاعات قبلی حذف نمی‌شوند؛ فقط Migration جدید روی همان PostgreSQL اجرا می‌شود. قبل از هر ارتقا از دیتابیس نسخه پشتیبان تهیه کنید:

```bash
./scripts/backup.sh
```
