# استقرار SHAYE روی VPS و دامنه

## پیش‌نیازها

- VPS با Ubuntu 22.04 یا 24.04
- دامنه با رکورد `A` متصل به IP سرور
- باز بودن پورت‌های `22`، `80` و `443`

## ۱. ورود به VPS و نصب ابزارها

```bash
ssh root@IP_VPS
apt update && apt upgrade -y
apt install unzip curl openssl -y
curl -fsSL https://get.docker.com | sh
docker compose version
```

## ۲. بارگذاری و استخراج پروژه

فایل ZIP را روی سرور بفرست، سپس:

```bash
unzip SHAYE-SERVER-READY.zip
cd SHAYE-SERVER-READY
chmod +x scripts/*.sh
```

## ۳. اجرای نصب خودکار

```bash
./scripts/setup.sh
```

اسکریپت این موارد را می‌پرسد:

- دامنه بدون `https://`
- ایمیل مدیر
- آدرس دریافت USDT روی BEP20؛ می‌توانی موقتاً خالی بگذاری
- رمز مدیر

رمز PostgreSQL و کلید JWT به‌طور خودکار ساخته می‌شوند. سپس PostgreSQL، برنامه و Caddy اجرا می‌شوند و HTTPS صادر می‌شود.

## ۴. بررسی اجرا

```bash
docker compose --env-file .env.deploy ps
curl https://YOUR-DOMAIN/health
curl https://YOUR-DOMAIN/ready
```

صفحات اصلی:

```text
https://YOUR-DOMAIN/
https://YOUR-DOMAIN/login.html
https://YOUR-DOMAIN/admin.html
```

## ۵. تنظیمات اولیه داخل پنل مدیر

پس از ورود به `admin.html` این موارد را بررسی و ذخیره کن:

- آدرس دریافت USDT BEP20
- حداقل واریز و برداشت
- مدت قفل سرمایه
- ساعت و منطقه زمانی وظیفه
- نرخ‌های معرفی و VIP
- وضعیت گردونه و جوایز
- مشخصات، بنرها، اخبار، مجوزها و اسناد سایت

## روند دستی واریز

1. کاربر USDT را به آدرس نمایش‌داده‌شده انتقال می‌دهد.
2. مبلغ و `txHash` را در صفحه واریز ثبت می‌کند.
3. مدیر انتقال را در مرورگر بلاک بررسی می‌کند.
4. مدیر فقط پس از اطمینان، درخواست را تأیید می‌کند.

## روند دستی برداشت

1. کاربر درخواست برداشت ثبت می‌کند و مبلغ از موجودی قابل برداشت رزرو می‌شود.
2. مدیر وجه را به آدرس کاربر ارسال می‌کند.
3. پس از ارسال، مدیر درخواست را تأیید می‌کند.
4. اگر وجه ارسال نشد، مدیر درخواست را رد می‌کند تا مبلغ خودکار برگردد.

## مدیریت و نگهداری

لاگ برنامه:

```bash
docker compose --env-file .env.deploy logs -f app
```

به‌روزرسانی:

```bash
./scripts/update.sh
```

بکاپ:

```bash
./scripts/backup.sh
```

بازیابی:

```bash
./scripts/restore.sh backups/FILE.dump
```

راه‌اندازی مجدد:

```bash
docker compose --env-file .env.deploy restart
```

خاموش‌کردن بدون حذف اطلاعات:

```bash
docker compose --env-file .env.deploy down
```

## نکات مهم

- فایل `.env.deploy` را برای کسی ارسال نکن.
- پوشه `backups` را خارج از VPS نیز نگهداری کن.
- Spck فقط فایل‌های ظاهری را نمایش می‌دهد؛ ورود و داده‌های واقعی بدون اجرای API و PostgreSQL کار نمی‌کنند.
- قبل از استفاده با پول واقعی، بررسی حقوقی، امنیتی و آزمون مستقل لازم است.
- این نسخه واریز و برداشت را فقط روی BSC Testnet اجرا می‌کند؛ Mainnet و پول واقعی مجاز نیست.

## افزوده مرحله ۶ — برداشت Testnet پس از تأیید مدیر

بعد از اینکه مراحل ۱ تا ۵ روی VPS و BSC Testnet با موفقیت بررسی شدند، ابتدا بکاپ بگیرید و سپس اجرا کنید:

```bash
./scripts/backup.sh
./scripts/setup-withdrawals.sh
```

این اسکریپت کیف پول Hot **آزمایشی** را روی VPS می‌سازد، Secret را فقط به Worker برداشت می‌دهد، Migration مرحله ۶ را اجرا می‌کند و Worker را روشن می‌کند. برای پول واقعی و Mainnet استفاده نشود.

وضعیت:

```bash
./scripts/check-withdrawals.sh
```

توقف فوری برداشت:

```bash
./scripts/pause-withdrawals.sh
```

در این مرحله مدیر برداشت را تأیید می‌کند و Worker آن را روی Testnet می‌فرستد. توضیح ساده‌تر در `VPS-STAGE-06-BEGINNER-FA.md` قرار دارد.
