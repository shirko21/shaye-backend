# مرحله ۱ اتصال بلاک‌چین — زیرساخت BSC

این نسخه فقط زیرساخت خواندنی اتصال به BNB Smart Chain را اضافه می‌کند. در این مرحله هیچ واریز یا برداشتی به‌طور خودکار ثبت، تأیید یا ارسال نمی‌شود و هیچ کلید خصوصی در پروژه وجود ندارد.

## موارد اضافه‌شده

- کتابخانه `ethers` نسخه ۶
- تنظیمات مجزای BSC Testnet و Mainnet
- کنترل اجباری Chain ID
- کنترل وجود کد قرارداد توکن
- خواندن `name`، `symbol` و `decimals` قرارداد ERC-20
- کش کوتاه‌مدت نتیجه Health Check
- Timeout برای RPC
- مسیر عمومی `GET /health/blockchain`
- مسیر عمومی `GET /api/blockchain/status`
- Worker خواندنی و آزمایشی `blockchain-watcher`
- توقف تمیز Provider هنگام خاموش‌شدن برنامه

## تنظیمات محیطی

در شروع، اتصال غیرفعال است:

```env
BLOCKCHAIN_ENABLED=false
BSC_NETWORK=testnet
BSC_RPC_URL=
BSC_TOKEN_CONTRACT=
BSC_TOKEN_EXPECTED_DECIMALS=18
BLOCKCHAIN_REQUEST_TIMEOUT_MS=8000
BLOCKCHAIN_STATUS_CACHE_MS=15000
BLOCKCHAIN_WATCHER_INTERVAL_MS=15000
```

برای فعال‌کردن تست، در فایل `.env.deploy` این مقادیر را وارد کنید:

```env
BLOCKCHAIN_ENABLED=true
BSC_NETWORK=testnet
BSC_RPC_URL=https://YOUR_BSC_TESTNET_RPC
BSC_TOKEN_CONTRACT=0xYOUR_TEST_TOKEN_CONTRACT
BSC_TOKEN_EXPECTED_DECIMALS=18
```

آدرس قرارداد باید روی همان شبکه‌ای باشد که در `BSC_NETWORK` تعیین شده است. در صورت اشتباه بودن Chain ID، نبودن قرارداد یا تفاوت decimals، وضعیت اتصال `unhealthy` می‌شود.

## اجرای سایت

اجرای عادی سایت:

```bash
docker compose --env-file .env.deploy up -d --build
```

بررسی اتصال:

```bash
curl https://YOUR_DOMAIN/health/blockchain
curl https://YOUR_DOMAIN/api/blockchain/status
```

اجرای Worker آزمایشی خواندنی:

```bash
docker compose --profile blockchain --env-file .env.deploy up -d --build
```

مشاهده گزارش Worker:

```bash
docker compose --profile blockchain --env-file .env.deploy logs -f blockchain-watcher
```

## نکات امنیتی

- در این مرحله هیچ Seed Phrase، Private Key یا Keystore لازم نیست.
- کلید خصوصی را داخل `.env.deploy`، GitHub، دیتابیس یا فایل ZIP قرار ندهید.
- Worker این مرحله فقط سلامت RPC و قرارداد را بررسی می‌کند و هیچ موجودی را تغییر نمی‌دهد.
- تا پایان مراحل دیتابیس، Watcher و دفتر مالی، از Mainnet برای دریافت پول کاربران استفاده نکنید.
