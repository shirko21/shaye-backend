# نکات امنیتی

- نشست کاربر در Cookie امضاشده، HttpOnly، Secure و SameSite=Lax نگهداری می‌شود.
- رمزها با bcrypt و ۱۲ دور هش می‌شوند.
- تمام مسیرهای خصوصی وضعیت موجود و فعال بودن حساب را بررسی می‌کنند.
- Rate Limit، Helmet، CSP، CORS و HTTPS فعال هستند.
- تغییرات موجودی با تراکنش PostgreSQL و Row Lock انجام می‌شوند.
- محدودیت‌های دیتابیس از موجودی منفی، دوباره‌پردازی و درخواست برداشت تکراری روزانه جلوگیری می‌کنند.
- عملیات مهم مدیر در `admin_action_logs` ثبت می‌شود.
- اسرار در `.env.deploy` قرار می‌گیرند و نباید Commit یا ارسال شوند.

در نسخه مرحله ۸، کلیدها فقط در Docker Secretهای جداگانه روی VPS نگهداری می‌شوند و هر Worker فقط به کلید موردنیاز خودش دسترسی دارد. برنامه اصلی سایت به عبارت بازیابی و کلیدهای امضا دسترسی ندارد. این نسخه همچنان فقط برای Testnet است؛ برای استفاده مالی واقعی، ممیزی امنیتی مستقل و بررسی الزامات قانونی ضروری است.

## Blockchain stage 1

The blockchain component in this release is read-only. It does not contain a signer and must never be given a seed phrase or private key. RPC and token-contract configuration must first be validated on BSC Testnet. Automatic deposits, withdrawals and wallet sweeping are not implemented in stage 1.


## امنیت دیتابیس بلاک‌چین

- جدول `blockchain_wallets` فقط آدرس عمومی و مسیر مشتق‌سازی را نگه می‌دارد.
- Seed Phrase، Private Key، Keystore و رمز آن‌ها نباید در PostgreSQL ذخیره شوند.
- تنظیم `emergency_stop` به‌صورت پیش‌فرض فعال است.
- کلیدهای idempotency و یکتایی `chain_id + tx_hash + log_index` از پردازش دوباره جلوگیری می‌کنند.
- Journalهای دفتر مالی بعد از POSTED شدن تغییرپذیر نیستند و در زمان Commit باید دوطرفه و متوازن باشند.

## Stage 3 deposit-wallet security

- The web application receives only the account-level xpub through a Docker Secret.
- The mnemonic is created on the VPS and is not mounted into the `app` container.
- PostgreSQL stores only public addresses, derivation indexes, paths and a non-secret fingerprint.
- Never replace the mnemonic/xpub on an existing database. A mismatch intentionally blocks address assignment.
- Automatic deposit detection and any signing capability remain disabled until later stages.

## Stage 4 deposit-watcher security

- The watcher uses a read-only JSON-RPC provider and contains no signer.
- It queries only token `Transfer` logs addressed to active deposit wallets.
- A database cursor lease prevents two watcher instances from advancing the same stream simultaneously.
- Event identity is enforced with `chain_id + tx_hash + log_index`.
- Recent blocks are rescanned and stored block hashes are compared to detect chain reorganizations.
- The scanner is disabled by default and can be paused immediately through database emergency controls.
- Stage 4 must remain on Testnet; it does not credit balances, sweep tokens or send withdrawals.

## Stage 8 sweep-worker security

- The web application still receives only the public deposit-wallet xpub.
- Only `sweep-worker` receives the deposit mnemonic and gas-wallet private key through Docker Secrets.
- `.env.deploy` and the entire `secrets` directory are excluded from the Docker build context.
- The withdrawal worker cannot read sweep secrets, and the sweep worker cannot read the hot-wallet key.
- The treasury private key is not required by the application; only its public address is configured.
- The worker verifies every derived private key against the public address stored in PostgreSQL before signing.
- Raw signed transactions and hashes are persisted before broadcast so restarts do not create duplicate transfers.
- A partial unique index permits only one active sweep per deposit wallet.
- Gas-wallet nonce selection is protected by a PostgreSQL advisory lock.
- Gas funding is bounded by estimated fee, configured target balance and a mandatory gas-wallet reserve.
- Mainnet sweep execution is blocked in Stage 8.
