import { PoolClient } from "pg";
import { query, withTransaction } from "../config/database";
import { mapSetting, mapTier, randomId } from "../utils/helpers";
import { env } from "../env";

const defaultTiers = [
  { level: 1, label: "VIP 1", minLocked: 10, dailyRate: 1, minWithdrawal: 2.5 },
  { level: 2, label: "VIP 2", minLocked: 30, dailyRate: 1.2, minWithdrawal: 7 },
  { level: 3, label: "VIP 3", minLocked: 60, dailyRate: 1.5, minWithdrawal: 15 },
  { level: 4, label: "VIP 4", minLocked: 150, dailyRate: 1.8, minWithdrawal: 37 },
  { level: 5, label: "VIP 5", minLocked: 300, dailyRate: 2, minWithdrawal: 75 },
];

export async function ensureDefaults() {
  await withTransaction(async (client) => {
    await client.query(`INSERT INTO app_settings(id, platform_name, sandbox_mode, funding_mode)
       VALUES('default', 'SHAYE', FALSE, 'MANUAL') ON CONFLICT(id) DO NOTHING`);
    await client.query(`INSERT INTO wheel_settings(id) VALUES('default') ON CONFLICT(id) DO NOTHING`);
    await client.query(`INSERT INTO home_content(id, content) VALUES('default', '{}'::jsonb) ON CONFLICT(id) DO NOTHING`);
    if (env.DEPOSIT_WALLET_ADDRESS) {
      await client.query(
        `UPDATE app_settings
         SET deposit_wallet_address = $1, updated_at = now()
         WHERE id = 'default'
           AND deposit_wallet_address IN (
             '0x0000000000000000000000000000000000000000',
             '0x1111111111111111111111111111111111111111'
           )`,
        [env.DEPOSIT_WALLET_ADDRESS],
      );
    }
    for (const tier of defaultTiers) {
      await client.query(`INSERT INTO vip_tiers(id, level, label, min_locked, daily_rate, min_withdrawal)
        VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(level) DO NOTHING`,
        [randomId(),tier.level,tier.label,tier.minLocked,tier.dailyRate,tier.minWithdrawal]);
    }
  });
}
export async function getSettings() { const result=await query("SELECT * FROM app_settings WHERE id='default'"); return mapSetting(result.rows[0]); }
export async function getVipTiers(includeInactive=false){const result=await query(`SELECT * FROM vip_tiers ${includeInactive?"":"WHERE is_active=TRUE"} ORDER BY level`);return result.rows.map(mapTier);}
export async function calculateVipLevel(lockedBalance:unknown){const r=await query<{level:number}>(`SELECT level FROM vip_tiers WHERE is_active=TRUE AND min_locked <= $1 ORDER BY level DESC LIMIT 1`,[lockedBalance]);return r.rows[0]?.level||0;}
export async function syncVipLevel(userId:string,client?:PoolClient){const run=(t:string,p:unknown[]=[])=>client?client.query(t,p):query(t,p);const ur=await run("SELECT locked_balance,vip_level FROM users WHERE id=$1",[userId]);const u=ur.rows[0];if(!u)return 0;const tr=await run(`SELECT level FROM vip_tiers WHERE is_active=TRUE AND min_locked <= $1 ORDER BY level DESC LIMIT 1`,[u.locked_balance]);const level=tr.rows[0]?.level||0;if(level!==u.vip_level)await run("UPDATE users SET vip_level=$1,updated_at=now() WHERE id=$2",[level,userId]);return level;}
export async function syncAllVipLevels(client?:PoolClient){const run=(t:string,p:unknown[]=[])=>client?client.query(t,p):query(t,p);await run(`UPDATE users u SET vip_level=COALESCE((SELECT v.level FROM vip_tiers v WHERE v.is_active=TRUE AND v.min_locked<=u.locked_balance ORDER BY v.level DESC LIMIT 1),0),updated_at=now() WHERE role='USER'`);}
